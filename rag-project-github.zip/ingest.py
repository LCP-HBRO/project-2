"""
ingest.py — Điểm vào của PIPELINE NẠP DỮ LIỆU.

Luồng:  data/documents/ -> loader -> chunker -> embedding -> ChromaDB

Chạy:   python ingest.py
        python ingest.py --strategy fixed --chunk-size 256 --reset
        (dùng --strategy/--chunk-size/--overlap để THÍ NGHIỆM — xem Ngày 3
        trong README: so sánh fixed vs recursive ảnh hưởng retrieval thế nào)

THIẾT KẾ:
    run_ingest() nhận `documents_dir` và `store` như THAM SỐ CÓ THỂ TRUYỀN VÀO
    (mặc định lấy từ config), thay vì gọi cứng load_documents()/VectorStore()
    bên trong. Đây là kỹ thuật "dependency injection" đơn giản: nhờ vậy
    tests/test_ingest.py có thể trỏ documents_dir và store vào thư mục tạm
    (tmp_path) để kiểm thử mà không đụng tới dữ liệu thật trong data/.
"""

import time
from pathlib import Path

from src.chunker import chunk_documents
from src.config import CHUNK_OVERLAP, CHUNK_SIZE, DOCUMENTS_DIR
from src.embedding import get_embedder
from src.loader import load_documents
from src.vectordb import VectorStore


def run_ingest(
    documents_dir: Path = DOCUMENTS_DIR,
    strategy: str = "recursive",
    chunk_size: int = CHUNK_SIZE,
    overlap: int = CHUNK_OVERLAP,
    store: VectorStore | None = None,
    reset: bool = False,
) -> int:
    """Chạy toàn bộ pipeline ingest, trả về số chunk đã nạp vào ChromaDB."""
    print("[ingest] Đang đọc tài liệu...")
    documents = load_documents(documents_dir)
    print(f"[ingest] Đã đọc {len(documents)} Document (trang PDF hoặc file .md/.txt).")

    # Nạp embedder TRƯỚC khi cắt chunk (không phải sau, như phiên bản Ngày 2):
    # chiến lược "semantic" cần model này ngay trong bước chunking (để embed
    # từng câu, tìm ranh giới chủ đề) — nạp sớm để dùng CHUNG một model cho cả
    # bước chunking lẫn bước embed chunk cuối cùng, tránh nạp model 2 lần.
    print("[ingest] Đang nạp model embedding (bge-m3)...")
    embedder = get_embedder()

    print(f"[ingest] Đang cắt chunk (strategy={strategy}, chunk_size={chunk_size}, overlap={overlap})...")
    chunk_kwargs = {"embedder": embedder} if strategy == "semantic" else {}
    chunks = chunk_documents(documents, strategy=strategy, chunk_size=chunk_size, overlap=overlap, **chunk_kwargs)
    print(f"[ingest] Sinh ra {len(chunks)} chunk.")

    if not chunks:
        print("[ingest] Không có chunk nào để nạp — kiểm tra lại thư mục tài liệu.")
        return 0

    print(f"[ingest] Đang tính vector cho {len(chunks)} chunk...")
    start = time.time()
    vectors = embedder.embed_texts([c.text for c in chunks])
    print(f"[ingest] Xong trong {time.time() - start:.1f}s.")

    if store is None:
        store = VectorStore()
    if reset:
        print("[ingest] --reset -> xoá toàn bộ dữ liệu cũ trong ChromaDB trước khi nạp lại.")
        store.reset()

    store.add(chunks, vectors)
    print(f"[ingest] Hoàn tất. Tổng số chunk hiện có trong ChromaDB: {store.count()}")
    return len(chunks)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Nạp toàn bộ data/documents/ vào ChromaDB.")
    parser.add_argument("--strategy", choices=["fixed", "recursive", "semantic"], default="recursive")
    parser.add_argument("--chunk-size", type=int, default=CHUNK_SIZE)
    parser.add_argument("--overlap", type=int, default=CHUNK_OVERLAP)
    parser.add_argument("--reset", action="store_true", help="Xoá dữ liệu cũ trong ChromaDB trước khi nạp lại")
    args = parser.parse_args()

    run_ingest(
        strategy=args.strategy,
        chunk_size=args.chunk_size,
        overlap=args.overlap,
        reset=args.reset,
    )
