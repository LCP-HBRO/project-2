import sys
sys.path.insert(0, '.')
try:
    print("Attempting to import ask...")
    import ask
    print("Import ask successful!")
except BaseException as e:
    import traceback
    traceback.print_exc()
