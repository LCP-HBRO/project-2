"""
llm.py — Gọi Qwen qua Ollama để sinh câu trả lời cuối cùng.

LÝ THUYẾT:
    Đây là bước GENERATION — CỐ Ý giữ đơn giản, đúng mục tiêu dự án đề ra ngay
    từ đầu ("Generation should remain simple", trọng tâm là Retrieval). Không
    streaming, không agent/tool-calling/memory — chỉ MỘT lệnh gọi duy nhất: đưa
    prompt đã dựng sẵn (từ prompt_builder.py) vào Qwen, nhận về MỘT câu trả lời.

    Dùng thư viện `ollama` chính thức (client HTTP gọi tới Ollama server chạy
    local tại OLLAMA_HOST) — đây KHÔNG phải một RAG framework như LangChain/
    LlamaIndex (bị cấm dùng trong dự án này), mà chỉ là client kết nối tới một
    server suy luận LLM local, tương tự việc dùng thư viện `requests` để gọi
    một API — không che giấu logic RAG nào, mọi bước retrieval/rerank/prompt
    vẫn do CHÍNH TA viết.

THIẾT KẾ:
    - generate_answer() nhận thẳng một prompt STRING đã dựng xong (từ
      prompt_builder.build_prompt), KHÔNG tự ghép ngữ cảnh bên trong hàm này —
      giữ ranh giới rõ ràng: prompt_builder.py chịu trách nhiệm NỘI DUNG prompt,
      llm.py chỉ chịu trách nhiệm GỌI model.
    - Module-level `_client` (không phải tạo mới mỗi lần gọi) — Client chỉ lưu
      host/cấu hình kết nối, không tốn tài nguyên đáng kể để giữ 1 instance
      dùng chung, tương tự get_embedder()/get_reranker() ở các module khác.
    - LLMError: bọc lại 2 lỗi thật đã gặp khi test thủ công (Ollama server tắt
      -> ConnectionError; model chưa `ollama pull` -> ollama.ResponseError)
      thành MỘT loại lỗi có thông điệp rõ ràng kèm lệnh khắc phục cụ thể. Nếu
      không bọc, app.py (Streamlit) sẽ hiện traceback thô cho người dùng cuối —
      trải nghiệm tệ cho một app demo.
"""

import ollama

from src.config import LLM_MAX_TOKENS, LLM_MODEL, LLM_TEMPERATURE, OLLAMA_HOST, LLM_NUM_GPU

_client = ollama.Client(host=OLLAMA_HOST)


class LLMError(Exception):
    """Lỗi khi gọi Qwen qua Ollama — thông điệp đã kèm gợi ý khắc phục cụ thể."""


def generate_answer(
    prompt: str,
    model: str = LLM_MODEL,
    temperature: float = LLM_TEMPERATURE,
    max_tokens: int = LLM_MAX_TOKENS,
) -> str:
    """Gửi `prompt` tới Qwen (qua Ollama), trả về câu trả lời dạng text."""
    try:
        response = _client.chat(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            options={
                "temperature": temperature, 
                "num_predict": max_tokens,
                "num_gpu": LLM_NUM_GPU
            },
        )
    except ConnectionError as e:
        raise LLMError(
            f"Không kết nối được tới Ollama server tại {OLLAMA_HOST}. "
            f"Kiểm tra Ollama đã chạy chưa (mở ứng dụng Ollama, hoặc chạy `ollama serve`)."
        ) from e
    except ollama.ResponseError as e:
        raise LLMError(
            f"Ollama báo lỗi khi gọi model '{model}': {e}. "
            f"Nếu model chưa có, tải bằng lệnh: `ollama pull {model}`."
        ) from e
    return response["message"]["content"]


if __name__ == "__main__":
    # Chạy `python -m src.llm "câu hỏi của bạn"` để thử nhanh CHỈ riêng bước LLM
    # (không qua retrieval/rerank) — hữu ích để kiểm tra Ollama server hoạt động.
    import sys

    prompt = " ".join(sys.argv[1:]) or "Xin chào, bạn là ai?"
    print(generate_answer(prompt))
