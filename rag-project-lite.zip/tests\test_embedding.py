"""
Test độc lập cho embedding.py.

CHIẾN LƯỢC TEST 2 TẦNG (một quyết định thiết kế đáng học):
1) Unit test (mặc định, nhanh, KHÔNG cần mạng/GPU): thay SentenceTransformer thật
   bằng một "fake" giả lập, chỉ kiểm tra Embedder gọi đúng tham số (batch_size,
   normalize_embeddings...) và trả về đúng hình dạng dữ liệu. Ưu điểm: chạy trong
   mili-giây, không phụ thuộc mạng/GPU, dùng được trong CI. Nhược điểm: không phát
   hiện được lỗi thật của chính model bge-m3.
2) Integration test (@pytest.mark.integration, TẮT mặc định qua pytest.ini): nạp
   model bge-m3 THẬT từ HuggingFace (~2.3GB, tải về lần đầu) và kiểm tra vector
   sinh ra có đúng 1024 chiều, đã được chuẩn hoá (norm ≈ 1.0).
   Chạy riêng bằng:  pytest tests/test_embedding.py -m integration
"""

import numpy as np
import pytest

import src.embedding as embedding_module
from src.embedding import Embedder, _resolve_device, get_embedder


class _FakeSentenceTransformer:
    """Giả lập SentenceTransformer thật, KHÔNG tải model nào cả — test chạy tức thì."""

    def __init__(self, model_name, device):
        self.model_name = model_name
        self.device = device
        self.max_seq_length = None
        self.encode_calls = []  # ghi lại mỗi lần encode() được gọi, để kiểm tra tham số

    def encode(self, texts, **kwargs):
        self.encode_calls.append((texts, kwargs))
        # trả về vector giả: mỗi đoạn văn -> 1 vector 4 chiều (chỉ để test hình dạng)
        return np.zeros((len(texts), 4), dtype=np.float32)


def test_resolve_device_falls_back_to_cpu_when_cuda_unavailable(monkeypatch):
    monkeypatch.setattr(embedding_module.torch.cuda, "is_available", lambda: False)
    assert _resolve_device("cuda") == "cpu"


def test_resolve_device_keeps_cpu_as_is():
    # Yêu cầu "cpu" thì không cần kiểm tra CUDA gì cả -> giữ nguyên "cpu"
    assert _resolve_device("cpu") == "cpu"


def test_embed_texts_passes_batch_size_and_normalize(monkeypatch):
    monkeypatch.setattr(embedding_module, "SentenceTransformer", _FakeSentenceTransformer)

    embedder = Embedder(model_name="fake-model", device="cpu")
    vectors = embedder.embed_texts(["a", "b", "c"], batch_size=2)

    assert vectors.shape == (3, 4)
    _texts, kwargs = embedder.model.encode_calls[0]
    assert kwargs["batch_size"] == 2
    assert kwargs["normalize_embeddings"] is True


def test_embed_query_returns_single_vector_not_batch(monkeypatch):
    monkeypatch.setattr(embedding_module, "SentenceTransformer", _FakeSentenceTransformer)

    embedder = Embedder(model_name="fake-model", device="cpu")
    vector = embedder.embed_query("một câu hỏi")

    assert vector.shape == (4,)  # 1 vector, KHÔNG phải (1, 4) — đã lấy [0]


def test_get_embedder_is_cached(monkeypatch):
    monkeypatch.setattr(embedding_module, "SentenceTransformer", _FakeSentenceTransformer)
    get_embedder.cache_clear()  # tránh ảnh hưởng từ lần chạy test khác

    first = get_embedder()
    second = get_embedder()

    assert first is second  # cùng một instance -> không nạp lại model
    get_embedder.cache_clear()  # dọn dẹp để không rò rỉ sang test khác


@pytest.mark.integration
def test_real_bge_m3_produces_normalized_1024d_vectors():
    """Chỉ chạy khi gọi rõ: pytest tests/test_embedding.py -m integration
    (sẽ tải model thật ~2.3GB từ HuggingFace trong lần chạy đầu tiên)."""
    embedder = Embedder()
    vectors = embedder.embed_texts(["Retrieval-Augmented Generation là gì?"])

    assert vectors.shape == (1, 1024)
    assert np.isclose(np.linalg.norm(vectors[0]), 1.0, atol=1e-3)
