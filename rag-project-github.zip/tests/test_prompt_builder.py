"""
Test độc lập cho prompt_builder.py — hàm thuần, không cần model/mạng.
"""

from src.prompt_builder import SYSTEM_INSTRUCTION, build_prompt


def _chunk(text, source="doc.pdf", page=3):
    return {"text": text, "metadata": {"source": source, "page": page}}


def test_build_prompt_includes_system_instruction_and_query():
    prompt = build_prompt("cau hoi test", [_chunk("noi dung A")])

    assert SYSTEM_INSTRUCTION in prompt
    assert "cau hoi test" in prompt


def test_build_prompt_numbers_chunks_in_order():
    chunks = [_chunk("noi dung A"), _chunk("noi dung B"), _chunk("noi dung C")]
    prompt = build_prompt("q", chunks)

    assert "[1]" in prompt
    assert "[2]" in prompt
    assert "[3]" in prompt
    assert prompt.index("[1]") < prompt.index("[2]") < prompt.index("[3]")


def test_build_prompt_cites_source_and_page():
    prompt = build_prompt("q", [_chunk("noi dung", source="paper.pdf", page=7)])

    assert "paper.pdf" in prompt
    assert "trang 7" in prompt


def test_build_prompt_hides_page_sentinel_for_non_pdf_documents():
    # page=-1 la quy uoc cho file .md/.txt (khong co so trang that)
    prompt = build_prompt("q", [_chunk("noi dung", source="note.md", page=-1)])

    assert "note.md" in prompt
    assert "trang -1" not in prompt


def test_build_prompt_context_appears_before_question():
    prompt = build_prompt("cau hoi cuoi cung", [_chunk("noi dung ngu canh")])

    assert prompt.index("noi dung ngu canh") < prompt.index("cau hoi cuoi cung")
