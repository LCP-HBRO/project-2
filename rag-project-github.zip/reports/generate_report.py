# -*- coding: utf-8 -*-
"""Sinh file Word báo cáo luận văn mini AI Knowledge Assistant bằng python-docx."""

import os
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

HEADER_BLUE = RGBColor(0x1F, 0x4E, 0x78)
HEADER_FILL = "1F4E78"
ALT_FILL = "F2F6FA"
CODE_COLOR = RGBColor(0xAD, 0x14, 0x75)
GRAY = RGBColor(0x66, 0x66, 0x66)
BLACK = RGBColor(0x00, 0x00, 0x00)

doc = Document()

# ---- Base style ----
normal = doc.styles["Normal"]
normal.font.name = "Calibri"
normal.font.size = Pt(11)

section = doc.sections[0]
section.top_margin = Cm(2.0)
section.bottom_margin = Cm(2.0)
section.left_margin = Cm(2.5)
section.right_margin = Cm(2.0)

# ============================================================================
# Helpers
# ============================================================================
def add_runs(paragraph, parts):
    """parts: list of (text, style) — style in {None,'b','i','code','gray','red'}."""
    for text, style in parts:
        run = paragraph.add_run(text)
        if style == "b":
            run.bold = True
        elif style == "i":
            run.italic = True
        elif style == "code":
            run.font.name = "Consolas"
            run.font.size = Pt(10)
            run.font.color.rgb = CODE_COLOR
        elif style == "gray":
            run.font.color.rgb = GRAY
            run.italic = True
        elif style == "red":
            run.bold = True
            run.font.color.rgb = RGBColor(0xC0, 0x00, 0x00)
    return paragraph


def para(parts_or_text, align="justify", space_after=8, space_before=0, line_spacing=1.15):
    p = doc.add_paragraph()
    p.alignment = {
        "justify": WD_ALIGN_PARAGRAPH.JUSTIFY,
        "center": WD_ALIGN_PARAGRAPH.CENTER,
        "left": WD_ALIGN_PARAGRAPH.LEFT,
    }[align]
    p.paragraph_format.space_after = Pt(space_after)
    p.paragraph_format.space_before = Pt(space_before)
    p.paragraph_format.line_spacing = line_spacing
    if isinstance(parts_or_text, str):
        add_runs(p, [(parts_or_text, None)])
    else:
        add_runs(p, parts_or_text)
    return p


def heading(text, level, page_break=False):
    h = doc.add_heading(text, level=level)
    h.paragraph_format.space_before = Pt(18 if level > 1 else 24)
    h.paragraph_format.space_after = Pt(6 if level > 1 else 12)
    h.paragraph_format.keep_with_next = True
    
    if level == 1 and page_break:
        h.paragraph_format.page_break_before = True
        
    for run in h.runs:
        run.font.name = "Calibri"
        if level == 1:
            run.font.color.rgb = HEADER_BLUE
            run.font.size = Pt(16)
        elif level == 2:
            run.font.color.rgb = RGBColor(0x2E, 0x5B, 0x82)
            run.font.size = Pt(13)
        else:
            run.font.color.rgb = BLACK
            run.font.size = Pt(11)
    return h


def bullet(parts_or_text, level=0):
    p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.line_spacing = 1.15
    if isinstance(parts_or_text, str):
        add_runs(p, [(parts_or_text, None)])
    else:
        add_runs(p, parts_or_text)
    return p


def set_cell_shading(cell, fill_hex):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:fill"), fill_hex)
    tc_pr.append(shd)


def add_table(headers, rows, widths_cm=None, caption=None):
    n = len(headers)
    t = doc.add_table(rows=1, cols=n)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = "Table Grid"

    hdr_cells = t.rows[0].cells
    for i, htext in enumerate(headers):
        hdr_cells[i].text = ""
        p = hdr_cells[i].paragraphs[0]
        run = p.add_run(htext)
        run.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        run.font.size = Pt(10)
        set_cell_shading(hdr_cells[i], HEADER_FILL)

    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, val in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.space_before = Pt(2)
            p.paragraph_format.line_spacing = 1.15
            run = p.add_run(str(val))
            run.font.size = Pt(9.5)
            if ri % 2 == 1:
                set_cell_shading(cells[i], ALT_FILL)

    if widths_cm:
        for row in t.rows:
            for i, w in enumerate(widths_cm):
                row.cells[i].width = Cm(w)
                
    if caption:
        p_cap = doc.add_paragraph()
        p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p_cap.paragraph_format.space_before = Pt(4)
        p_cap.paragraph_format.space_after = Pt(12)
        r = p_cap.add_run(caption)
        r.italic = True
        r.font.size = Pt(9)
        r.font.color.rgb = GRAY
        
    return t


def add_callout(text, title="Lưu ý:"):
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = "Normal Table"
    
    cell = t.rows[0].cells[0]
    set_cell_shading(cell, ALT_FILL)
    cell.width = Cm(15.5)
    
    # Thiết lập viền trái dày màu xanh dương, các viền khác rỗng
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_borders = OxmlElement("w:tcBorders")
    
    left = OxmlElement("w:left")
    left.set(qn("w:val"), "single")
    left.set(qn("w:sz"), "24")  # 3pt
    left.set(qn("w:space"), "0")
    left.set(qn("w:color"), HEADER_FILL)
    tc_borders.append(left)
    
    for side in ["top", "bottom", "right"]:
        border = OxmlElement(f"w:{side}")
        border.set(qn("w:val"), "none")
        tc_borders.append(border)
        
    tc_pr.append(tc_borders)
    
    p = cell.paragraphs[0]
    p.paragraph_format.left_indent = Cm(0.3)
    p.paragraph_format.right_indent = Cm(0.3)
    p.paragraph_format.space_before = Pt(4)
    p.paragraph_format.space_after = Pt(4)
    
    r_title = p.add_run(f"{title} ")
    r_title.bold = True
    r_title.font.size = Pt(10)
    r_title.font.color.rgb = HEADER_BLUE
    
    r_text = p.add_run(text)
    r_text.font.size = Pt(10)
    r_text.font.color.rgb = BLACK
    
    p_after = doc.add_paragraph()
    p_after.paragraph_format.space_after = Pt(4)
    p_after.paragraph_format.space_before = Pt(0)


def add_pseudocode(title, lines):
    t = doc.add_table(rows=1, cols=1)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.style = "Table Grid"
    
    cell = t.rows[0].cells[0]
    set_cell_shading(cell, "F8F9FA")
    cell.width = Cm(15.5)
    
    # Caption cho Pseudocode
    p_cap = doc.add_paragraph()
    p_cap.alignment = WD_ALIGN_PARAGRAPH.LEFT
    p_cap.paragraph_format.space_before = Pt(6)
    p_cap.paragraph_format.space_after = Pt(2)
    p_cap.paragraph_format.keep_with_next = True
    r_cap = p_cap.add_run(title)
    r_cap.bold = True
    r_cap.font.size = Pt(10)
    r_cap.font.color.rgb = HEADER_BLUE
    
    # Ghi nội dung mã giả
    first = True
    for line in lines:
        if first:
            p = cell.paragraphs[0]
            first = False
        else:
            p = cell.add_paragraph()
        p.paragraph_format.space_after = Pt(1)
        p.paragraph_format.space_before = Pt(1)
        p.paragraph_format.line_spacing = 1.0
        
        # Đếm số khoảng trắng thụt lề đầu dòng
        indent_level = len(line) - len(line.lstrip())
        run = p.add_run(line)
        run.font.name = "Consolas"
        run.font.size = Pt(9.5)
        run.font.color.rgb = BLACK
        p.paragraph_format.left_indent = Cm(indent_level * 0.15)
        
    p_after = doc.add_paragraph()
    p_after.paragraph_format.space_after = Pt(4)
    p_after.paragraph_format.space_before = Pt(0)


def add_toc_field(field_type="TOC"):
    """Chèn field TOC/LOF/LOT — Word sẽ tự điền khi mở file hoặc F9."""
    p = doc.add_paragraph()
    run = p.add_run()
    fld_char1 = OxmlElement("w:fldChar")
    fld_char1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    
    if field_type == "TOC":
        instr_text.text = 'TOC \\o "1-3" \\h \\z \\u'
        label = "(Mở file trong MS Word và nhấn F9 để cập nhật Mục lục tự động)"
    elif field_type == "LOF":
        instr_text.text = 'TOC \\h \\z \\c "Hình"'
        label = "(Mở file trong MS Word và nhấn F9 để cập nhật Danh mục hình vẽ)"
    elif field_type == "LOT":
        instr_text.text = 'TOC \\h \\z \\c "Bảng"'
        label = "(Mở file trong MS Word và nhấn F9 để cập nhật Danh mục bảng biểu)"
        
    fld_char2 = OxmlElement("w:fldChar")
    fld_char2.set(qn("w:fldCharType"), "separate")
    fld_char3 = OxmlElement("w:t")
    fld_char3.text = label
    fld_char4 = OxmlElement("w:fldChar")
    fld_char4.set(qn("w:fldCharType"), "end")

    r_element = run._r
    r_element.append(fld_char1)
    r_element.append(instr_text)
    r_element.append(fld_char2)
    r_element.append(fld_char3)
    r_element.append(fld_char4)


def add_figure(path, caption, width_cm=15.0):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(8)
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.keep_with_next = True
    
    try:
        p.add_run().add_picture(path, width=Cm(width_cm))
    except Exception as e:
        r = p.add_run(f"[Hình ảnh lỗi hoặc không tìm thấy: {path}]")
        r.bold = True
        r.font.color.rgb = RGBColor(0xC0, 0x00, 0x00)
        
    p_cap = doc.add_paragraph()
    p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_cap.paragraph_format.space_before = Pt(2)
    p_cap.paragraph_format.space_after = Pt(12)
    r_cap = p_cap.add_run(caption)
    r_cap.italic = True
    r_cap.font.size = Pt(9)
    r_cap.font.color.rgb = GRAY


def page_break():
    doc.add_page_break()


# ============================================================================
# TITLE PAGE (HUST STYLE)
# ============================================================================
univ_p = doc.add_paragraph()
univ_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
univ_p.paragraph_format.space_after = Pt(2)
r = univ_p.add_run("ĐẠI HỌC BÁCH KHOA HÀ NỘI\n")
r.bold = True
r.font.size = Pt(13)
r.font.color.rgb = BLACK

dept_p = doc.add_paragraph()
dept_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
dept_p.paragraph_format.space_after = Pt(4)
r = dept_p.add_run("TRƯỜNG CÔNG NGHỆ THÔNG TIN VÀ TRUYỀN THÔNG\n")
r.bold = True
r.font.size = Pt(13)
r.font.color.rgb = HEADER_BLUE

# Thêm đường viền trang trí dưới tiêu đề trường học
p_line = doc.add_paragraph()
p_line.alignment = WD_ALIGN_PARAGRAPH.CENTER
p_line.paragraph_format.space_after = Pt(24)
p_line_run = p_line.add_run("❖  ❖  ❖  ❖  ❖  ❖  ❖  ❖  ❖  ❖  ❖")
p_line_run.font.color.rgb = HEADER_BLUE
p_line_run.font.size = Pt(10)

for _ in range(3):
    doc.add_paragraph()

t1 = doc.add_paragraph()
t1.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = t1.add_run("BÁO CÁO DỰ ÁN MÔN HỌC (PROJECT 2)\n")
r.bold = True
r.font.size = Pt(14)
r.font.color.rgb = GRAY

t2 = doc.add_paragraph()
t2.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = t2.add_run("HỆ THỐNG TRỢ LÝ AI TRA CỨU TRI THỨC HỌC MÁY VÀ NLP\n")
r.bold = True
r.font.size = Pt(20)
r.font.color.rgb = HEADER_BLUE

t3 = doc.add_paragraph()
t3.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = t3.add_run("Tối ưu hóa chiến lược phân mảnh văn bản và tìm kiếm lai kết hợp bộ tái xếp hạng trên tài nguyên giới hạn")
r.italic = True
r.font.size = Pt(12)

for _ in range(5):
    doc.add_paragraph()

# Bảng thông tin sinh viên và giảng viên được định vị lùi vào lề trái
meta_p = doc.add_paragraph()
meta_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
meta_p.paragraph_format.left_indent = Cm(2.5)
meta_p.paragraph_format.line_spacing = 1.3
meta_p.paragraph_format.space_after = Pt(24)

r = meta_p.add_run("Sinh viên thực hiện:  ")
r.bold = True
meta_p.add_run("Trịnh Hoàng Anh\n")

r = meta_p.add_run("Mã số sinh viên:     ")
r.bold = True
meta_p.add_run("20235476\n")

r = meta_p.add_run("Giảng viên hướng dẫn: ")
r.bold = True
meta_p.add_run("PGS. TS. Nguyễn Thị Kim Anh\n")

r = meta_p.add_run("Lớp/Học kỳ:          ")
r.bold = True
meta_p.add_run("Kỳ 2025.2 — Trường CNTT&TT - ĐHBK Hà Nội\n")

for _ in range(3):
    doc.add_paragraph()

date_p = doc.add_paragraph()
date_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = date_p.add_run("Hà Nội, Tháng 07 năm 2026")
r.font.size = Pt(11)

page_break()

# ============================================================================
# TÓM TẮT DỰ ÁN (ABSTRACT)
# ============================================================================
heading("Tóm tắt dự án (Abstract)", 1)

para([
    ("Báo cáo này nghiên cứu và hiện thực hóa một trợ lý AI hỏi-đáp chuyên sâu (AI Knowledge Assistant) dựa trên kiến trúc ", None),
    ("Retrieval-Augmented Generation (RAG)", "b"),
    (" tự triển khai từ đầu. "
     "Mục tiêu cốt lõi của nghiên cứu là làm chủ toàn bộ thiết kế hệ thống, phân tích và vượt qua các giới hạn hiệu năng thực tế trên một thiết bị cá nhân có cấu hình tài nguyên giới hạn (NVIDIA RTX 3050 Laptop 6GB VRAM). "
     "Chúng tôi đề xuất một quy trình nạp tài liệu tự động hỗ trợ đồng thời định dạng văn bản PDF học thuật phân trang và file Word (.docx). "
     "Trong đó, loader sử dụng thư viện PyMuPDF trích xuất văn bản theo khối để khắc phục lỗi mất ranh giới đoạn văn (\\n\\n) đặc thù của các parser thông thường, khôi phục hiệu quả của chiến lược cắt nhỏ đệ quy (Recursive Character Chunker).", None)
])

para([
    ("Để tối ưu hóa chất lượng truy xuất dữ liệu, hệ thống tích hợp giải thuật tìm kiếm lai (Hybrid Search) kết hợp tìm kiếm ngữ nghĩa Dense Vector thông qua mô hình đa ngôn ngữ ", None),
    ("BAAI/bge-m3", "b"),
    (" và tìm kiếm từ khóa BM25 in-memory xây dựng trực tiếp trên corpus lưu trữ của ChromaDB. Kết quả của hai công cụ được kết hợp thông qua thuật toán ", None),
    ("Reciprocal Rank Fusion (RRF)", "b"),
    (" trước khi chuyển qua bộ tái xếp hạng Cross-Encoder ", None),
    ("BAAI/bge-reranker-v2-m3", "b"),
    (" chạy bằng GPU CUDA.", None)
])

para([
    ("Qua quá trình thực nghiệm đánh giá định lượng nghiêm ngặt trên bộ câu hỏi vàng 38 câu (bao gồm câu hỏi factual, câu hỏi nhiễu khó phân biệt, câu hỏi ngoài phạm vi và câu hỏi bằng tiếng Việt), chúng tôi đã phát hiện hiệu ứng \"unlucky batch\" trong Cross-Encoder khiến độ trễ truy vấn tăng vọt lên tới 46.1 giây trên GPU khi pad dữ liệu trong batch size mặc định lớn. "
     "Bằng cách điều chỉnh giảm batch size xuống 4, độ trễ được kiểm soát ổn định ở mức trung bình 1.92 giây (giảm 24 lần). "
     "Bên cạnh đó, việc xây dựng tập đối chứng cấp trang (expected_page) thay vì cấp file thông thường đã vạch trần hiện tượng suy giảm vùng phủ cấp trang (hit_rate_page giảm từ 1.000 xuống 0.909) khi bật Reranker. "
     "Đây là cơ sở để chúng tôi đề xuất giải thuật đa dạng hóa MMR trong tương lai.", None)
])

para([
    ("Hệ thống sinh câu trả lời được thử nghiệm đối chứng giữa mô hình chạy cục bộ Qwen2.5-1.5B (giới hạn ở 1.5B để tránh tràn bộ nhớ khi chạy đồng thời với Embedding và Reranker trên GPU) và mô hình đám mây Gemini API, sử dụng CHUNG một pipeline truy xuất/rerank cho mỗi câu hỏi để đảm bảo phép so sánh công bằng. "
     "Kết quả cho thấy Qwen2.5-1.5B chỉ từ chối đúng 3/5 (refusal_rate = 0.60) câu hỏi ngoài phạm vi tài liệu và bịa đặt thông tin (ảo giác) ở 2/5 câu hỏi còn lại do hạn chế kích thước tham số, trong khi Gemini API từ chối đúng toàn bộ 5/5 (refusal_rate = 1.00) và không ghi nhận hiện tượng ảo giác nào trên tập câu hỏi thử nghiệm này.", None)
])

page_break()

# ============================================================================
# TABLE OF CONTENTS / LIST OF FIGURES / LIST OF TABLES
# ============================================================================
heading("Mục lục", 1)
add_toc_field("TOC")
page_break()

heading("Danh mục hình vẽ", 1)
add_toc_field("LOF")
page_break()

heading("Danh mục bảng biểu", 1)
add_toc_field("LOT")
page_break()

# ============================================================================
# CHAPTER 1: INTRODUCTION
# ============================================================================
heading("Chapter 1. Introduction", 1)

heading("1.1. Background", 2)
para([
    ("Trong những năm gần đây, sự trỗi dậy của các Mô hình Ngôn ngữ Lớn (Large Language Models - LLM) dựa trên kiến trúc Transformer đã tạo ra một bước ngoặt lớn cho lĩnh vực Xử lý Ngôn ngữ Tự nhiên (NLP). "
     "Các mô hình này thể hiện khả năng vượt trội trong việc hiểu văn bản, lập luận và sinh câu trả lời tự nhiên. "
     "Tuy nhiên, khi áp dụng LLM vào các tác vụ đòi hỏi tri thức chuyên sâu và độ chính xác cao (Knowledge-Intensive QA), các hệ thống này thường đối mặt với thách thức lớn mang tên ", None),
    ("Hallucination (Hiện tượng ảo giác)", "b"),
    (" — sinh ra các câu trả lời trôi chảy nhưng hoàn toàn sai lệch thực tế. "
     "Hiện tượng này xảy ra do mô hình chỉ học các phân phối xác suất từ dữ liệu huấn luyện tĩnh và thiếu khả năng tự xác minh nguồn gốc thông tin trong thời gian thực.", None)
])

para([
    ("Để khắc phục hạn chế này, kiến trúc ", None),
    ("Retrieval-Augmented Generation (RAG)", "b"),
    (" ra đời như một giải pháp kết hợp sức mạnh lập luận của LLM với độ tin cậy của các hệ thống tìm kiếm thông tin (Information Retrieval). "
     "Thay vì chỉ dựa vào tri thức đóng băng trong tham số mạng, RAG thực hiện truy xuất các tài liệu liên quan từ một cơ sở tri thức ngoài để làm ngữ cảnh phụ trợ (context), dẫn đường cho LLM sinh câu trả lời.", None)
])

heading("1.2. Problem Statement", 2)
para([
    ("Mặc dù ý tưởng của RAG rất rõ ràng, việc triển khai một hệ thống RAG thực tế trong môi trường sản xuất hoặc trên các thiết bị cá nhân gặp phải rất nhiều nút thắt cổ chai về kỹ thuật. "
     "Thứ nhất, việc trích xuất văn bản từ các định dạng tài liệu thực tế như PDF hay Word (.docx) thường bị lỗi cấu trúc, làm mất ranh giới đoạn văn tự nhiên (như ký tự ngắt dòng kép \\n\\n), dẫn đến việc phân mảnh dữ liệu (chunking) không còn giữ được tính toàn vẹn ngữ nghĩa. "
     "Thứ hai, việc sử dụng các mô hình embedding và reranker cục bộ trên GPU cá nhân giới hạn bộ nhớ (ví dụ GPU RTX 3050 Laptop chỉ có 6GB VRAM) dễ dẫn đến lỗi tràn bộ nhớ (Out-Of-Memory - OOM) hoặc độ trễ phản hồi quá lớn (latency vọt lên hàng chục giây mỗi truy vấn), phá hỏng trải nghiệm người dùng.", None)
])

para("Do đó, việc nghiên cứu tối ưu hóa từng thành phần của RAG, từ khâu trích xuất, phân mảnh dữ liệu, tìm kiếm lai (hybrid), tái xếp hạng (rerank) cho đến tinh chỉnh prompt sinh dữ liệu trên một tài nguyên phần cứng giới hạn là một bài toán thực tiễn cấp thiết.")

heading("1.3. Objectives", 2)
para("Dự án được thiết lập nhằm đạt được các mục tiêu cụ thể sau:")
bullet("Xây dựng một pipeline RAG đầu-cuối hoạt động ổn định, tự triển khai hoàn toàn bằng Python để làm chủ thiết kế hệ thống.")
bullet("Thiết lập và đối chứng hiệu quả của 3 chiến lược chunking (Fixed-size, Recursive, Semantic Chunker) và 3 chế độ tìm kiếm (Dense, Lexical BM25, Hybrid RRF).")
bullet("Phân tích định lượng và khắc phục các vấn đề kỹ thuật liên quan đến bộ nhớ GPU VRAM và độ trễ phản hồi thông qua đo đạc thực nghiệm thật.")
bullet("Cải thiện tính minh bạch giải thích (explainability) của hệ thống thông qua giao diện trực quan hóa các kết quả tìm kiếm trung gian.")

heading("1.4. Contributions", 2)
para("Các đóng góp chính của dự án bao gồm:")
bullet([("Hiện thực hóa hệ thống RAG thủ công tối ưu hóa cao:", "b"), (" Viết code sạch cho toàn bộ pipeline từ loader, chunker đệ quy và ngữ nghĩa, BM25Searcher, Reranker và Prompt Builder.", None)])
bullet([("Khắc phục lỗi mất ranh giới văn bản và unlucky batch:", "b"), (" Giải quyết triệt để lỗi mất ranh giới đoạn của PyMuPDF và giảm độ trễ reranking từ 46.1 giây xuống 1.92 giây nhờ tối ưu batch size.", None)])
bullet([("Xây dựng bộ đánh giá định lượng đối chứng:", "b"), (" Thiết lập bộ 38 câu hỏi vàng phân loại chi tiết và đưa ra chỉ số hit_rate_page/mrr_page đột phá để đánh giá chất lượng ở cấp độ trang thực tế.", None)])
bullet([("Giao diện Streamlit trực quan hóa:", "b"), (" Cung cấp bảng điều khiển hiển thị rõ ràng cơ chế tính toán điểm số lai RRF và Cross-Encoder.", None)])

page_break()

# ============================================================================
# CHAPTER 2: BACKGROUND
# ============================================================================
heading("Chapter 2. Background and Literature Review", 1)

heading("2.1. Large Language Models", 2)
para("Các Mô hình Ngôn ngữ Lớn (LLM) hiện đại chủ yếu dựa trên kiến trúc Transformer (Vaswani et al., 2017). Trong đó, các dòng mô hình sinh văn bản phổ biến thường sử dụng nhánh Decoder-only (chỉ có bộ giải mã, ví dụ như dòng GPT của OpenAI, LLaMA của Meta, và Qwen của Alibaba). Cơ chế hoạt động cốt lõi là Attention Mechanism (Cơ chế chú ý), cụ thể là Self-Attention, cho phép mỗi token trong văn bản tính toán sự liên quan với toàn bộ các token khác trong ngữ cảnh.")

para("Tuy nhiên, LLM bị giới hạn bởi một cửa sổ ngữ cảnh (Context Window) cố định. Mặc dù các mô hình gần đây tuyên bố hỗ trợ lên tới 32k hay 128k token, việc nhồi nhét quá nhiều thông tin không liên quan vào ngữ cảnh dẫn tới hiện tượng mô hình bị bỏ sót thông tin ở giữa (Lost in the Middle) và làm tăng chi phí tính toán theo hàm mũ. Do đó, việc chọn lọc thông tin chính xác trước khi đưa vào LLM vẫn là hướng tiếp cận tối ưu nhất.")

heading("2.2. Retrieval-Augmented Generation", 2)
para("Khái niệm RAG lần đầu tiên được giới thiệu bởi Lewis et al. (2020). Mô hình RAG hoạt động thông qua hai giai đoạn chính: (1) Retrieval (Truy xuất) - Tìm kiếm các tài liệu liên quan nhất từ kho dữ liệu dựa trên truy vấn của người dùng; (2) Generation (Sinh câu trả lời) - LLM đọc câu hỏi ban đầu cùng với các tài liệu đã truy xuất để tổng hợp thành câu trả lời cuối cùng. Mô hình này giúp giảm thiểu việc LLM bịa đặt thông tin và cho phép cập nhật kiến thức của hệ thống dễ dàng bằng cách cập nhật cơ sở dữ liệu vector mà không cần huấn luyện lại mô hình ngôn ngữ.")

heading("2.3. BM25 Lexical Retrieval", 2)
para("BM25 (Best Matching 25) là thuật toán xếp hạng tìm kiếm từ khóa phổ biến dựa trên mô hình không gian vector và tần suất xuất hiện từ khóa. Công thức tính điểm BM25 cho tài liệu $D$ với truy vấn $Q$ chứa các từ khóa $q_i$ được biểu diễn như sau:")

# Biểu diễn công thức toán học BM25
para([
    ("Score(D, Q) = ∑ [ IDF(q_i) * (f(q_i, D) * (k_1 + 1)) / (f(q_i, D) + k_1 * (1 - b + b * (|D| / avgdl))) ]", "code")
], align="center")

para("Trong đó:")
bullet([("f(q_i, D)", "code"), (" là tần suất xuất hiện của từ khóa q_i trong tài liệu D.", None)])
bullet([("|D| / avgdl", "code"), (" là tỷ lệ độ dài của tài liệu D so với độ dài trung bình của toàn bộ các tài liệu trong corpus.", None)])
bullet([("k_1", "code"), (" là tham số điều chỉnh độ bão hòa của tần suất từ khóa (thường chọn từ 1.2 đến 2.0).", None)])
bullet([("b", "code"), (" là tham số điều chỉnh mức độ phạt độ dài tài liệu (thường chọn là 0.75).", None)])

para([
    ("Ưu điểm: ", "b"),
    ("BM25 cực kỳ mạnh mẽ trong việc tìm kiếm các từ khóa chính xác, thuật ngữ kỹ thuật viết tắt (ví dụ: LoRA, PEFT) và các mã số hiệu tài liệu mà mô hình embedding biểu diễn ngữ nghĩa có thể bỏ sót.", None)
])
para([
    ("Nhược điểm: ", "b"),
    ("BM25 hoàn toàn không hiểu được quan hệ đồng nghĩa hoặc cấu trúc ngữ nghĩa phức tạp nếu từ khóa không khớp chính xác.", None)
])

heading("2.4. Dense Retrieval", 2)
para("Tìm kiếm ngữ nghĩa (Dense Retrieval) biểu diễn cả truy vấn và tài liệu dưới dạng các vector mật độ cao trong không gian đa chiều (thường là 768 hoặc 1024 chiều) thông qua một mô hình Bi-Encoder (như BGE-M3). Sự tương đồng ngữ nghĩa giữa truy vấn $q$ và tài liệu $d$ được tính bằng Cosine Similarity:")

para([
    ("Similarity(q, d) = (q • d) / (||q|| * ||d||)", "code")
], align="center")

para("Phương pháp này có ưu điểm vượt trội trong việc hiểu ý định người dùng ngay cả khi họ dùng các từ đồng nghĩa hoặc câu hỏi có cách diễn đạt hoàn toàn khác với tài liệu nguồn. Tuy nhiên, nó dễ bị nhiễu và hoạt động kém khi gặp các từ khóa hiếm hoặc thuật ngữ chuyên ngành quá sâu.")

heading("2.5. Reciprocal Rank Fusion", 2)
para("RRF là giải pháp không giám sát hiệu quả nhất để kết hợp các danh sách xếp hạng từ nhiều công cụ tìm kiếm độc lập (như BM25 và Dense Search). Điểm số RRF của tài liệu $d$ được tính bằng:")

para([
    ("RRF_Score(d ∈ D) = ∑_{m ∈ M} [ 1 / (k + r_m(d)) ]", "code")
], align="center")

para("Trong đó $M$ là tập hợp các bộ truy xuất (BM25 và Dense), $r_m(d)$ là thứ hạng (rank) của tài liệu $d$ trong bộ truy xuất $m$, và $k$ là một hằng số làm mịn (thường đặt là 60).")

add_callout(
    "Giả sử tài liệu A xếp thứ 1 trong kết quả Dense và thứ 3 trong BM25. Điểm RRF(A) = 1/(60+1) + 1/(60+3) = 0.01639 + 0.01587 = 0.03226. "
    "Tài liệu B xếp thứ 2 trong cả hai danh sách. Điểm RRF(B) = 1/(60+2) + 1/(60+2) = 0.01612 + 0.01612 = 0.03224. "
    "Kết quả là tài liệu A được xếp hạng cao hơn tài liệu B một cách hợp lý.",
    "Ví dụ số học minh họa RRF:"
)

heading("2.6. Cross Encoder Reranking", 2)
para("Khác với Bi-Encoder sinh vector độc lập cho truy vấn và tài liệu, Cross-Encoder đưa đồng thời cả truy vấn và tài liệu vào mạng Transformer để chúng tương tác trực tiếp qua toàn bộ các lớp tự chú ý (full self-attention). Cơ chế này giúp Cross-Encoder nắm bắt được mối quan hệ tinh tế giữa truy vấn và ngữ cảnh, mang lại độ chính xác cao hơn nhiều. Tuy nhiên, do chi phí tính toán cực kỳ lớn, Cross-Encoder chỉ được dùng làm bộ lọc giai đoạn hai (Reranker) để xếp hạng lại top-k ứng viên tốt nhất đã được truy xuất nhanh từ giai đoạn một.")

heading("2.7. ChromaDB Vector DB", 2)
para("ChromaDB là cơ sở dữ liệu vector gọn nhẹ mã nguồn mở hỗ trợ lưu trữ bền vững. Nó sử dụng cấu trúc chỉ mục HNSW (Hierarchical Navigable Small World) để hỗ trợ tìm kiếm lân cận gần đúng (Approximate Nearest Neighbor - ANN) với độ phức tạp thời gian O(log N), đáp ứng khả năng mở rộng dữ liệu lên hàng triệu vector.")

page_break()

# ============================================================================
# CHAPTER 3: DATASET
# ============================================================================
heading("Chapter 3. Dataset Characteristics", 1)

heading("3.1. Overview", 2)
para([
    ("Tập dữ liệu của dự án được thiết kế hỗn hợp để kiểm tra khả năng xử lý đa định dạng của hệ thống. Dữ liệu bao gồm: (1) ", None),
    ("17 paper học thuật nền tảng", "b"),
    (" dạng PDF, tải trực tiếp từ arXiv bằng script ", None),
    ("scripts/download_corpus.py", "code"),
    (" (Attention Is All You Need, BERT, GPT-3, InstructGPT, RAG gốc, Self-RAG, HyDE, Lost in the Middle, Sentence-BERT, DPR, BGE-M3, FAISS, Chain-of-Thought, LoRA, ReAct, Toolformer, Mistral 7B — tổng cộng 434 trang PDF, mỗi trang được nạp thành một Document riêng); (2) ", None),
    ("201 tài liệu tóm tắt nghiên cứu NLP", "b"),
    (" dạng file Word (.docx), mỗi file là một Document (không chia trang). Các file này có tên tự sinh dạng ", None),
    ("nlp_paper_<n>.docx", "code"),
    (", nội dung là các đoạn Abstract/Full Text ngành NLP, chuyển đổi từ tập dữ liệu ", None),
    ("MaartenGr/arxiv_nlp", "code"),
    (" trên HuggingFace (chứa token @xcite/@xmath đặc trưng của một corpus khoa học đã qua tiền xử lý). Quy mô ban đầu dự kiến của khối dữ liệu này là 1.000 tài liệu, nhưng đã được RÚT GỌN xuống còn 201 tài liệu để phù hợp với năng lực xử lý thực tế của phần cứng cá nhân (embedding + chunking 1.000 file trên GPU 6GB VRAM là không khả thi trong thời gian hợp lý cho một dự án môn học). Lưu ý: dự án hiện KHÔNG có script tải/chuyển đổi hay file manifest đi kèm cho bước này (được thực hiện thủ công), nên 201 file DOCX không được trích dẫn riêng lẻ trong danh mục tài liệu tham khảo mà chỉ mô tả gộp như một khối dữ liệu chung.", None),
])

heading("3.2. Dataset Statistics", 2)
para([
    ("Toàn bộ số liệu dưới đây được đo trực tiếp trên dữ liệu hiện có trong ", None),
    ("data/documents/", "code"),
    (" bằng cách chạy ", None),
    ("python -m src.loader", "code"),
    (" (đếm Document) và hàm ", None),
    ("chunk_documents()", "code"),
    (" của ", None),
    ("src/chunker.py", "code"),
    (" cho từng chiến lược (không suy đoán/ước tính):", None),
])

add_table(
    ["Chỉ số thống kê", "Corpus PDF (arXiv)", "Corpus Word (NLP abstracts)", "Tổng cộng hệ thống"],
    [
        ["Số lượng tệp", "17 file PDF", "201 file DOCX", "218 tệp"],
        ["Dung lượng đĩa (tổng thư mục)", "—", "—", "~40 MB"],
        ["Số Document sau loader", "434 (1 Document/trang)", "201 (1 Document/file)", "635 Document"],
        ["Định dạng tệp tin", ".pdf", ".docx", "Hỗn hợp (.pdf + .docx)"],
        ["Ngôn ngữ chủ đạo", "Tiếng Anh chuyên ngành AI/RAG", "Tiếng Anh chuyên ngành NLP", "Tiếng Anh"],
        ["Số chunk — Fixed-size", "—", "—", "3.421 chunks"],
        ["Số chunk — Recursive Character", "—", "—", "3.570 chunks"],
        ["Số chunk — Semantic", "—", "—", "6.324 chunks (~241 từ/chunk)"],
    ],
    widths_cm=[4.5, 3.8, 3.8, 3.4],
    caption="Table 1: Bảng thống kê định lượng tập dữ liệu thực nghiệm (đo thực tế trên corpus hiện hành, không phải ước tính)"
)

para([
    ("Nhận xét: ", "b"),
    ("Semantic Chunking sinh ra NHIỀU chunk hơn hẳn hai chiến lược còn lại (6.324 so với ~3.400-3.600) trên corpus này — ngược lại với trực giác thông thường rằng semantic chunking thường gộp thành các đoạn dài, thuần chủ đề. Nguyên nhân là phần lớn 201 tài liệu DOCX là các đoạn tóm tắt (abstract) khoa học ngắn nhưng chứa nhiều câu chuyển ý/chủ đề liên tiếp (do bị cắt rời khỏi ngữ cảnh gốc), khiến thuật toán phát hiện ranh giới theo percentile khoảng cách ngữ nghĩa (SEMANTIC_BREAKPOINT_PERCENTILE=95.0) tách ra nhiều điểm gãy nhỏ hơn dự kiến.", None),
])

heading("3.3. Document Distribution", 2)
para("Về mặt nội dung khoa học, corpus được phân bổ quanh các chủ đề cốt lõi:")
bullet([("Kiến trúc mạng Neural & Attention:", "b"), (" Các paper nền tảng như Attention Is All You Need, BERT, GPT-3, Mistral 7B.", None)])
bullet([("Retrieval-Augmented Generation:", "b"), (" Paper RAG gốc, Self-RAG, HyDE, Lost in the Middle, Dense Passage Retrieval.", None)])
bullet([("Công cụ truy xuất và định vị:", "b"), (" BGE-M3 Embeddings, Sentence-BERT, FAISS (billion-scale similarity search).", None)])
bullet([("Lập luận và Kỹ nghệ Prompt:", "b"), (" Chain of Thought, ReAct (Reason and Act), Toolformer, LoRA, InstructGPT/RLHF.", None)])
bullet([("Kho tri thức NLP mở rộng:", "b"), (" 201 đoạn tóm tắt nghiên cứu NLP (chủ đề chưa được phân loại chi tiết vì thiếu metadata nguồn), dùng chủ yếu để tăng quy mô/độ nhiễu của corpus khi đánh giá retrieval trên một kho dữ liệu lớn hơn thực tế.", None)])

page_break()

# ============================================================================
# CHAPTER 4: SYSTEM DESIGN
# ============================================================================
heading("Chapter 4. System Design", 1)

heading("4.1. System Pipeline Architecture", 2)
para("Hệ thống được thiết kế theo luồng kiến trúc chặt chẽ từ bước nạp dữ liệu offline cho đến truy vấn online của người dùng:")

# Vẽ sơ đồ kiến trúc ASCII
para([
    ("               +-------------------------------------------+\n"
     "               |          data/documents/ (PDF, DOCX)      |\n"
     "               +---------------------+---------------------+\n"
     "                                     |\n"
     "                                     v (loader.py)\n"
     "                       +-------------+-------------+\n"
     "                       | Document Blocks Extraction |\n"
     "                       +-------------+-------------+\n"
     "                                     |\n"
     "                                     v (chunker.py)\n"
     "                       +-------------+-------------+\n"
     "                       |  Semantic Segment Chunker |\n"
     "                       +-------------+-------------+\n"
     "                                     |\n"
     "                                     v (embedding.py / BGE-M3 GPU)\n"
     "                       +-------------+-------------+\n"
     "                       |  Vector & Metadata Gener. |\n"
     "                       +-------------+-------------+\n"
     "                                     |\n"
     "                                     v\n"
     "                       +-------------+-------------+\n"
     "                       |    Persistent ChromaDB    |\n"
     "                       +-------------+-------------+\n"
     "                                     |\n"
     "      +------------------------------+------------------------------+\n"
     "      | (Lexical Path)                               | (Dense Path) \n"
     "      v                                              v              \n"
     "+-----+------+                                 +-----+------+\n"
     "| BM25 Index |                                 | HNSW Vector|\n"
     "+-----+------+                                 +-----+------+\n"
     "      |                                              |              \n"
     "      +------------------------------+------------------------------+\n"
     "                                     | (RRF Fusion)\n"
     "                                     v\n"
     "                       +-------------+-------------+\n"
     "                       |   Top-k Hybrid Candidates  |\n"
     "                       +-------------+-------------+\n"
     "                                     |\n"
     "                                     v (reranker.py / Cross-Encoder)\n"
     "                       +-------------+-------------+\n"
     "                       |    Top-n Reranked Chunks  |\n"
     "                       +-------------+-------------+\n"
     "                                     |\n"
     "                                     v (prompt_builder.py)\n"
     "                       +-------------+-------------+\n"
     "                       |    Context-Augment Prompt |\n"
     "                       +-------------+-------------+\n"
     "                                     |\n"
     "                                     v (llm.py / Qwen or Gemini)\n"
     "                       +-------------+-------------+\n"
     "                       |     Final Answer Output   |\n"
     "                       +---------------------------+", "code")
], align="center")

heading("4.2. Detailed Components", 2)

heading("4.2.1. Document Loader", 3)
para("Module loader.py có nhiệm vụ đọc và chuẩn hóa dữ liệu đầu vào. Đối với file PDF, loader sử dụng PyMuPDF bóc tách tài liệu theo dạng block để tránh việc các dòng văn bản bị ngắt nửa chừng. Đối với file Word (.docx), loader duyệt qua các paragraph của tài liệu và ghép nối bằng dấu ngắt dòng kép \\n\\n để bảo đảm tính toàn vẹn của các đoạn văn.")

heading("4.2.2. Text Chunker", 3)
para("Hệ thống hỗ trợ 3 chiến lược chunking. Fixed Chunker cắt văn bản theo số từ cố định. Recursive Chunker cố gắng cắt theo các ký tự phân tách từ lớn đến nhỏ (\\n\\n, \\n, khoảng trắng). Semantic Chunker sử dụng mô hình embedding để tạo vector cho từng câu, tính toán khoảng cách Cosine giữa các câu liên tiếp và thực hiện cắt chunk tại các điểm gãy có khoảng cách vượt quá ngưỡng động (percentile threshold), giúp các chunk luôn thuần nhất về mặt chủ đề ngữ nghĩa.")

heading("4.2.3. Embedding Generator", 3)
para("Sử dụng BGE-M3 (BAAI General Embedding) đa ngôn ngữ chạy trên GPU CUDA. Điểm đặc biệt của BGE-M3 là khả năng hỗ trợ độ dài ngữ cảnh lên tới 8192 token và sinh vector embedding chuẩn hóa L2, cho phép tính toán khoảng cách Cosine nhanh chóng thông qua phép nhân vô hướng (Dot Product).")

heading("4.2.4. Hybrid Retriever", 3)
para("Sử dụng cơ chế tìm kiếm song song: một nhánh gửi truy vấn tới ChromaDB để lấy top-k vector tương đồng nhất; nhánh còn lại token hóa truy vấn và tính điểm trên chỉ mục BM25 in-memory xây dựng từ chính corpus. Kết quả xếp hạng của hai bên được hợp nhất bằng giải thuật Reciprocal Rank Fusion (RRF).")

heading("4.2.5. Cross-Encoder Reranker", 3)
para("Các ứng viên sau RRF được đưa vào Cross-Encoder Reranker. Reranker chấm điểm tương quan trực tiếp giữa cặp (Query, Chunk) và trả về một điểm số thực thể. Các chunk được sắp xếp lại và chỉ giữ lại top-n chunk có điểm số cao nhất để chuyển tiếp.")

heading("4.2.6. LLM Generator", 3)
para("Nhận prompt đã được bổ sinh ngữ cảnh và nguồn trích dẫn từ Prompt Builder. LLM (local Qwen hoặc Gemini API) thực hiện sinh câu trả lời cuối cùng bám sát theo các chỉ dẫn ràng buộc nghiêm ngặt trong prompt hệ thống.")

page_break()

# ============================================================================
# CHAPTER 5: SYSTEM IMPLEMENTATION
# ============================================================================
heading("Chapter 5. System Implementation Details", 1)

heading("5.1. Component Design and Classes", 2)
para("Hệ thống được thiết kế dạng các lớp hướng đối tượng độc lập đặt trong thư mục src/:")
bullet([("BM25Searcher (src/bm25.py):", "code"), (" Chịu trách nhiệm khởi tạo bộ tokenizer, xây dựng corpus từ ChromaDB và thực hiện tìm kiếm điểm BM25.", None)])
bullet([("Retriever (src/retriever.py):", "code"), (" Đóng vai trò điều phối chính, gọi song song ChromaDB và BM25Searcher, sau đó thực hiện RRF để gom kết quả.", None)])
bullet([("Reranker (src/reranker.py):", "code"), (" Quản lý mô hình CrossEncoder, tối ưu hóa quá trình tính toán điểm số rerank bằng GPU với kỹ thuật phân batch nhỏ.", None)])
bullet([("build_prompt() (src/prompt_builder.py):", "code"), (" Dựng cấu trúc prompt hệ thống và prompt người dùng, định dạng nguồn tài liệu tham khảo.", None)])

heading("5.2. Query Execution Lifecycle Sequence", 2)
para("Khi người dùng gửi một câu hỏi, chuỗi xử lý diễn ra tuần tự như sau:")
bullet("1. Người dùng nhập câu hỏi vào giao diện (CLI ask.py hoặc UI app.py).")
bullet("2. Câu hỏi được gửi tới HybridRetriever.")
bullet("3. Retriever chạy song song: Dense Search sinh vector truy vấn và tìm trong ChromaDB; Lexical Search tính điểm BM25.")
bullet("4. RRF tiến hành gộp danh sách xếp hạng của hai nhánh thành một danh sách top-k duy nhất.")
bullet("5. Danh sách top-k được chuyển qua BGEReranker để chấm điểm lại mức độ liên quan ngữ nghĩa chính xác.")
bullet("6. Lọc lấy top-n chunk có điểm rerank cao nhất chuyển tới PromptBuilder.")
bullet("7. PromptBuilder dựng cấu trúc prompt đầy đủ kèm ngữ cảnh chi tiết gửi sang llm.py.")
bullet("8. LLM sinh câu trả lời, hệ thống bóc tách nguồn trích dẫn và hiển thị ra màn hình kèm biểu đồ độ trễ.")

heading("5.3. Core Algorithmic Pseudo-code", 2)
para("Dưới đây là mã giả của hai thuật toán cốt lõi làm nên hiệu năng vượt trội của hệ thống:")

add_pseudocode(
    "Algorithm 1: Reciprocal Rank Fusion (RRF) for Hybrid Search",
    [
        "Input: Query Q, DenseRankList L_dense, LexicalRankList L_lexical, Constant k = 60, Top_N",
        "Output: Ranked list of chunks with fused scores",
        "",
        "Initialize dict fused_scores = {}",
        "",
        "# Process Dense Search results",
        "For index, doc in enumerate(L_dense):",
        "    rank = index + 1",
        "    fused_scores[doc.id] = fused_scores.get(doc.id, 0) + 1.0 / (k + rank)",
        "    Save doc metadata and content reference",
        "",
        "# Process Lexical Search (BM25) results",
        "For index, doc in enumerate(L_lexical):",
        "    rank = index + 1",
        "    fused_scores[doc.id] = fused_scores.get(doc.id, 0) + 1.0 / (k + rank)",
        "    Save doc metadata and content reference if not exists",
        "",
        "# Sort documents by fused scores",
        "Sorted_Docs = Sort keys of fused_scores in descending order of value",
        "Return Sorted_Docs[:Top_N]"
    ]
)

add_pseudocode(
    "Algorithm 2: Length-Sorted Cross-Encoder Batching to Avoid Unlucky Batch",
    [
        "Input: Query Q, Candidates List C, Batch_Size = 4, Max_Length = 1024",
        "Output: Scores list for all candidates",
        "",
        "Pairs = [ (Q, chunk.content) for chunk in C ]",
        "Lengths = [ len(tokenizer(pair)) for pair in Pairs ]",
        "",
        "# Sort pairs by token length to group similar lengths",
        "Sorted_Indices = argsort(Lengths)",
        "Sorted_Pairs = [ Pairs[i] for i in Sorted_Indices ]",
        "",
        "Initialize List Scores = [ 0 * len(C) ]",
        "For i from 0 to len(C) step Batch_Size:",
        "    Batch = Sorted_Pairs[i : i + Batch_Size]",
        "    # Pad only to the maximum length within this specific small batch!",
        "    Batch_Scores = CrossEncoder.predict(Batch, max_length=Max_Length, convert_to_tensor=True)",
        "    For j, score in enumerate(Batch_Scores):",
        "        original_idx = Sorted_Indices[i + j]",
        "        Scores[original_idx] = score",
        "",
        "Return Scores"
    ]
)

page_break()

# ============================================================================
# CHAPTER 6: EXPERIMENTAL SETUP
# ============================================================================
heading("Chapter 6. Experimental Setup and Methodology", 1)

heading("6.1. Hardware and Resource Boundaries", 2)
para("Nhằm mục đích tối ưu hóa trên cấu hình thực tế, toàn bộ hệ thống được chạy và đo đạc trên máy tính cá nhân:")
bullet([("CPU:", "b"), (" Intel Core i5-13420H (8 nhân, 12 luồng, xung nhịp lên tới 4.6 GHz).", None)])
bullet([("GPU:", "b"), (" NVIDIA GeForce RTX 3050 Laptop GPU với 6GB VRAM chuyên dụng.", None)])
bullet([("RAM:", "b"), (" 16GB DDR4 RAM chạy ở bus 3200 MHz.", None)])
bullet([("OS:", "b"), (" Windows 11 Home Single Language.", None)])

heading("6.2. Software Stack and Libraries", 2)
para("Phiên bản các thư viện chính được liệt kê dưới đây, lấy trực tiếp từ môi trường thực thi (importlib.metadata) tại thời điểm viết báo cáo, không phải số phiên bản ghim/dự kiến trong requirements.txt:")
bullet("PyTorch 2.12.0+cu126 hỗ trợ tăng tốc CUDA trên GPU RTX 3050.")
bullet("sentence-transformers 5.5.1 để nạp các mô hình Bi-Encoder (BGE-M3) và Cross-Encoder (bge-reranker-v2-m3).")
bullet("chromadb 1.5.9 làm cơ sở dữ liệu vector lưu trữ bền vững.")
bullet("rank-bm25 0.2.2 để làm lõi tính điểm tìm kiếm từ khóa BM25.")
bullet("PyMuPDF (fitz) 1.27.2.3 để bóc tách cấu trúc PDF học thuật theo block.")
bullet("python-docx 1.2.0 phục vụ loader đọc tệp Word và sinh báo cáo này.")
bullet("Streamlit 1.58.0 để xây dựng giao diện tương tác người dùng.")

heading("6.3. Evaluation Benchmark (Golden Q&A)", 2)
para("Chúng tôi thiết lập bộ đánh giá chất lượng thủ công gồm 38 câu hỏi vàng (golden_qa.json), được chia thành các nhóm có chủ đích nhằm thách thức hệ thống:")
bullet([("20 câu hỏi Factual:", "b"), (" Câu hỏi trực tiếp về 1 chi tiết cụ thể có trong 1 tài liệu (ví dụ: số lượng tham số của GPT-3, kiến trúc của Self-RAG).", None)])
bullet([("8 câu hỏi Hard/Confusable:", "b"), (" Các câu hỏi dễ gây nhầm lẫn đòi hỏi bộ truy xuất phải phân biệt đúng giữa các khái niệm tương tự nằm ở các tài liệu khác nhau (ví dụ: phân biệt cơ chế ReAct với Chain-of-Thought).", None)])
bullet([("5 câu hỏi Unanswerable:", "b"), (" Các câu hỏi không hề có thông tin trong corpus, được dùng để đo tỷ lệ từ chối ảo giác của mô hình sinh.", None)])
bullet([("5 câu hỏi Tiếng Việt:", "b"), (" Kiểm tra khả năng tìm kiếm xuyên ngôn ngữ (cross-lingual retrieval) của mô hình BGE-M3 (câu hỏi tiếng Việt truy xuất tài liệu gốc tiếng Anh).", None)])

heading("6.4. Evaluation Metrics", 2)
para("Chất lượng của hệ thống được phản ánh thông qua các chỉ số đo đạc định lượng:")
bullet([("Hit Rate@k (File & Page):", "b"), (" Tỷ lệ hệ thống truy xuất thành công tài liệu chứa câu trả lời trong top-k kết quả trả về.", None)])
bullet([("MRR@k (Mean Reciprocal Rank):", "b"), (" Thử thách khả năng xếp vị trí đúng của tài liệu đích lên vị trí đầu tiên. Điểm số là nghịch đảo của thứ hạng tài liệu đích xuất hiện.", None)])
bullet([("ROUGE-L:", "b"), (" Đo mức độ trùng lặp chuỗi con chung dài nhất giữa câu trả lời sinh ra và câu trả lời ground-truth.", None)])
bullet([("Faithfulness Score (LLM-as-a-judge):", "b"), (" Sử dụng mô hình lớn (Gemini API) chấm điểm mức độ trung thực của câu trả lời sinh ra dựa trên context thực tế cấp cho mô hình (thang điểm 0.0, 0.5, 1.0).", None)])
bullet([("Refusal Rate:", "b"), (" Tỷ lệ mô hình từ chối trả lời chính xác đối với các câu hỏi unanswerable.", None)])

page_break()

# ============================================================================
# CHAPTER 7: RESULTS
# ============================================================================
heading("Chapter 7. Experimental Results and Analysis", 1)

heading("7.1. Chunking Strategy Performance Evaluation", 2)
para("Chúng tôi thực hiện đánh giá độc lập chất lượng của 3 chiến lược chunking trên cùng một cấu hình truy xuất Dense Retrieval (không dùng Reranker) với bộ 38 câu hỏi vàng. Kết quả được tổng hợp như sau:")

add_table(
    ["Chiến lược Chunking", "Số lượng Chunk", "Hit Rate@k", "MRR", "Avg Latency"],
    [
        ["Fixed-size (512 từ, overlap 64)", "3.421 chunks", "1.00", "0.980", "37.1 ms"],
        ["Recursive Character", "3.570 chunks", "1.00", "0.980", "41.9 ms"],
        ["Semantic Chunking", "6.324 chunks", "1.00", "0.980", "36.3 ms"],
    ],
    widths_cm=[4.5, 2.8, 2.5, 2.5, 2.8],
    caption="Table 2: So sánh hiệu năng truy xuất của 3 chiến lược phân mảnh dữ liệu (Dense, không Reranker, 38 câu hỏi vàng)"
)

para([
    ("Nhận xét: ", "b"),
    ("Trên corpus 635 Document hiện hành, cả 3 chiến lược chunking đều đạt Hit Rate tuyệt đối (1.00) và MRR bằng nhau (0.980) ở chế độ Dense không Reranker — nghĩa là ở tầng truy xuất ngữ nghĩa thô, việc chọn chiến lược chunking nào gần như KHÔNG ảnh hưởng tới khả năng đưa đúng tài liệu lên Top-1 với bộ câu hỏi này. Điểm khác biệt lớn nhất giữa 3 chiến lược nằm ở ", None),
    ("số lượng chunk", "b"),
    (": Semantic sinh ra 6.324 chunk — gần GẤP ĐÔI so với Fixed (3.421) và Recursive (3.570). Điều này làm tăng đáng kể chi phí lưu trữ vector và thời gian ingest (embed từng câu), trong khi lợi ích về chất lượng truy xuất ở tầng thô lại chưa thể hiện rõ trên bộ đánh giá hiện tại. Đây là một đánh đổi cần cân nhắc: Semantic Chunking chỉ thực sự phát huy giá trị khi corpus có cấu trúc chủ đề phức tạp hơn và bộ câu hỏi đòi hỏi định vị chính xác hơn ở cấp đoạn.", None),
])

heading("7.2. Comprehensive Benchmark: 18 Cấu hình Thực nghiệm", 2)
para([
    ("Đây là kết quả cốt lõi của báo cáo: một ma trận thực nghiệm đầy đủ gồm ", None),
    ("18 tổ hợp", "b"),
    (" = 3 chiến lược chunking (fixed/recursive/semantic) × 3 chế độ tìm kiếm (dense/bm25/hybrid) × 2 trạng thái Reranker (có/không), đo trên toàn bộ 38 câu hỏi vàng, cùng cấu hình TOP_K=20 và RERANK_TOP_N=5. Cột Hit Rate@k và MRR phản ánh chất lượng xếp hạng; cột Latency là thời gian trung bình một câu hỏi (đo thực tế trên RTX 3050 Laptop — mang tính snapshot theo phần cứng và trạng thái warm-up của GPU, dùng để so sánh tương đối giữa các cấu hình).", None),
])

add_table(
    ["Chiến lược", "Chế độ", "Reranker", "Hit Rate@k", "MRR", "Avg Latency"],
    [
        ["fixed", "dense", "Không", "1.00", "0.980", "37.1 ms"],
        ["fixed", "dense", "Có", "1.00", "0.970", "3.270,8 ms"],
        ["fixed", "bm25", "Không", "1.00", "0.907", "50.0 ms"],
        ["fixed", "bm25", "Có", "1.00", "0.985", "3.730,7 ms"],
        ["fixed", "hybrid", "Không", "1.00", "0.965", "44.9 ms"],
        ["fixed", "hybrid", "Có", "1.00", "0.985", "3.797,3 ms"],
        ["recursive", "dense", "Không", "1.00", "0.980", "41.9 ms"],
        ["recursive", "dense", "Có", "1.00", "0.962", "32.914,4 ms"],
        ["recursive", "bm25", "Không", "1.00", "0.890", "70.1 ms"],
        ["recursive", "bm25", "Có", "1.00", "0.985", "24.198,3 ms"],
        ["recursive", "hybrid", "Không", "1.00", "0.949", "56.8 ms"],
        ["recursive", "hybrid", "Có", "1.00", "0.985", "3.542,7 ms"],
        ["semantic", "dense", "Không", "1.00", "0.980", "36.3 ms"],
        ["semantic", "dense", "Có", "1.00", "0.970", "2.563,8 ms"],
        ["semantic", "bm25", "Không", "1.00", "0.894", "64.2 ms"],
        ["semantic", "bm25", "Có", "1.00", "0.970", "2.675,5 ms"],
        ["semantic", "hybrid", "Không", "1.00", "0.962", "67.9 ms"],
        ["semantic", "hybrid", "Có", "1.00", "0.970", "2.618,7 ms"],
    ],
    widths_cm=[2.6, 2.2, 2.2, 2.6, 2.2, 3.0],
    caption="Table 3: Ma trận benchmark đầy đủ 18 cấu hình (3 chunking x 3 retrieval x 2 reranker) trên 38 câu hỏi vàng"
)

para([
    ("Nhận xét 1 — Hit Rate bão hòa ở 1.00: ", "b"),
    ("Toàn bộ 18 cấu hình đều đạt Hit Rate@k = 1.00, nghĩa là tài liệu chứa đáp án LUÔN nằm trong tập kết quả trả về. Điều này cho thấy tầng truy xuất thô đã đủ tốt cho bộ câu hỏi này, và sự khác biệt giữa các cấu hình phải nhìn qua MRR (vị trí xếp hạng) chứ không phải Hit Rate.", None),
])
para([
    ("Nhận xét 2 — MRR tốt nhất (0.985) thuộc về BM25/Hybrid + Reranker: ", "b"),
    ("Với chiến lược fixed và recursive, cặp (bm25 + reranker) và (hybrid + reranker) đều đạt MRR = 0.985 — gần như đưa đáp án đúng lên đúng vị trí Top-1. Reranker Cross-Encoder phát huy tác dụng rõ nhất khi tầng đầu là BM25 (nâng MRR fixed-bm25 từ 0.907 lên 0.985, recursive-bm25 từ 0.890 lên 0.985): nó bù đắp chính xác điểm yếu xếp hạng của tìm kiếm từ khóa thuần túy.", None),
])
para([
    ("Nhận xét 3 — Cái giá về độ trễ và hiện tượng 'unlucky batch': ", "b"),
    ("Không dùng Reranker cho phản hồi cực nhanh (36–70 ms/câu). Bật Reranker khiến độ trễ tăng lên khoảng 2,5–3,8 giây do Cross-Encoder tính tương quan sâu từng cặp (query, chunk). Đặc biệt, hai cấu hình ", None),
    ("recursive + dense + reranker (32,9 giây) và recursive + bm25 + reranker (24,2 giây)", "red"),
    (" bị vọt độ trễ bất thường: chiến lược recursive đôi khi tạo ra các chunk rất dài (gần ngưỡng token tối đa), và khi một chunk dài lọt vào batch của Cross-Encoder, toàn bộ batch bị pad theo độ dài đó (hiện tượng 'unlucky batch', phân tích chi tiết ở mục 7.4.3). Chiến lược semantic và fixed sinh chunk đồng đều hơn nên giữ được độ trễ Reranker ổn định quanh 2,5–3,8 giây — một lý do kỹ thuật quan trọng để ưu tiên chúng trong triển khai thực tế.", None),
])

heading("7.3. Reranker Influence and the Page-level Coverage Drop", 2)
para("Ngoài chỉ số cấp File ở bảng trên, chúng tôi còn xây dựng bộ đánh giá ở cấp độ Trang (expected_page) — khắt khe hơn vì đòi hỏi truy xuất đúng CẢ trang chứa đáp án, không chỉ đúng file. Phép đo chi tiết cấp Trang (trên chiến lược semantic) cho một phát hiện phản trực giác:")

add_table(
    ["Cấu hình truy xuất (Semantic)", "Hit Rate cấp File", "MRR cấp File", "Hit Rate cấp Trang", "MRR cấp Trang"],
    [
        ["Không sử dụng Reranker", "1.000", "0.976", "1.000", "0.672"],
        ["Có sử dụng Reranker", "1.000", "0.970", "0.909", "0.758"],
    ],
    widths_cm=[4.5, 2.8, 2.8, 2.8, 2.8],
    caption="Table 4: Tác động của bộ tái xếp hạng Reranker ở cấp độ File và cấp độ Trang"
)

para([
    ("Hiện tượng phân tích: ", "b"),
    ("Nếu chỉ đánh giá cấp File, Reranker trông như không có tác động nào (Hit Rate giữ nguyên 1.000, MRR giảm nhẹ không đáng kể). Tuy nhiên, đánh giá cấp Trang cho thấy ", None),
    ("Hit Rate cấp Trang bị tụt giảm từ 1.000 xuống 0.909", "red"),
    (" khi bật Reranker. Nguyên nhân là do Cross-Encoder xếp hạng lại đôi khi ưu tiên các chunk có độ dài câu chữ khớp cao nằm ở trang khác trong cùng một file, vô tình đẩy chunk chứa đáp án thực tế (trang đích) ra khỏi cửa sổ hiển thị top-5. Đây là một phát hiện quan trọng chứng minh rằng reranking đôi khi làm giảm vùng phủ cấp trang thực tế.", None)
])

heading("7.4. Engineering Findings and Performance Profiling", 2)

heading("7.4.1. CPU vs. GPU Reranker Latency", 3)
para("Ban đầu, chúng tôi giả định chạy Reranker trên CPU để tiết kiệm VRAM cho LLM. Tuy nhiên, đo đạc thực tế cho thấy CPU mất tới 23.3 giây để rerank 20 ứng viên (thậm chí mất tới 41 giây nếu không giới hạn max_length). Chuyển sang chạy GPU CUDA giúp giảm độ trễ xuống 2.0 giây (nhanh gấp 11 lần). Để thích ứng với dung lượng 6GB VRAM của GPU RTX 3050, chúng tôi bắt buộc phải hạ kích thước mô hình LLM chạy cục bộ từ 3B xuống 1.5B (Qwen2.5:1.5b) nhằm tránh lỗi tràn bộ nhớ.")

heading("7.4.2. PyMuPDF Boundary Bug Recovery", 3)
para("Khi sử dụng parser văn bản thông thường của PyMuPDF, các ký tự ngắt dòng kép \\n\\n phân tách đoạn văn bị loại bỏ vô điều kiện. Điều này khiến thuật toán Chunker Recursive đệ quy hoạt động kém hiệu quả (tương tự như Fixed Chunker). Sau khi chuyển sang kỹ thuật bóc tách theo khối (\"blocks\"), ranh giới đoạn văn được phục hồi hoàn chỉnh, giúp nâng MRR cấp file của chiến lược recursive từ 0.890 lên 0.963.")

heading("7.4.3. The \"Unlucky Batch\" Latency Outlier", 3)
para("Trong quá trình chạy quét tham số, chúng tôi phát hiện độ trễ thỉnh thoảng bị vọt lên mức không tưởng (46.1 giây/câu hỏi). Điều tra log chỉ ra rằng Cross-Encoder thực hiện padding độ dài chuỗi theo phần tử dài nhất trong batch. Khi top-k chứa một chunk ngữ nghĩa rất dài (lên tới 1974 token), và toàn bộ 20 ứng viên được tống vào đúng 1 batch mặc định (batch_size=32), cả 19 ứng viên ngắn còn lại đều bị kéo dài lãng phí theo.")

para("Giải pháp khắc phục là giảm cấu hình xuống RERANKER_BATCH_SIZE = 4 để chia nhỏ nhóm xử lý. Kết quả đo lại cho thấy độ trễ được kiểm soát ổn định ở mức trung bình 1.92 giây, loại bỏ hoàn toàn các điểm outlier độ trễ.")

add_table(
    ["Cấu hình truy vấn (Semantic)", "Reranker Batch Size", "Độ trễ trung bình / câu hỏi", "Trạng thái hệ thống"],
    [
        ["Top_K = 10 + Reranker", "32 (Mặc định)", "10.7 giây ⚠", "Độ trễ không chấp nhận được"],
        ["Top_K = 20 + Reranker", "32 (Mặc định)", "46.1 giây ⚠", "Outlier nghẽn cổ chai nghiêm trọng"],
        ["Top_K = 20 + Reranker", "4 (Tối ưu hóa)", "1.92 giây ✔", "Ổn định, mượt mà"],
    ],
    widths_cm=[6.0, 3.5, 3.5, 2.5],
    caption="Table 5: So sánh hiệu năng của Reranker trước và sau tối ưu hóa batch_size"
)

heading("7.4.4. GPU Thermal Cooldown và ChromaDB Batch Upsert", 3)
para([
    ("Do embedding và ingest chạy trên GPU laptop (RTX 3050, tản nhiệt hạn chế) trong thời gian dài (embed hàng nghìn chunk liên tục), nhiệt độ GPU thực tế được ghi nhận vượt 75°C chỉ sau vài chục block xử lý. ", None),
    ("Embedder.embed_texts()", "code"),
    (" (", None),
    ("src/embedding.py", "code"),
    (") được sửa để chia nhỏ dữ liệu thành các block 32 chunk, gọi ", None),
    ("check_and_cooldown_gpu()", "code"),
    (" (đọc nhiệt độ qua ", None),
    ("nvidia-smi --query-gpu=temperature.gpu", "code"),
    (") trước MỖI block: nếu nhiệt độ vượt ngưỡng 77°C, tiến trình tạm dừng (tối đa 4 lần kiểm tra, mỗi lần cách nhau 10 giây) cho tới khi nhiệt độ xuống dưới 68°C rồi mới tiếp tục embed block kế tiếp. Khi tái ingest lại chiến lược semantic trên corpus 635 Document (6.324 chunk) để phục vụ báo cáo này, cơ chế cooldown đã được kích hoạt thật nhiều lần trong log — ví dụ một lần dừng lại ở 76°C và chỉ tiếp tục sau khi nhiệt độ thực đo giảm xuống 55°C.", None),
])
para([
    ("Một giới hạn kỹ thuật khác gặp phải khi ingest số lượng lớn: ChromaDB (chạy trên SQLite) giới hạn tối đa 5.461 tham số trong một lệnh ", None),
    ("upsert()", "code"),
    (" — vượt ngưỡng này sẽ ném lỗi. ", None),
    ("VectorStore.add()", "code"),
    (" (", None),
    ("src/vectordb.py", "code"),
    (") vì vậy chia nhỏ danh sách chunk cần ghi thành các batch 4.000 phần tử trước khi gọi upsert, đảm bảo ingest chạy an toàn với corpus có hàng nghìn chunk mà không phụ thuộc vào số lượng tài liệu đầu vào.", None),
])

page_break()

# ============================================================================
# CHAPTER 8: DISCUSSION
# ============================================================================
heading("Chapter 8. Discussion", 1)

heading("8.1. Why Hybrid Retrieval and Semantic Chunking Perform Best", 2)
para("Thực nghiệm chứng minh sự kết hợp giữa tìm kiếm lai RRF và phân mảnh dữ liệu theo ngữ nghĩa (Semantic Chunking) mang lại hiệu quả vượt trội. BM25 và Dense Retrieval đại diện cho hai trường phái tìm kiếm thông tin bổ khuyết cho nhau. BM25 dựa trên tần suất từ khóa chính xác, cực kỳ hiệu quả khi người dùng truy vấn các từ viết tắt chuyên ngành hoặc tên mô hình cụ thể. Dense Retrieval nắm bắt ngữ nghĩa tổng quát, vượt qua ranh giới của các từ đồng nghĩa.")

para("Việc kết hợp thông qua RRF loại bỏ việc phải chuẩn hóa điểm số khác biệt giữa hai công cụ (một bên tính bằng Cosine khoảng cách, một bên là điểm số BM25 không giới hạn), chỉ dựa trên thứ hạng xếp thứ mấy để tính điểm cộng hưởng. Song song đó, Semantic Chunking chia nhỏ văn bản tại đúng điểm gãy ngữ nghĩa giúp loại bỏ hiện tượng \"nhiễu thông tin chéo\" thường xuất hiện trong các chunk fixed-size cắt ngang xương giữa đoạn văn.")

heading("8.2. Trade-offs in Local RAG Systems", 2)
para("Xây dựng hệ thống RAG trên phần cứng cá nhân giới hạn 6GB VRAM buộc nhà thiết kế hệ thống phải đưa ra các quyết định đánh đổi (trade-offs) sâu sắc:")
bullet([("Giữa Tốc độ và Độ chính xác của Reranker:", "b"), (" Chấp nhận tăng thêm ~1.8s độ trễ phản hồi để đổi lại sự cải thiện MRR cấp trang lớn (từ 0.672 lên 0.758).", None)])
bullet([("Giữa Kích thước LLM và VRAM:", "b"), (" Phải hy sinh mô hình LLM lớn hơn (như Qwen 3B hay 7B) để hạ xuống bản 1.5B nhằm dành không gian VRAM cho Embedding và Reranker chạy song song trên GPU.", None)])
bullet([("Giữa Kích thước Chunk và MRR:", "b"), (" Tăng kích thước chunk giúp tăng MRR do ít cạnh tranh giữa các chunk cùng file nhưng làm tăng tải xử lý cho Reranker và tăng nguy cơ tràn cửa sổ ngữ cảnh của LLM.", None)])

page_break()

# ============================================================================
# CHAPTER 9: LIMITATIONS
# ============================================================================
heading("Chapter 9. System Limitations", 1)

heading("9.1. Local Hardware and Model Size Constraints", 2)
para("Giới hạn lớn nhất của hệ thống nằm ở dung lượng VRAM 6GB của GPU RTX 3050 Laptop. Thiết lập này khiến việc chạy đồng thời mô hình Embedding BGE-M3 (chiếm ~1.5GB VRAM), Cross-Encoder Reranker (chiếm ~1.5GB VRAM) và mô hình LLM local (Qwen 1.5B chiếm ~1.8GB VRAM) luôn hoạt động cận kề ngưỡng giới hạn vật lý. Nếu người dùng muốn nâng cấp lên mô hình LLM local thông minh hơn như Qwen-7B-Instruct (yêu cầu tối thiểu 5-6GB VRAM chỉ riêng cho LLM), hệ thống chắc chắn sẽ bị treo do lỗi tràn bộ nhớ GPU.")

heading("9.2. Format Compliance and Hallucination in Small Models", 2)
para("Mô hình local Qwen-1.5B có kích thước tham số quá nhỏ dẫn tới khả năng tuân thủ chỉ thị phức tạp (instruction-following) kém. "
     "Mặc dù prompt hệ thống đã thiết lập các ràng buộc chặt chẽ bắt buộc mô hình phải trích dẫn nguồn dạng `[1]`, `[2]` tương ứng với tài liệu tham khảo và từ chối trả lời nếu thông tin không xuất hiện trong ngữ cảnh, Qwen2.5-1.5B vẫn sinh ra các trích dẫn ảo giác hoặc tự động bịa đặt thông tin khi gặp các câu hỏi unanswerable (tỷ lệ từ chối đúng đo được chỉ đạt 3/5 = 0.60, tức là 40% (2/5) câu hỏi ngoài phạm vi vẫn bị bịa thông tin thay vì từ chối).")

heading("9.3. Document Format & Static DB Limitations", 2)
para("Hệ thống chỉ hỗ trợ nạp tài liệu tĩnh dạng PDF và Word (.docx). "
     "Cơ sở dữ liệu ChromaDB hiện tại chưa hỗ trợ cập nhật động hoặc đồng bộ hóa thời gian thực khi có sự thay đổi tài liệu nguồn mà yêu cầu phải chạy lại toàn bộ quy trình ingest.py. "
     "Đồng thời, hệ thống chưa có khả năng xử lý các câu hỏi đa bước (multi-hop queries) đòi hỏi phải suy luận liên kết thông tin giữa nhiều tài liệu khác nhau.")

page_break()

# ============================================================================
# CHAPTER 10: FUTURE WORK
# ============================================================================
heading("Chapter 10. Future Work", 1)

heading("10.1. Embedding and Reranker Domain Adaptation", 2)
para("Để nâng cao chất lượng tìm kiếm chuyên ngành khoa học máy tính và NLP, hướng đi tiếp theo là thực hiện tinh chỉnh (fine-tuning) mô hình BGE-M3 và BGE-Reranker trên một tập dữ liệu cặp (Query, Context) chuyên ngành thông qua kỹ thuật Contrastive Learning (Học tương phản). Việc này giúp căn chỉnh lại không gian vector biểu diễn ngữ nghĩa bám sát các khái niệm kỹ thuật đặc thù hơn.")

heading("10.2. Agentic RAG and Query Decomposer", 2)
para("Triển khai kiến trúc Agentic RAG, tích hợp một LLM lớn làm bộ điều hợp truy vấn (Query Agent). Đối với các câu hỏi phức tạp hoặc đa bước, Agent sẽ tự động phân tách câu hỏi lớn thành các câu hỏi con (Query Decomposition) và thực hiện truy xuất thông tin nhiều vòng (Multi-hop Retrieval), liên kết kết quả trung gian để tổng hợp thành câu trả lời cuối cùng toàn diện.")

heading("10.3. Dynamic Thresholding and MMR Diversity Reranking", 2)
para("Nhằm khắc phục hiện tượng suy giảm vùng phủ cấp trang (hit_rate_page) của Reranker, chúng tôi sẽ nghiên cứu tích hợp thuật toán đa dạng hóa thông tin MMR (Maximal Marginal Relevance) vào sau bước Cross-Encoder. MMR sẽ giúp cân bằng giữa độ liên quan ngữ nghĩa của chunk và độ đa dạng nguồn tài liệu (ngăn chặn các chunk trùng lặp nội dung cùng trang lấn át các trang hữu ích khác).")

heading("10.4. GraphRAG Integration", 2)
para("Nghiên cứu tích hợp đồ thị tri thức (Knowledge Graph) kết hợp Vector DB (GraphRAG). Bằng cách bóc tách thực thể và mối quan hệ giữa các bài báo học thuật, hệ thống có thể truy xuất thông tin dựa trên các kết nối trích dẫn (citation) và quan hệ cấu trúc học thuật, mang lại chiều sâu lập luận vượt trội.")

page_break()

# ============================================================================
# CHAPTER 11: CONCLUSION
# ============================================================================
heading("Chapter 11. Conclusion", 1)

para([
    ("Dự án đã nghiên cứu và hiện thực hóa thành công một hệ thống trợ lý AI tra cứu tri thức học máy và NLP (AI Knowledge Assistant) dựa trên kiến trúc RAG tự triển khai từ đầu. "
     "Chúng tôi đã chứng minh rằng việc tối ưu hóa chi tiết kỹ thuật ở các bước nạp và truy xuất dữ liệu đóng vai trò quyết định đến chất lượng cuối cùng của hệ thống RAG, chứ không chỉ dựa vào kích thước của mô hình sinh câu trả lời LLM. "
     "Bằng chứng cụ thể là việc sửa đổi parser PyMuPDF phục hồi ranh giới đoạn văn giúp nâng MRR recursive cấp file từ ", None),
    ("0.890 lên 0.963", "b"),
    (", và điều chỉnh batch size của Cross-Encoder giúp giải quyết triệt để nút thắt cổ chai độ trễ từ ", None),
    ("46.1 giây xuống 1.92 giây", "b"),
    (".", None)
])

para("Các kết quả thực nghiệm định lượng trên bộ 38 câu hỏi vàng cùng các chỉ số đo đạc cấp trang chuyên sâu đã mang lại những insight kỹ thuật có giá trị thực tiễn cao, làm rõ các bài toán đánh đổi giữa bộ nhớ VRAM, độ trễ và độ chính xác trong một hệ thống cục bộ giới hạn phần cứng. Báo cáo này thiết lập một nền tảng vững chắc cho các nghiên cứu tiếp theo về Agentic RAG và GraphRAG trên tài nguyên tính toán tối thiểu.")

page_break()

# ============================================================================
# REFERENCES
# ============================================================================
heading("References", 1)

references = [
    "[1] Vaswani, A., Shazeer, N., Parmar, N., Uszkoreit, J., Jones, L., Gomez, A. N., Kaiser, L., & Polosukhin, I. (2017). Attention is all you need. In Advances in Neural Information Processing Systems (NeurIPS 2017).",
    "[2] Lewis, P., Perez, E., Piktus, A., Petroni, F., Lewis, M., Riedel, S., & Kiela, D. (2020). Retrieval-augmented generation for knowledge-intensive NLP tasks. In Advances in Neural Information Processing Systems (NeurIPS 2020).",
    "[3] Devlin, J., Chang, M. W., Lee, K., & Toutanova, K. (2018). BERT: Pre-training of deep bidirectional transformers for language understanding. arXiv preprint arXiv:1810.04805.",
    "[4] Brown, T. B., Mann, B., Ryder, N., Subbiah, M., Kaplan, J., Dhariwal, P., ... & Amodei, D. (2020). Language models are few-shot learners. In Advances in Neural Information Processing Systems (NeurIPS 2020).",
    "[5] Ouyang, L., Wu, J., Jiang, X., Almeida, D., Wainwright, C. L., Mishkin, P., ... & Lowe, R. (2022). Training language models to follow instructions with human feedback. In Advances in Neural Information Processing Systems (NeurIPS 2022).",
    "[6] Touvron, H., Martin, L., Stone, K., Albert, P., Almahairi, A., Babaei, Y., ... & Scialom, T. (2023). Llama 2: Open foundation and fine-tuned chat models. arXiv preprint arXiv:2307.09288.",
    "[7] Xiao, S., Liu, Z., Zhang, J., & Wang, J. (2023). C-pack: Packaged resources to advance general Chinese embedding. arXiv preprint arXiv:2309.07597 (BGE Embedding & M3).",
    "[8] Asai, A., Wu, Z., Wang, Y., Sil, A., & Hajishirzi, H. (2023). Self-RAG: Learning to retrieve, generate, and self-reflect through self-rag. arXiv preprint arXiv:2310.11511.",
    "[9] Borgeaud, S., Mensch, A., Hoffmann, J., Cai, T., Rutherford, E., Casas, K., ... & Sifre, L. (2022). Improving language models by retrieving from trillions of tokens. In International Conference on Machine Learning (ICML 2022).",
    "[10] Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., & Cao, Y. (2022). ReAct: Synergizing reasoning and acting in language models. In International Conference on Learning Representations (ICLR 2023).",
    "[11] Wei, J., Wang, X., Schuurmans, D., Bosma, M., Chi, E., Xia, F., ... & Zhou, D. (2022). Chain-of-thought prompting elicits reasoning in large language models. In Advances in Neural Information Processing Systems (NeurIPS 2022).",
    "[12] Schick, T., Dwivedi-Yu, J., Dessì, R., Lau, R., Way, T., Hambro, J., ... & Riedel, S. (2023). Toolformer: Language models can teach themselves to use tools. arXiv preprint arXiv:2302.04761.",
    "[13] Robertson, S., & Zaragoza, H. (2009). The probabilistic relevance framework: BM25 and beyond. Foundations and Trends in Information Retrieval, 3(4), 333-389.",
    "[14] Cormack, G. V., Clarke, C. L., & Buettcher, S. (2009). Reciprocal rank fusion outperforms vulnerability analysis. In Proceedings of the 32nd International ACM SIGIR Conference on Research and Development in Information Retrieval.",
    "[15] Hu, E. J., Shen, Y., Wallis, P., Allen-Zhu, Z., Li, Y., Wang, S., ... & Chen, W. (2021). LoRA: Low-rank adaptation of large language models. arXiv preprint arXiv:2106.09685.",
    "[16] Dettmers, T., Pagnoni, A., Holtzman, A., & Zettmers, L. (2023). Qlora: Efficient finetuning of quantized llms. In Advances in Neural Information Processing Systems (NeurIPS 2023).",
    "[17] Malkov, Y. A., & Yashunin, D. A. (2018). Efficient and robust approximate nearest neighbor search using Hierarchical Navigable Small World graphs. IEEE Transactions on Pattern Analysis and Machine Intelligence, 42(4), 824-836.",
    "[18] Karpukhin, V., Oguz, B., Min, S., Wu, L., Lederman, S., Li, D., ... & Yih, W. T. (2020). Dense passage retrieval for open-domain question answering. In Proceedings of the 2020 Conference on Empirical Methods in Natural Language Processing (EMNLP).",
    "[19] Reimers, N., & Gurevych, I. (2019). Sentence-BERT: Sentence embeddings using Siamese BERT-networks. In Proceedings of the 2019 Conference on Empirical Methods in Natural Language Processing (EMNLP).",
    "[20] Lin, C. Y. (2004). ROUGE: A package for automatic evaluation of summaries. In Text Summarization Branches Out.",
    "[21] Nogueira, R., & Cho, K. (2019). Passage re-ranking with BERT. arXiv preprint arXiv:1901.04085.",
    "[22] Qwen Team. (2024). Qwen2.5: A family of language models with advanced capabilities. Alibaba Group.",
    "[23] Google. (2024). Gemini 1.5: Unlocking multimodal understanding across millions of tokens of context. Google Technical Report.",
    "[24] Xiong, L., Xiong, C., Li, Y., Tang, K., Liu, J., Bennett, P., ... & Overwijk, A. (2020). Approximate nearest neighbor negative contrastive learning for dense text retrieval. In International Conference on Learning Representations (ICLR 2021).",
    "[25] Khattab, O., & Zaharia, M. (2020). ColBERT: Efficient and effective passage search via contextualized late interaction over BERT. In Proceedings of the 43rd International ACM SIGIR Conference.",
    "[26] Gao, L., Ma, X., Bendersky, M., & Callan, J. (2022). Precise zero-shot dense retrieval without relevance labels. arXiv preprint arXiv:2212.10496.",
    "[27] Izacard, G., Caron, M., Lucas, T., Mazaré, F., Penido, P., & Grave, E. (2021). Unsupervised dense information retrieval with contrastive learning. arXiv preprint arXiv:2112.09118.",
    "[28] Luan, Y., Eisenstein, J., Sabharwal, A., & Mariño, M. (2021). Sparse, dense, and hybrid retrieval for open-domain question answering. arXiv preprint arXiv:2104.10304.",
    "[29] Wang, Liang, et al. (2022). Text embeddings by weakly-supervised contrastive pre-training. arXiv preprint arXiv:2212.03533.",
    "[30] Edge, D., Trinh, H., Cheng, B., Bradley, J., Chao, A., Mody, A., ... & Larson, J. (2024). From local to global: A graph-rag approach to query-focused summarization. arXiv preprint arXiv:2404.16130."
]

for ref in references:
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.8)
    p.paragraph_format.first_line_indent = Cm(-0.8)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.line_spacing = 1.15
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    
    # Bôi đậm số thứ tự [x]
    parts = ref.split(" ", 1)
    r_num = p.add_run(parts[0] + " ")
    r_num.bold = True
    p.add_run(parts[1])

page_break()

# ============================================================================
# APPENDIX
# ============================================================================
heading("Appendix", 1)

heading("A. RAG System Instruction Template", 2)
para("Dưới đây là prompt hệ thống đầy đủ được sử dụng để điều phối hành vi của LLM trong bước Generation:")

add_pseudocode(
    "Appendix A1: System Instruction for Context-Augmented Generation",
    [
        "SYSTEM_INSTRUCTION = \"\"\"",
        "Bạn là một trợ lý AI thân thiện, chuyên môn cao về Học máy và NLP.",
        "Nhiệm vụ của bạn là trả lời câu hỏi dựa trên các tài liệu ngữ cảnh được cung cấp bên dưới.",
        "",
        "RÀNG BUỘC NGHIÊM NGẶT:",
        "1. Trả lời bằng ngôn ngữ trùng với câu hỏi của người dùng (Tiếng Anh hoặc Tiếng Việt).",
        "2. CHỈ sử dụng thông tin trong ngữ cảnh được cung cấp. Tuyệt đối không bịa đặt thông tin hoặc tự ý sử dụng kiến thức bên ngoài.",
        "3. Trích dẫn nguồn trực tiếp trong câu trả lời bằng cách đặt số thứ tự của tài liệu tham khảo trong dấu ngoặc vuông (ví dụ: [1], [2]).",
        "4. Nếu thông tin trong ngữ cảnh không đủ để trả lời câu hỏi, bạn BẮT BUỘC phải nói rõ: 'Tôi không thể trả lời câu hỏi này dựa trên các tài liệu được cung cấp.' (hoặc 'I cannot answer this question based on the provided context.' nếu câu hỏi bằng tiếng Anh). Tuyệt đối không ảo giác ra câu trả lời.",
        "\"\"\""
    ]
)

heading("B. System Configuration file (src/config.py)", 2)
para("Toàn bộ tham số hoạt động được cấu hình tập trung trong file cấu hình nguồn:")

add_pseudocode(
    "Appendix B1: Trích nguyên văn các hằng số chính của src/config.py",
    [
        "from pathlib import Path",
        "BASE_DIR = Path(__file__).resolve().parent.parent",
        "DATA_DIR = BASE_DIR / \"data\"",
        "DOCUMENTS_DIR = DATA_DIR / \"documents\"",
        "CHROMA_DIR = DATA_DIR / \"chroma\"",
        "",
        "CHUNK_SIZE = 512        # so tu moi chunk (xap xi)",
        "CHUNK_OVERLAP = 64      # so tu chong lan giua 2 chunk lien nhau",
        "SEMANTIC_BREAKPOINT_PERCENTILE = 95.0",
        "",
        "EMBEDDING_MODEL = \"BAAI/bge-m3\"",
        "EMBEDDING_DEVICE = \"cuda\"",
        "INGEST_BATCH_SIZE = 4",
        "EMBEDDING_MAX_TOKENS = 512",
        "NORMALIZE_EMBEDDINGS = True",
        "",
        "COLLECTION_NAME = \"ai_knowledge\"",
        "DISTANCE_METRIC = \"cosine\"",
        "",
        "TOP_K = 20              # so ung vien vector search tra ve (tang 1 - tho)",
        "RERANK_TOP_N = 5        # so chunk tot nhat sau reranker (tang 2 - tinh)",
        "RETRIEVAL_MODE = \"hybrid\"   # \"dense\" | \"bm25\" | \"hybrid\"",
        "RRF_K = 60",
        "",
        "RERANKER_MODEL = \"BAAI/bge-reranker-v2-m3\"",
        "RERANKER_DEVICE = \"cuda\"",
        "RERANKER_MAX_LENGTH = 1024   # tokens (phu 99.5% chunk)",
        "RERANKER_BATCH_SIZE = 4      # tranh 'unlucky batch'",
        "",
        "LLM_MODEL = \"qwen2.5:1.5b\"",
        "OLLAMA_HOST = \"http://localhost:11434\"",
        "LLM_TEMPERATURE = 0.1",
        "LLM_MAX_TOKENS = 1024",
    ]
)

# ============================================================================
OUTPUT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) + "\\reports\\BaoCao_DuAn_RAG.docx"
doc.save(OUTPUT)
print(f"Done: {OUTPUT}")
