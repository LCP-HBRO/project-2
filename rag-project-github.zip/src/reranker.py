"""
reranker.py — Cross-Encoder Reranker (bge-reranker-v2-m3).

LÝ THUYẾT:
    Bi-encoder (bge-m3, dùng ở retriever.py) encode CÂU HỎI và CHUNK RIÊNG BIỆT
    thành 2 vector độc lập, rồi so sánh bằng cosine similarity. Ưu điểm: rất
    nhanh — có thể tính TRƯỚC vector cho hàng nghìn chunk lúc ingest, lúc query
    chỉ cần embed một câu hỏi rồi so sánh. Nhược điểm: 2 vector được tính ĐỘC
    LẬP, không "nhìn thấy nhau" — mất đi các tương tác tinh vi giữa từng từ của
    câu hỏi với từng từ của chunk.

    Cross-encoder (bge-reranker-v2-m3) đưa CẢ câu hỏi VÀ chunk vào CÙNG một lần
    forward pass (nối thành một chuỗi duy nhất), cho phép self-attention "nhìn
    xuyên suốt" cả hai phần cùng lúc -> chính xác hơn NHIỀU so với bi-encoder.
    Cái giá phải trả: không thể tính trước — phải chạy một lần cho MỖI CẶP
    (câu hỏi, chunk), nên không thể áp dụng cho hàng nghìn chunk cùng lúc.

    Đây chính là lý do kiến trúc "hai tầng" (two-stage retrieval) tồn tại:
      Tầng 1 (bi-encoder, RẺ)  -> lọc TOP_K=20 ứng viên từ hàng nghìn chunk.
      Tầng 2 (cross-encoder, ĐẮT nhưng chỉ chạy trên 20 ứng viên) -> chấm lại
              chính xác, giữ RERANK_TOP_N=5 tốt nhất để đưa vào prompt.
    Chỉ dùng tầng 1: nhanh nhưng có thể bỏ sót chunk đúng nằm ngoài top vector-
    similarity thô. Chỉ dùng tầng 2 (chạy cross-encoder trên TOÀN kho): chính
    xác nhất nhưng quá chậm để dùng thực tế. Kết hợp cả hai tận dụng ưu điểm
    của từng loại.

THIẾT KẾ:
    - Dùng sentence_transformers.CrossEncoder (KHÁC với SentenceTransformer ở
      embedding.py) vì đây là kiến trúc khác hẳn: input là CẶP (query, text),
      output là MỘT điểm số liên quan duy nhất — không phải một vector để so
      sánh cosine.
    - Chạy trên GPU (RERANKER_DEVICE trong config.py). QUYẾT ĐỊNH NÀY ĐÃ ĐỔI
      sau khi ĐO THỰC NGHIỆM: ban đầu định để CPU vì lý do ngân sách VRAM, nhưng
      đo thật cho thấy CPU rerank 20 cặp mất tới 23.3s (max_length mặc định của
      model còn khiến nó tệ hơn: 41s — xem RERANKER_MAX_LENGTH trong config.py)
      — quá chậm cho một trợ lý hỏi-đáp tương tác. Trên GPU chỉ mất 2.0s (nhanh
      gấp ~11 lần). Đánh đổi: embedding+reranker cùng lúc trên GPU chiếm đỉnh
      ~5.02GB VRAM, buộc phải giảm LLM xuống bản 1.5B để vừa ngân sách 6GB (xem
      LLM_MODEL trong config.py). Bài học rút ra: ước tính VRAM/latency trên
      giấy có thể sai lệch nhiều — luôn đo thật trước khi quyết định kiến trúc.
    - get_reranker() cache model (cùng mẫu với get_embedder() ở embedding.py) —
      tránh nạp lại model mỗi câu hỏi.
    - batch_size NHỎ (RERANKER_BATCH_SIZE=4, xem giải thích chi tiết + số đo
      thật trong config.py) khi gọi predict(): CrossEncoder tự sắp xếp các cặp
      theo độ dài trước khi tạo batch, nhưng chỉ có tác dụng khi có NHIỀU hơn 1
      batch. Với batch_size mặc định (32) và TOP_K=20, mọi ứng viên luôn rơi
      vào ĐÚNG 1 batch — 1 chunk dài kéo CẢ BATCH chậm theo ("unlucky batch").
      Giảm batch_size buộc tách thành nhiều batch nhỏ, cách ly chunk dài ra.
"""

from functools import lru_cache

from sentence_transformers import CrossEncoder

from src.config import (
    RERANK_TOP_N,
    RERANKER_BATCH_SIZE,
    RERANKER_DEVICE,
    RERANKER_MAX_LENGTH,
    RERANKER_MODEL,
)


class Reranker:
    """Bọc CrossEncoder cho bge-reranker-v2-m3: chấm lại điểm cho từng cặp (câu hỏi, chunk)."""

    def __init__(
        self,
        model_name: str = RERANKER_MODEL,
        device: str = RERANKER_DEVICE,
        max_length: int = RERANKER_MAX_LENGTH,
        batch_size: int = RERANKER_BATCH_SIZE,
    ):
        self.device = device
        self.batch_size = batch_size
        # max_length: xem giải thích trong config.py — model mặc định hỗ trợ tới
        # 8192 token, nhưng chunk của ta không bao giờ dài hơn CHUNK_SIZE. Không
        # giới hạn sẽ khiến CPU xử lý mọi cặp ở độ dài 8192 một cách lãng phí.
        self.model = CrossEncoder(model_name, device=device, max_length=max_length)

    def rerank(self, query: str, hits: list[dict], top_n: int = RERANK_TOP_N) -> list[dict]:
        """
        Nhận danh sách hit từ Retriever (mỗi hit là dict có khoá 'text'), chấm
        lại điểm bằng cross-encoder, trả về top_n hit có điểm CAO NHẤT.

        Thêm khoá 'rerank_score' vào mỗi hit (KHÔNG xoá 'similarity' cũ từ
        retriever — giữ lại để so sánh 2 điểm số khi debug: "bi-encoder xếp
        hạng thế nào" vs "cross-encoder xếp hạng thế nào").
        """
        if not hits:
            return []

        pairs = [(query, hit["text"]) for hit in hits]
        scores = self.model.predict(pairs, batch_size=self.batch_size)

        for hit, score in zip(hits, scores):
            hit["rerank_score"] = float(score)

        return sorted(hits, key=lambda h: h["rerank_score"], reverse=True)[:top_n]


@lru_cache(maxsize=1)
def get_reranker() -> Reranker:
    """Cache model reranker đã nạp — tránh nạp lại (vài giây) mỗi câu hỏi."""
    return Reranker()


if __name__ == "__main__":
    # Chạy `python -m src.reranker "câu hỏi của bạn"` để thử nhanh trên dữ liệu
    # thật (yêu cầu đã chạy `python ingest.py` trước đó) và đo latency CPU thật.
    import sys
    import time

    from src.retriever import Retriever

    query = " ".join(sys.argv[1:]) or "What is the attention mechanism in Transformers?"

    retriever = Retriever()
    hits = retriever.retrieve(query, top_k=20)

    reranker = get_reranker()
    start = time.time()
    reranked = reranker.rerank(query, hits, top_n=5)
    elapsed = time.time() - start

    print(f"Câu hỏi: {query}")
    print(f"Rerank {len(hits)} -> {len(reranked)} ứng viên trong {elapsed:.2f}s (device={reranker.device})\n")
    for rank, hit in enumerate(reranked, start=1):
        meta = hit["metadata"]
        print(
            f"[{rank}] rerank_score={hit['rerank_score']:.3f}  similarity={hit['similarity']:.3f}"
            f"  {meta['source']} (trang {meta['page']})"
        )
        print(f"     {hit['text'][:150]}...\n")
