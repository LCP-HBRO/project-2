"""
scripts/compare_modes.py — So sánh 3 chế độ retrieval (dense / bm25 / hybrid)
trên CÙNG một collection (mặc định = semantic, ai_knowledge) và cùng bộ câu hỏi
vàng, có/không reranker.

Mục đích: cung cấp số liệu định lượng cho mục 5.4 của báo cáo — dense (bge-m3,
ngữ nghĩa) vs bm25 (từ khoá) vs hybrid (RRF gộp cả hai).

Chạy TỪ THƯ MỤC GỐC:  python -m scripts.compare_modes
"""

from evaluation import evaluate_retriever, load_golden_qa
from src.reranker import get_reranker
from src.retriever import Retriever


def main() -> None:
    golden_qa = load_golden_qa()
    retriever = Retriever()  # dùng collection mặc định (semantic) — xem config
    reranker = get_reranker()

    header = (
        f"{'mode':<9} {'reranker':<9} {'hit_rate':<9} {'mrr':<8} "
        f"{'hit_page':<9} {'mrr_page':<9} {'latency_ms':<11}"
    )
    print(header)
    print("-" * len(header))

    for mode in ("dense", "bm25", "hybrid"):
        for label, rr in (("no", None), ("yes", reranker)):
            r = evaluate_retriever(retriever, golden_qa, reranker=rr, mode=mode)
            print(
                f"{mode:<9} {label:<9} {r['hit_rate']:<9.3f} {r['mrr']:<8.3f} "
                f"{r.get('hit_rate_page', float('nan')):<9.3f} "
                f"{r.get('mrr_page', float('nan')):<9.3f} {r['avg_latency_ms']:<11.1f}"
            )


if __name__ == "__main__":
    main()
