"""
evaluation.py — Đánh giá ĐỊNH LƯỢNG chất lượng Retrieval (+ tiện ích cho Generation).

LÝ THUYẾT:
    Tới đây (Ngày 1-4), mọi đánh giá đều là ĐỊNH TÍNH — "nhìn bằng mắt" xem
    chunk trả về có vẻ đúng không (như scripts/compare_chunking.py). Module này
    thêm đánh giá ĐỊNH LƯỢNG bằng một BỘ CÂU HỎI VÀNG (data/golden_qa.json):
    mỗi câu hỏi đã biết trước NGUỒN đúng (file PDF nào chứa câu trả lời), nên ta
    có thể đo Retriever tìm đúng nguồn đó tốt đến đâu — MỘT CON SỐ CỤ THỂ, thay
    vì cảm tính.

    Hai chỉ số retrieval kinh điển:

    1) Hit Rate@k — "Trong top-k kết quả, có xuất hiện nguồn đúng hay không?"
       Nhị phân (0 hoặc 1) cho mỗi câu hỏi, rồi lấy trung bình trên cả bộ câu
       hỏi. Dễ hiểu nhưng THÔ: không phân biệt nguồn đúng nằm ở hạng 1 hay hạng
       20 — miễn có mặt là tính là "hit".

    2) MRR (Mean Reciprocal Rank) — "Nguồn đúng nằm ở HẠNG BAO NHIÊU?"
       Với mỗi câu hỏi, tính 1/hạng của lần xuất hiện ĐẦU TIÊN của nguồn đúng
       (0 nếu không xuất hiện), rồi lấy trung bình. Phạt nặng nếu nguồn đúng bị
       xếp hạng thấp (hạng 10 chỉ được 0.1 điểm) — tinh hơn Hit Rate@k vì quan
       tâm tới THỨ TỰ xếp hạng, không chỉ có mặt hay không.

    MỨC ĐỘ CHI TIẾT CỦA "ĐÚNG": ground truth ở đây là cấp ĐỘ FILE NGUỒN (vd
    "attention_is_all_you_need.pdf"), KHÔNG phải đúng một chunk_index cụ thể.
    Lý do: 3 chiến lược chunking (fixed/recursive/semantic) cắt chunk ở vị trí
    khác nhau hoàn toàn cho CÙNG một tài liệu, nên "đúng chunk_index=5" của
    chiến lược này không có nghĩa gì khi so với chiến lược khác — nhưng "đúng
    file nguồn" thì so sánh được công bằng giữa cả 3 chiến lược.

    ROUGE-L và faithfulness_score (bên dưới) là 2 chỉ số đánh giá GENERATION
    (câu trả lời cuối cùng của Qwen so với đáp án mẫu / so với ngữ cảnh) —
    được viết SẴN ở đây (thuần hàm, không phụ thuộc LLM) để Ngày 6 chỉ cần GỌI
    chúng trên câu trả lời thật, không cần quay lại sửa module này.

Chạy:  python evaluation.py
       (So sánh 3 chiến lược chunking x có/không reranker trên bộ câu hỏi vàng,
       dùng lại 3 collection ChromaDB đã ingest ở Ngày 3 — scripts/compare_chunking.py)
"""

import json
import time
from pathlib import Path

from src.config import DATA_DIR, RERANK_TOP_N, TOP_K
from src.retriever import Retriever

GOLDEN_QA_PATH = DATA_DIR / "golden_qa.json"


def load_golden_qa(path: Path = GOLDEN_QA_PATH) -> list[dict]:
    """Đọc bộ câu hỏi vàng từ JSON: mỗi câu hỏi có 'question' + 'expected_source'."""
    return json.loads(path.read_text(encoding="utf-8"))


# ============================================================================
# CHỈ SỐ RETRIEVAL
# ============================================================================
def hit_rate_at_k(retrieved_sources: list[str], expected_source: str) -> bool:
    """True nếu expected_source xuất hiện Ở BẤT KỲ ĐÂU trong danh sách kết quả."""
    return expected_source in retrieved_sources


def reciprocal_rank(retrieved_sources: list[str], expected_source: str) -> float:
    """1/hạng của lần xuất hiện ĐẦU TIÊN của expected_source; 0.0 nếu không có."""
    for rank, source in enumerate(retrieved_sources, start=1):
        if source == expected_source:
            return 1.0 / rank
    return 0.0


def hit_rate_at_page(retrieved_pairs: list[tuple], expected_source: str, expected_page: int) -> bool:
    """
    Giống hit_rate_at_k nhưng KHẮT KHE HƠN: đòi đúng CẢ file NGUỒN và SỐ TRANG,
    không chỉ đúng file. Xem giải thích đầy đủ ở docstring evaluate_retriever —
    đây là ground truth chi tiết hơn, bổ sung cho hit_rate cấp file vốn cho mọi
    chunk từ đúng file được tính là "đúng" dù chunk đó nói về phần khác của paper.
    """
    return (expected_source, expected_page) in retrieved_pairs


def reciprocal_rank_page(retrieved_pairs: list[tuple], expected_source: str, expected_page: int) -> float:
    """Giống reciprocal_rank nhưng đòi khớp CẢ (source, page)."""
    for rank, pair in enumerate(retrieved_pairs, start=1):
        if pair == (expected_source, expected_page):
            return 1.0 / rank
    return 0.0


def evaluate_retriever(
    retriever: Retriever,
    golden_qa: list[dict],
    top_k: int = TOP_K,
    reranker=None,
    rerank_top_n: int = RERANK_TOP_N,
    mode: str | None = None,
) -> dict:
    """
    Chạy retrieval (có/không truyền `reranker`) trên toàn bộ golden_qa, trả về
    Hit Rate@k, MRR, và latency trung bình mỗi câu hỏi (mili-giây).

    Câu hỏi "unanswerable" (expected_source = None, xem data/golden_qa.json) bị
    BỎ QUA khi tính hit_rate/mrr — Hit Rate@k đo "có tìm thấy nguồn đúng không",
    nhưng với câu KHÔNG CÓ nguồn đúng nào, "không tìm thấy gì" chính là hành vi
    ĐÚNG, không phải một lần "miss" như câu hỏi thường. Trộn 2 loại vào cùng một
    chỉ số sẽ làm Hit Rate/MRR sai lệch không có ý nghĩa. Latency vẫn được đo
    cho MỌI câu hỏi (kể cả unanswerable) vì đó là chi phí retrieval thật.

    GROUND TRUTH CẤP TRANG (hit_rate_page/mrr_page, chỉ xuất hiện trong kết quả
    nếu golden_qa có trường "expected_page"): hit_rate/mrr ở cấp FILE có một
    nhược điểm — bất kỳ chunk nào từ đúng file đều được tính là "đúng", dù chunk
    đó thực ra nói về một phần KHÁC của paper, không liên quan gì tới câu hỏi.
    Ví dụ: hỏi "GPT-3 có bao nhiêu tham số" (câu trả lời ở trang 8) nhưng
    retriever trả về một chunk ở trang 3 nói về kiến trúc — hit_rate cấp file
    vẫn tính là "đúng" (cùng file), còn hit_rate_page sẽ tính là "sai" (không
    đúng trang). Vì số trang được kế thừa từ Document gốc và KHÔNG đổi theo
    chiến lược chunking (khác chunk_index), đây là ground truth so sánh công
    bằng được giữa fixed/recursive/semantic, đồng thời khắt khe hơn cấp file.
    """
    hits = 0
    reciprocal_ranks = []
    page_hits = 0
    page_reciprocal_ranks = []
    n_with_page = 0
    latencies_ms = []
    n_scored = 0

    for item in golden_qa:
        start = time.time()
        try:
            results = retriever.retrieve(item["question"], top_k=top_k, mode=mode)
        except TypeError:
            results = retriever.retrieve(item["question"], top_k=top_k)
        if reranker is not None:
            results = reranker.rerank(item["question"], results, top_n=rerank_top_n)
        latencies_ms.append((time.time() - start) * 1000)

        if item.get("expected_source") is None:
            continue  # câu unanswerable -> không tính vào hit_rate/mrr (xem docstring)

        sources = [r["metadata"]["source"] for r in results]
        hits += hit_rate_at_k(sources, item["expected_source"])
        reciprocal_ranks.append(reciprocal_rank(sources, item["expected_source"]))
        n_scored += 1

        expected_page = item.get("expected_page")
        if expected_page is not None:
            pairs = [(r["metadata"]["source"], r["metadata"]["page"]) for r in results]
            page_hits += hit_rate_at_page(pairs, item["expected_source"], expected_page)
            page_reciprocal_ranks.append(
                reciprocal_rank_page(pairs, item["expected_source"], expected_page)
            )
            n_with_page += 1

    result = {
        "hit_rate": hits / n_scored if n_scored else float("nan"),
        "mrr": sum(reciprocal_ranks) / n_scored if n_scored else float("nan"),
        "avg_latency_ms": sum(latencies_ms) / len(golden_qa),
        "n_questions": n_scored,
    }
    if n_with_page:
        result["hit_rate_page"] = page_hits / n_with_page
        result["mrr_page"] = sum(page_reciprocal_ranks) / n_with_page
        result["n_questions_page"] = n_with_page
    return result


# ============================================================================
# CHỈ SỐ GENERATION (dùng thật từ Ngày 6, khi có câu trả lời của Qwen)
# ============================================================================
def _lcs_length(a: list[str], b: list[str]) -> int:
    """Độ dài Dãy Con Chung Dài Nhất (Longest Common Subsequence) giữa 2 danh sách từ."""
    dp = [[0] * (len(b) + 1) for _ in range(len(a) + 1)]
    for i in range(1, len(a) + 1):
        for j in range(1, len(b) + 1):
            if a[i - 1] == b[j - 1]:
                dp[i][j] = dp[i - 1][j - 1] + 1
            else:
                dp[i][j] = max(dp[i - 1][j], dp[i][j - 1])
    return dp[-1][-1]


def rouge_l(candidate: str, reference: str) -> float:
    """
    ROUGE-L F1: đo mức trùng khớp giữa câu trả lời (candidate) và đáp án mẫu
    (reference), dựa trên LCS theo TỪ — không yêu cầu các từ khớp phải liền kề
    nhau (khác BLEU dùng n-gram khớp CHÍNH XÁC theo cụm), nên khoan dung hơn với
    việc diễn đạt khác thứ tự/chèn thêm từ nhẹ. Trả về 0.0 nếu 1 trong 2 chuỗi
    rỗng.
    """
    cand_words = candidate.split()
    ref_words = reference.split()
    if not cand_words or not ref_words:
        return 0.0

    lcs = _lcs_length(cand_words, ref_words)
    precision = lcs / len(cand_words)
    recall = lcs / len(ref_words)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


REFUSAL_KEYWORDS = [
    "không tìm thấy",
    "không có thông tin",
    "không tìm được",
    "không đủ thông tin",
    "không được đề cập",
    "không được cung cấp",
    "not found",
    "don't know",
    "do not know",
    "no information",
    "not find",  # bắt cả "cannot find", "could not find", "did not find", ...
    "does not contain",
    "not provided",  # đo thật (mục đánh giá refusal) cho thấy Qwen hay dùng cụm này
    "not mentioned",
    "not specified",
    "no mention",
    "no such",
]


def check_refusal(answer: str) -> bool:
    """
    Kiểm tra NHẸ (dựa trên từ khoá) xem câu trả lời có PHẢI một lời từ chối hợp
    lý không — dùng cho câu hỏi loại "unanswerable" trong golden_qa.json, nơi
    hành vi ĐÚNG là thừa nhận không tìm thấy thông tin (đúng như yêu cầu trong
    SYSTEM_INSTRUCTION của prompt_builder.py), KHÔNG PHẢI bịa ra một câu trả
    lời nghe hợp lý (hallucination).
    """
    answer_lower = answer.lower()
    return any(kw in answer_lower for kw in REFUSAL_KEYWORDS)


def evaluate_refusal_behavior(
    golden_qa: list[dict],
    retriever: Retriever,
    reranker=None,
    log_path=Ellipsis,
    answer_fn=None,
    llm_label: str = "qwen",
) -> dict:
    """
    Chạy pipeline ĐẦY ĐỦ (retriever -> reranker -> prompt_builder -> LLM) trên
    các câu hỏi "unanswerable", kiểm tra model có TỪ CHỐI đúng cách hay BỊA câu
    trả lời. Đây là bài test faithfulness quan trọng nhất trong cả bộ: Hit Rate/
    MRR chỉ đo retrieval, KHÔNG đo được việc model có hallucinate ở bước
    generation hay không — chỉ chạy hết pipeline thật mới kiểm tra được.

    `answer_fn` = hàm trả lời một câu hỏi, chữ ký (query, retriever, reranker) ->
    dict có khoá 'answer'. MẶC ĐỊNH None -> dùng Qwen local qua ask.answer_question.
    Truyền ask_gemini.answer_question_gemini để đánh giá Gemini thay vì Qwen —
    nhờ đó có thể SO SÁNH hành vi từ chối giữa 2 LLM trên CÙNG retrieval/reranker
    (thí nghiệm đối chứng: chỉ khác LLM, nên chênh lệch refusal_rate phản ánh
    đúng năng lực từng model). `llm_label` chỉ để ghi vào kết quả cho dễ đọc.

    `log_path=Ellipsis` (giá trị mặc định, KHÁC None) nghĩa là "dùng đường dẫn
    log mặc định của ask.answer_question()" — chỉ áp dụng cho nhánh Qwen mặc
    định (answer_fn=None). Dùng Ellipsis thay vì None vì None ở đây có ý nghĩa
    RIÊNG (tắt hẳn việc ghi log, xem ask.py).
    """
    if answer_fn is None:
        from ask import answer_question

        kwargs = {} if log_path is Ellipsis else {"log_path": log_path}
        answer_fn = lambda q, r, rr: answer_question(q, retriever=r, reranker=rr, **kwargs)

    unanswerable = [item for item in golden_qa if item.get("expected_source") is None]
    details = []
    for item in unanswerable:
        log = answer_fn(item["question"], retriever, reranker)
        details.append(
            {"question": item["question"], "answer": log["answer"], "refused": check_refusal(log["answer"])}
        )

    n_refused = sum(d["refused"] for d in details)
    return {
        "llm": llm_label,
        "n_unanswerable": len(unanswerable),
        "n_correctly_refused": n_refused,
        "refusal_rate": n_refused / len(unanswerable) if unanswerable else float("nan"),
        "details": details,
    }


def faithfulness_score(answer: str, context_chunks: list[str]) -> float:
    """
    Ước lượng NHẸ mức độ câu trả lời "bám" vào ngữ cảnh đã cung cấp: tỉ lệ TỪ
    trong answer cũng xuất hiện ở ít nhất một chunk ngữ cảnh.

    ĐÂY KHÔNG PHẢI faithfulness check production-grade (không dùng NLI hay
    LLM-judge như các hệ thống thật) — chỉ là một tín hiệu LEXICAL rẻ, phát
    hiện trường hợp answer chứa nhiều từ HOÀN TOÀN không xuất hiện ở đâu trong
    context (dấu hiệu hallucination rõ rệt). KHÔNG bắt được lỗi tinh vi hơn
    (dùng đúng từ nhưng diễn giải sai ý — cần LLM-judge mới phát hiện được).
    """
    context_words = set(" ".join(context_chunks).lower().split())
    answer_words = answer.lower().split()
    if not answer_words:
        return 0.0
    grounded = sum(1 for w in answer_words if w in context_words)
    return grounded / len(answer_words)


# ============================================================================
# SO SÁNH: 3 chiến lược chunking x 3 chế độ retrieval x có/không reranker
# ============================================================================
if __name__ == "__main__":
    from src.config import COLLECTION_NAME
    from src.reranker import get_reranker
    from src.vectordb import VectorStore

    golden_qa = load_golden_qa()
    print(f"Đã nạp {len(golden_qa)} câu hỏi vàng.\n")

    reranker = get_reranker()
    header = f"{'strategy':<12} {'mode':<10} {'reranker':<10} {'hit_rate':<10} {'mrr':<8} {'latency_ms':<12}"
    print(header)
    print("-" * len(header))

    for strategy in ("fixed", "recursive", "semantic"):
        store = VectorStore(collection_name=f"{COLLECTION_NAME}_{strategy}")
        retriever = Retriever(store=store)

        for mode in ("dense", "bm25", "hybrid"):
            for label, rr in (("no", None), ("yes", reranker)):
                result = evaluate_retriever(retriever, golden_qa, reranker=rr, mode=mode)
                print(
                    f"{strategy:<12} {mode:<10} {label:<10} {result['hit_rate']:<10.2f} "
                    f"{result['mrr']:<8.3f} {result['avg_latency_ms']:<12.1f}"
                )
