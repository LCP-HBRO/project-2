"""Package tests — kiểm thử độc lập cho từng module (chạy: pytest)."""
