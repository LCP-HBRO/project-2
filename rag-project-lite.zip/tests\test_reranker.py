"""
Test độc lập cho reranker.py.

Cùng chiến lược test 2 tầng như test_embedding.py:
1) Unit test (mặc định, nhanh): thay CrossEncoder thật bằng fake, không tải model.
2) Integration test (@pytest.mark.integration, TẮT mặc định): nạp bge-reranker-v2-m3
   THẬT từ HuggingFace và chấm điểm thật.
   Chạy riêng bằng: pytest tests/test_reranker.py -m integration
"""

import numpy as np
import pytest

import src.reranker as reranker_module
from src.reranker import Reranker, get_reranker


class _FakeCrossEncoder:
    """Giả lập CrossEncoder thật — KHÔNG tải model nào cả, test chạy tức thì.
    Điểm giả: cặp có chứa 'MATCH' trong text -> điểm cao, ngược lại điểm thấp."""

    def __init__(self, model_name, device, max_length=None):
        self.model_name = model_name
        self.device = device
        self.max_length = max_length
        self.predict_calls = []

    def predict(self, pairs, **kwargs):
        self.predict_calls.append((pairs, kwargs))
        return np.array([10.0 if "MATCH" in text else 0.0 for _, text in pairs], dtype=np.float32)


def _hit(text):
    return {"text": text, "similarity": 0.5, "metadata": {"source": "doc.pdf", "page": 1}}


def test_rerank_reorders_by_score_not_original_order(monkeypatch):
    monkeypatch.setattr(reranker_module, "CrossEncoder", _FakeCrossEncoder)
    reranker = Reranker(model_name="fake-model", device="cpu")

    hits = [_hit("khong lien quan"), _hit("MATCH day la cau tra loi dung"), _hit("cung khong lien quan")]
    result = reranker.rerank("cau hoi", hits, top_n=3)

    assert result[0]["text"] == "MATCH day la cau tra loi dung"
    assert result[0]["rerank_score"] > result[1]["rerank_score"]


def test_rerank_respects_top_n(monkeypatch):
    monkeypatch.setattr(reranker_module, "CrossEncoder", _FakeCrossEncoder)
    reranker = Reranker(model_name="fake-model", device="cpu")

    hits = [_hit(f"chunk {i}") for i in range(10)]
    result = reranker.rerank("cau hoi", hits, top_n=3)

    assert len(result) == 3


def test_rerank_empty_hits_returns_empty_list(monkeypatch):
    monkeypatch.setattr(reranker_module, "CrossEncoder", _FakeCrossEncoder)
    reranker = Reranker(model_name="fake-model", device="cpu")

    assert reranker.rerank("cau hoi", []) == []


def test_rerank_preserves_similarity_alongside_rerank_score(monkeypatch):
    monkeypatch.setattr(reranker_module, "CrossEncoder", _FakeCrossEncoder)
    reranker = Reranker(model_name="fake-model", device="cpu")

    hits = [_hit("MATCH")]
    result = reranker.rerank("cau hoi", hits, top_n=1)

    assert result[0]["similarity"] == 0.5   # điểm bi-encoder cũ vẫn còn
    assert "rerank_score" in result[0]        # điểm cross-encoder mới được thêm


def test_reranker_uses_configured_device(monkeypatch):
    monkeypatch.setattr(reranker_module, "CrossEncoder", _FakeCrossEncoder)
    reranker = Reranker(model_name="fake-model", device="cpu")
    assert reranker.model.device == "cpu"


def test_rerank_passes_small_batch_size_to_predict(monkeypatch):
    # Xem giải thích "unlucky batch" trong config.py/reranker.py: batch_size
    # NHỎ là cố ý, để cách ly chunk dài ra khỏi batch chứa chunk ngắn.
    monkeypatch.setattr(reranker_module, "CrossEncoder", _FakeCrossEncoder)
    reranker = Reranker(model_name="fake-model", device="cpu", batch_size=4)

    reranker.rerank("cau hoi", [_hit("a"), _hit("b")])

    _pairs, kwargs = reranker.model.predict_calls[0]
    assert kwargs["batch_size"] == 4


def test_get_reranker_is_cached(monkeypatch):
    monkeypatch.setattr(reranker_module, "CrossEncoder", _FakeCrossEncoder)
    get_reranker.cache_clear()

    first = get_reranker()
    second = get_reranker()

    assert first is second
    get_reranker.cache_clear()


@pytest.mark.integration
def test_real_bge_reranker_scores_relevant_pair_higher():
    """Chỉ chạy khi gọi rõ: pytest tests/test_reranker.py -m integration
    (sẽ tải model thật ~2.3GB từ HuggingFace trong lần chạy đầu tiên)."""
    reranker = Reranker()
    hits = [
        {"text": "The attention mechanism computes a weighted sum of values.", "metadata": {}},
        {"text": "Bananas are a good source of potassium.", "metadata": {}},
    ]

    result = reranker.rerank("What is the attention mechanism?", hits, top_n=2)

    assert result[0]["text"].startswith("The attention mechanism")
    assert result[0]["rerank_score"] > result[1]["rerank_score"]
