# BÁO CÁO KẾT QUẢ ĐÁNH GIÁ ĐỊNH LƯỢNG HỆ THỐNG RAG (EVALUATION RESULTS)

**Ngày xuất báo cáo:** 22/07/2026  
**Tập dữ liệu tài liệu:** 217 tài liệu (17 PDF kinh điển AI/NLP + 200 DOCX toàn văn từ HuggingFace `MaartenGr/arxiv_nlp`, tổng 635 trang/documents).  
**Bộ câu hỏi thử nghiệm (Golden QA):** 38 câu hỏi vàng được thẩm định thủ công.

---

## 1. THỐNG KÊ LƯỢNG CHUNK NẠP VÀO CHROMADB (100% COMPLETE)

| Chiến lược Chunking | Kích thước Chunk (cấu hình) | Tổng số Chunk sinh ra | Tên Collection ChromaDB |
|---|---|---|---|
| **Fixed-size** | 512 từ, 64 từ overlap | **3,421 chunks** | `ai_knowledge_fixed` |
| **Recursive Character** | Ưu tiên `\n\n` -> `\n` -> `. ` -> ` ` | **3,570 chunks** | `ai_knowledge_recursive` |
| **Semantic** | Tách câu, bge-m3 sentence embedding, 95th percentile | **6,324 chunks** | `ai_knowledge_semantic` |

---

## 2. BẢNG KẾT QUẢ ĐÁNH GIÁ ĐỊNH LƯỢNG TOÀN DIỆN (18 TỔ HỢP THỰC NGHIỆM)

| Chiến lược (Strategy) | Chế độ tìm kiếm (Mode) | Reranker (Cross-Encoder) | Hit Rate@k | MRR (Mean Reciprocal Rank) | Avg Latency (ms) |
|---|---|---|---|---|---|
| **fixed** | `dense` | No | **1.00** | 0.980 | 37.1 ms |
| **fixed** | `dense` | Yes (`bge-reranker-v2-m3`) | **1.00** | 0.970 | 3,270.8 ms |
| **fixed** | `bm25` | No | **1.00** | 0.907 | 50.0 ms |
| **fixed** | `bm25` | Yes | **1.00** | **0.985** | 3,730.7 ms |
| **fixed** | `hybrid` | No | **1.00** | 0.965 | 44.9 ms |
| **fixed** | `hybrid` | Yes | **1.00** | **0.985** | 3,797.3 ms |
| **recursive** | `dense` | No | **1.00** | 0.980 | 41.9 ms |
| **recursive** | `dense` | Yes | **1.00** | 0.962 | 32,914.4 ms |
| **recursive** | `bm25` | No | **1.00** | 0.890 | 70.1 ms |
| **recursive** | `bm25` | Yes | **1.00** | **0.985** | 24,198.3 ms |
| **recursive** | `hybrid` | No | **1.00** | 0.949 | 56.8 ms |
| **recursive** | `hybrid` | Yes | **1.00** | **0.985** | 3,542.7 ms |
| **semantic** | `dense` | No | **1.00** | 0.980 | **36.3 ms** |
| **semantic** | `dense` | Yes | **1.00** | 0.970 | 2,563.8 ms |
| **semantic** | `bm25` | No | **1.00** | 0.894 | 64.2 ms |
| **semantic** | `bm25` | Yes | **1.00** | 0.970 | 2,675.5 ms |
| **semantic** | `hybrid` | No | **1.00** | 0.962 | 67.9 ms |
| **semantic** | `hybrid` | Yes | **1.00** | 0.970 | 2,618.7 ms |

---

## 3. PHÂN TÍCH CHUYÊN SÂU & BÀI HỌC KỸ THUẬT (ENGINEERING POST-MORTEM)

1. **Độ chính xác thu hồi (Hit Rate):** Tất cả 18 cấu hình đều đạt **Hit Rate = 1.00 (100%)**, đảm bảo tài liệu chứa câu trả lời đúng luôn nằm trong tập kết quả trả về.
2. **Thứ hạng ưu việt (MRR = 0.985):** Sự kết hợp giữa **BM25 / Hybrid Search + Reranker** đem lại điểm MRR cao nhất (**0.985**), đưa tài liệu chuẩn xác lên vị trí **Top-1 gần như tuyệt đối**.
3. **Phân tích đỗ trễ (Latency Profile):**
   - Không dùng Reranker: Phản hồi cực nhanh từ **36.3ms – 67.9ms** cho 1 câu hỏi.
   - Có Reranker: Đỗ trễ tăng lên **~2.5s – 3.7s** do tính toán ma trận tương quan sâu của Cross-Encoder.
   - Nút thắt ở Recursive Mode: Một số đoạn văn dài không có ranh giới `\n\n` làm kéo dài độ trễ Reranker lên **24s – 32s**. Semantic và Fixed giữ được độ trễ ổn định ở mức ~2.5s.
4. **Giải pháp an toàn phần cứng (GPU Thermal Management):** 
   - Tích hợp kiểm tra nhiệt độ GPU (`nvidia-smi`) vào Embedder: Ngưỡng tối đa 77°C, tự động nghỉ 10s hạ về < 68°C.
   - Đặt `INGEST_BATCH_SIZE = 4` và `block_size = 32` giúp triệt tiêu hoàn toàn sự cố sập nguồn/TDR driver crash trên GPU Laptop RTX 3050.
5. **Xử lý giới hạn ChromaDB:** Đặt đợt `upsert` tối đa 4,000 chunks/batch để tránh quá tải giới hạn SQLite (`5461`).

---

## 4. BƯỚC THỬ NGHIỆM TIẾP THEO (NEXT STEPS TO TEST)

1. **Đánh giá End-to-End LLM Generation (Sinh câu trả lời):**
   - Chạy pipeline đầy đủ qua `Qwen2.5-1.5B-Instruct` trên 38 câu hỏi vàng.
   - Đo chỉ số **ROUGE-L** (độ tương đồng văn bản so với đáp án chuẩn).
   - Đo chỉ số **Faithfulness Score** (tỉ lệ từ bám sát ngữ cảnh retrieved chunks để kiểm tra hiện tượng hallucination).
   - Đo **Refusal Rate** (tỉ lệ từ chối chuẩn xác cho các câu hỏi không có trong tài liệu).
2. **Đo đạc phân rã đỗ trễ từng bước (Latency Breakdown):**
   - Ghi log chi tiết đỗ trễ của từng công đoạn: `retrieval_ms` vs `reranker_ms` vs `llm_generation_ms`.
3. **Thử nghiệm giao diện tương tác (Streamlit UI):**
   - Khởi chạy web app tương tác (`streamlit run app.py`) để kiểm thử trải nghiệm hỏi đáp thực tế.
