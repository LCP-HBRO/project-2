"""
download_corpus.py — Tải bộ paper nền tảng (PDF) từ arXiv về data/documents/.

Chạy:  python scripts/download_corpus.py

Chỉ tải các PDF paper (đơn giản, HTTP GET trực tiếp từ arxiv.org). Các trang
docs công cụ (ChromaDB, FAISS, Sentence-Transformers, LangChain, LlamaIndex,
Ollama) nên lưu thủ công dưới dạng .md vì mỗi trang một cấu trúc HTML khác nhau,
không đáng viết scraper riêng cho một dự án học tập.
"""

import sys
import ssl
import urllib.request
from pathlib import Path

import certifi

if sys.platform == "win32":
    # Xem giải thích đầy đủ trong src/config.py: console Windows mặc định
    # (cp1252) không hiển thị được tiếng Việt có dấu.
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

# Python trên Windows đôi khi không liên kết đúng kho chứng chỉ hệ thống cho
# urllib -> SSLCertVerificationError. Dùng bundle chứng chỉ của certifi (vẫn
# xác thực SSL đầy đủ, chỉ đổi NGUỒN chứng chỉ tin cậy) thay vì tắt xác thực.
_SSL_CONTEXT = ssl.create_default_context(cafile=certifi.where())

DOCUMENTS_DIR = Path(__file__).resolve().parent.parent / "data" / "documents"

# (tên file lưu, arXiv ID) — mỗi paper phủ một chủ đề trong 12 chủ đề của assistant
PAPERS = [
    ("attention_is_all_you_need.pdf", "1706.03762"),
    ("bert.pdf", "1810.04805"),
    ("gpt3_few_shot_learners.pdf", "2005.14165"),
    ("instructgpt_rlhf.pdf", "2203.02155"),
    ("mistral_7b.pdf", "2310.06825"),
    ("rag_original.pdf", "2005.11401"),
    ("self_rag.pdf", "2310.11511"),
    ("hyde_hypothetical_document_embeddings.pdf", "2212.10496"),
    ("lost_in_the_middle.pdf", "2307.03172"),
    ("sentence_bert.pdf", "1908.10084"),
    ("dense_passage_retrieval.pdf", "2004.04906"),
    ("bge_m3.pdf", "2402.03216"),
    ("faiss_billion_scale.pdf", "1702.08734"),
    ("chain_of_thought_prompting.pdf", "2201.11903"),
    ("lora.pdf", "2106.09685"),
    ("react_reasoning_acting.pdf", "2210.03629"),
    ("toolformer.pdf", "2302.04761"),
]

USER_AGENT = "Mozilla/5.0 (educational RAG project; contact via chat)"


def download_paper(filename: str, arxiv_id: str) -> None:
    dest = DOCUMENTS_DIR / filename
    if dest.exists():
        print(f"[skip] {filename} đã tồn tại")
        return

    url = f"https://arxiv.org/pdf/{arxiv_id}"
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, context=_SSL_CONTEXT) as response:
        data = response.read()
    dest.write_bytes(data)
    print(f"[ok]   {filename}  ({len(data) / 1024:.0f} KB)")


if __name__ == "__main__":
    DOCUMENTS_DIR.mkdir(parents=True, exist_ok=True)
    for filename, arxiv_id in PAPERS:
        download_paper(filename, arxiv_id)
    print(f"\nHoàn tất. Kiểm tra {DOCUMENTS_DIR}")
