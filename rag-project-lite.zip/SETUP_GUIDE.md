# 🚀 HƯỚNG DẪN SETUP & TIẾP TỤC DỰ ÁN RAG TRÊN MÁY MỚI

## Bước 1: Giải nén

Giải nén `rag-project.zip` vào thư mục bất kỳ, ví dụ:
```
D:\rag-project\
```

---

## Bước 2: Cài Python (nếu chưa có)

- Cần **Python 3.10+** (khuyên 3.11 hoặc 3.12)
- Tải từ https://www.python.org/downloads/
- Tick **"Add Python to PATH"** khi cài

---

## Bước 3: Tạo Virtual Environment

```powershell
cd D:\rag-project
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

> Nếu lỗi Execution Policy:
> ```powershell
> Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
> ```

---

## Bước 4: Cài PyTorch với CUDA (QUAN TRỌNG)

**Phải cài PyTorch bản CUDA TRƯỚC, rồi mới cài requirements.txt.**

### Nếu máy có GPU NVIDIA:
```powershell
# Kiểm tra phiên bản CUDA:
nvidia-smi
# Xem dòng "CUDA Version: XX.X"

# Cài torch cho CUDA 12.1 (phổ biến nhất):
pip install torch --index-url https://download.pytorch.org/whl/cu121

# Hoặc CUDA 12.4:
pip install torch --index-url https://download.pytorch.org/whl/cu124

# Kiểm tra:
python -c "import torch; print(torch.cuda.is_available())"
# Phải in: True
```

### Nếu máy KHÔNG có GPU NVIDIA:
```powershell
pip install torch
```
Sau đó sửa file `src/config.py`:
- `EMBEDDING_DEVICE = "cpu"` (dòng ~78)
- `RERANKER_DEVICE = "cpu"` (dòng ~126)

---

## Bước 5: Cài thư viện

```powershell
pip install -r requirements.txt
```

---

## Bước 6: Cài Ollama + Model Qwen

1. Tải Ollama: https://ollama.ai/download
2. Cài đặt và mở Ollama
3. Tải model:
```powershell
ollama pull qwen2.5:1.5b
```
4. Kiểm tra:
```powershell
ollama list
# Phải thấy qwen2.5:1.5b
```

---

## Bước 7: Cấu hình GPU cho LLM (tuỳ máy)

Mở file `src/config.py`, tìm dòng `LLM_NUM_GPU`:

```python
LLM_NUM_GPU = 0   # Hiện tại = 0 (chạy CPU) vì máy cũ bị quá nhiệt
```

| GPU máy mới | Chỉnh thành |
|---|---|
| Không có GPU | `LLM_NUM_GPU = 0` |
| GPU yếu (< 6GB VRAM) | `LLM_NUM_GPU = 0` |
| GPU trung bình (6-8GB) | `LLM_NUM_GPU = 99` (thử, nếu crash thì đổi lại 0) |
| GPU mạnh (> 8GB) | `LLM_NUM_GPU = 99` |

---

## Bước 8: Kiểm tra hệ thống hoạt động

### Test nhanh 1 câu hỏi qua pipeline:
```powershell
python -u debug_single_qa.py
```

Kết quả mong đợi:
```
[1/5] Importing modules... OK
[2/5] Loading Embedder... OK
[3/5] Loading Retriever... OK
[4/5] Loading Reranker... OK
[5/5] Running single question... SUCCESS
Answer: The attention mechanism in Transformers...
Retrieval: XXms | Rerank: XXms | LLM: XXms | Total: XXms
```

Nếu lỗi ở bước nào, xem hướng dẫn khắc phục ở cuối file.

---

## Bước 9: Chạy Generation Evaluation (VIỆC CHÍNH CÒN LẠI)

```powershell
python -u run_gen_eval.py
```

### Script này sẽ:
- Chạy 38 câu hỏi từ `data/golden_qa.json` qua full RAG pipeline
- Đo 4 chỉ số: **ROUGE-L, Faithfulness, Refusal Rate, Latency**
- Lưu checkpoint sau mỗi câu vào `reports/generation_evaluation_temp.json`
- **Nếu bị crash → chạy lại lệnh trên, tự resume từ câu cuối**
- Kết quả cuối cùng: `reports/generation_evaluation_results.json`

### Thời gian ước tính:
- GPU (LLM_NUM_GPU=99): ~5-10 phút
- CPU (LLM_NUM_GPU=0): ~20-25 phút

### Log chạy:
- Console + `reports/gen_eval_progress.log`

---

## Bước 10: Đọc kết quả

Sau khi chạy xong, mở `reports/generation_evaluation_results.json`:
```json
{
  "avg_rouge_l": 0.XXXX,
  "avg_faithfulness_score": 0.XXXX,
  "refusal_rate": 0.XXXX,
  "avg_retrieval_latency_ms": XX.X,
  "avg_reranker_latency_ms": XX.X,
  "avg_llm_latency_ms": XX.X,
  "avg_total_latency_ms": XX.X,
  "details": [...]
}
```

---

## Tổng hợp tất cả kết quả đã có

### Retrieval Evaluation (ĐÃ XONG — 18 tổ hợp)
File: `reports/evaluation_results.json` và `reports/evaluation_results.md`

| Chỉ số | Kết quả |
|---|---|
| Hit Rate | **100%** (tất cả 18 tổ hợp) |
| MRR cao nhất | **0.985** (BM25+Reranker, Hybrid+Reranker) |
| Latency nhanh nhất | **37ms** (Dense, không reranker) |

### Generation Evaluation (CẦN CHẠY)
File: `reports/generation_evaluation_results.json` (tạo sau khi chạy bước 9)

---

## Cấu trúc thư mục quan trọng

```
rag-project/
├── src/                    # Source code chính
│   ├── config.py           # ⭐ CẤU HÌNH TOÀN BỘ HỆ THỐNG
│   ├── loader.py           # Đọc PDF
│   ├── chunker.py          # 3 chiến lược chunking
│   ├── embedding.py        # Embedder (bge-m3)
│   ├── vectordb.py         # ChromaDB wrapper
│   ├── bm25.py             # BM25 sparse search
│   ├── retriever.py        # Dense/BM25/Hybrid retrieval
│   ├── reranker.py         # Cross-encoder reranker
│   ├── llm.py              # Giao tiếp Ollama (Qwen)
│   └── prompt_builder.py   # Prompt template tiếng Việt
├── data/
│   ├── documents/          # 217 PDF papers
│   ├── chroma/             # ChromaDB vector index (đã ingest sẵn)
│   └── golden_qa.json      # 38 câu hỏi đánh giá
├── reports/
│   ├── evaluation_results.json   # ✅ Kết quả retrieval (đã xong)
│   ├── evaluation_results.md     # ✅ Báo cáo retrieval markdown
│   └── handoff_summary.md        # ⭐ Tóm tắt toàn bộ dự án cho AI viết báo cáo
├── ask.py                  # Full RAG pipeline (Qwen local)
├── ask_gemini.py           # RAG pipeline (Gemini API)
├── evaluation.py           # Metrics: Hit Rate, MRR, ROUGE-L, Faithfulness
├── ingest.py               # Script nạp PDF vào ChromaDB
├── app.py                  # Streamlit UI
├── run_gen_eval.py         # ⭐ CHẠY FILE NÀY để đánh giá generation
├── debug_single_qa.py      # Test nhanh 1 câu
└── requirements.txt        # Thư viện Python
```

---

## Khắc phục lỗi thường gặp

### Lỗi: "torch.cuda.is_available() = False"
→ Cài lại PyTorch bản CUDA (Bước 4)

### Lỗi: "Không kết nối được Ollama"
→ Mở app Ollama hoặc chạy `ollama serve`

### Lỗi: "model qwen2.5:1.5b not found"
→ Chạy `ollama pull qwen2.5:1.5b`

### Lỗi: GPU quá nhiệt / máy reset
→ Đổi `LLM_NUM_GPU = 0` trong `src/config.py`
→ Chạy lại `python -u run_gen_eval.py` (tự resume từ checkpoint)

### Lỗi: "UnicodeEncodeError" khi in tiếng Việt
→ Chạy lệnh: `$env:PYTHONIOENCODING="utf-8"` trước khi chạy script

### Lỗi: ChromaDB "collection not found"
→ Cần ingest lại: `python ingest.py` (mất ~15-30 phút tuỳ GPU)
