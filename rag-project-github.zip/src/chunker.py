"""
chunker.py — Text Cleaning + Chunking.

LÝ THUYẾT:
    Đây là module quan trọng NHẤT của toàn bộ hệ thống Retrieval. Vì sao?
    Embedding model chỉ có thể "hiểu" được một đoạn văn ngắn cùng lúc — nếu chunk
    quá dài, vector sinh ra sẽ là một bản "trung bình" mờ nhạt của nhiều ý khác
    nhau (chủ đề bị pha loãng), khiến vector search không tìm đúng đoạn cần thiết.
    Ngược lại, nếu chunk quá ngắn hoặc bị cắt giữa câu, ta mất ngữ cảnh cần để
    trả lời đúng. Toàn bộ chất lượng RAG thường bị quyết định ở BƯỚC NÀY nhiều hơn
    là ở việc chọn LLM nào.

    Ta cài 3 CHIẾN LƯỢC để so sánh (sẽ đo thực nghiệm ở Ngày 3 & 5):

    1) chunk_fixed — "Fixed-size splitting"
       Cắt văn bản thành từng cụm N từ liên tiếp, có phần chồng lấn (overlap).
       Ưu điểm: đơn giản, tốc độ, kích thước chunk luôn đều nhau (dễ dự đoán
       chi phí embedding). Nhược điểm: HOÀN TOÀN không quan tâm ranh giới câu/
       đoạn văn -> có thể cắt đứt ngay giữa một ý quan trọng.

    2) chunk_recursive — "Structure-aware / recursive splitting"
       Ưu tiên cắt theo ranh giới TỰ NHIÊN của văn bản: đoạn văn (\\n\\n) trước,
       rồi tới dòng (\\n), rồi tới câu (". "), rồi mới tới từ — chỉ "hạ cấp"
       xuống ranh giới mịn hơn khi mảnh hiện tại vẫn còn quá dài. Sau đó gộp các
       mảnh nhỏ lại thành chunk gần với CHUNK_SIZE nhất có thể.
       Ưu điểm: chunk có xu hướng là các đơn vị ý nghĩa trọn vẹn (một đoạn văn,
       một luận điểm). Nhược điểm: code phức tạp hơn, kích thước chunk dao động.

    Đây chính là kỹ thuật đứng sau "RecursiveCharacterTextSplitter" nổi tiếng của
    LangChain — ở đây ta tự cài để hiểu rõ CÁCH NÓ HOẠT ĐỘNG, không dùng thư viện.

    3) chunk_semantic — "Semantic / embedding-based splitting"
       Tách văn bản thành CÂU, dùng chính bge-m3 để embed từng câu, rồi đo cosine
       similarity giữa 2 câu LIÊN TIẾP. Nơi similarity TỤT XUỐNG bất thường (so
       với phân bố similarity của chính tài liệu đó, đo bằng percentile — xem
       SEMANTIC_BREAKPOINT_PERCENTILE trong config.py) được coi là "ranh giới
       chủ đề" -> cắt tại đó.
       Ưu điểm: ranh giới chunk bám theo Ý NGHĨA thay vì hình thức (dấu câu/thụt
       lề) -> tốt cho văn bản có cấu trúc kém rõ ràng.
       Nhược điểm: CHẬM (phải embed từng câu trước khi ingest, không chỉ embed
       chunk cuối cùng như 2 chiến lược trên) và cần MỘT MODEL EMBEDDING sẵn có
       -> phá vỡ tính "không phụ thuộc model" mà chunk_fixed/chunk_recursive có
       được; kết quả cũng nhạy với percentile chọn.
       Khác biệt thiết kế quan trọng với chunk_recursive: chunk_semantic KHÔNG
       gộp các mảnh nhỏ lại với nhau để đạt chunk_size (xem chú thích trong hàm)
       — vì ranh giới ở đây MANG Ý NGHĨA (chỗ đổi chủ đề), gộp lại sẽ triệt tiêu
       chính lợi ích mà semantic chunking mang lại.

XẤP XỈ "TOKEN" BẰNG "TỪ":
    Embedding model đếm theo TOKEN (mảnh sub-word), không phải theo TỪ tiếng Anh
    cách nhau bởi dấu cách. Đếm token thật cần nạp tokenizer của bge-m3 (việc đó
    thuộc về embedding.py ở Ngày 2 — nạp cả model chỉ để đếm token là quá nặng
    cho module này). Ở đây ta dùng SỐ TỪ (`text.split()`) làm XẤP XỈ cho số token
    — với văn bản tiếng Anh, 1 từ thường xấp xỉ 1.3 token, nên CHUNK_SIZE=512 từ
    thực tế sẽ cho ra khoảng 600-700 token — vẫn nằm trong giới hạn an toàn.
    Đây là một sự đánh đổi có chủ ý: đơn giản, không phụ thuộc model, đủ tốt cho
    mục đích học tập. (Nếu muốn chính xác tuyệt đối, có thể thay `count_words`
    bằng tokenizer thật ở bước tinh chỉnh sau.)
"""

import re
from dataclasses import dataclass

import numpy as np

from src.config import CHUNK_OVERLAP, CHUNK_SIZE, SEMANTIC_BREAKPOINT_PERCENTILE
from src.loader import Document

# Thứ tự ưu tiên ranh giới cắt: từ "tự nhiên nhất" (đoạn văn) tới "cưỡng ép nhất" (từ).
# chunk_recursive sẽ thử lần lượt từng separator, chỉ hạ xuống mức tiếp theo khi
# mức hiện tại không tách được gì (vd văn bản không có "\n\n" nào).
SEPARATORS = ["\n\n", "\n", ". ", " "]


@dataclass
class Chunk:
    """Một đơn vị văn bản đã sẵn sàng để embedding, kèm đủ metadata để trích dẫn."""
    text: str
    source: str          # tên file gốc, kế thừa từ Document
    page: int | None      # số trang gốc (None nếu là .md/.txt)
    chunk_index: int      # thứ tự chunk trong tài liệu (0, 1, 2, ...)
    strategy: str         # "fixed" / "recursive" / "semantic" — để so sánh sau này


# ============================================================================
# TEXT CLEANING
# ============================================================================
def clean_text(text: str) -> str:
    """
    Làm sạch văn bản thô trước khi cắt chunk.

    Vì sao cần: văn bản trích từ PDF thường có ký tự null, khoảng trắng thừa do
    layout nhiều cột, hoặc quá nhiều dòng trống liên tiếp. Nếu không làm sạch,
    những "rác" này sẽ bị tính vào chunk_size và làm nhiễu văn bản đưa vào embedding.
    """
    text = text.replace("\x00", "")                 # PyMuPDF đôi khi chèn ký tự null
    text = re.sub(r"[ \t]+", " ", text)              # gộp nhiều khoảng trắng/tab liên tiếp
    text = re.sub(r"\n{3,}", "\n\n", text)           # tối đa 1 dòng trống giữa 2 đoạn văn
    text = "\n".join(line.strip() for line in text.split("\n"))  # xoá khoảng trắng đầu/cuối mỗi dòng
    return text.strip()


def count_words(text: str) -> int:
    """Đếm số từ — dùng làm xấp xỉ cho số token (xem giải thích ở đầu file)."""
    return len(text.split())


# ============================================================================
# CHIẾN LƯỢC 1: FIXED-SIZE SPLITTING
# ============================================================================
def chunk_fixed(
    text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP
) -> list[str]:
    """
    Cắt `text` thành các cụm `chunk_size` từ liên tiếp, trượt cửa sổ với bước
    nhảy (chunk_size - overlap) để tạo phần chồng lấn giữa 2 chunk kề nhau.

    Ví dụ minh hoạ (chunk_size=4, overlap=1, text="a b c d e f g"):
        chunk 0: "a b c d"
        chunk 1: "d e f g"   <- "d" được lặp lại (overlap) để không mất ngữ cảnh
    """
    words = text.split()
    step = chunk_size - overlap
    if step <= 0:
        raise ValueError("overlap phải nhỏ hơn chunk_size, nếu không vòng lặp không tiến lên được")

    chunks = []
    for start in range(0, len(words), step):
        piece = words[start : start + chunk_size]
        if not piece:
            break
        chunks.append(" ".join(piece))
        if start + chunk_size >= len(words):
            break
    return chunks


# ============================================================================
# CHIẾN LƯỢC 2: RECURSIVE (STRUCTURE-AWARE) SPLITTING
# ============================================================================
def _recursive_split(text: str, separators: list[str], chunk_size: int) -> list[str]:
    """
    Tách `text` đệ quy theo `separators`, chỉ hạ xuống separator mịn hơn khi
    mảnh hiện tại vẫn còn dài hơn chunk_size. Kết quả: các mảnh nhỏ hơn hoặc
    bằng chunk_size, ưu tiên giữ nguyên ranh giới đoạn văn/câu khi có thể.
    """
    if count_words(text) <= chunk_size or not separators:
        return [text]

    sep, *rest = separators
    parts = [p for p in text.split(sep) if p.strip()]

    if len(parts) == 1:
        # separator này không tách được gì có ý nghĩa (vd không có "\n\n" trong đoạn)
        # -> thử separator mịn hơn tiếp theo trong danh sách.
        return _recursive_split(text, rest, chunk_size)

    result: list[str] = []
    for part in parts:
        result.extend(_recursive_split(part, rest, chunk_size))
    return result


def _merge_pieces(pieces: list[str], chunk_size: int, overlap: int) -> list[str]:
    """
    Gộp các mảnh nhỏ (từ _recursive_split) lại thành chunk gần chunk_size nhất
    có thể — tránh tình trạng mỗi đoạn văn ngắn trở thành một chunk lãng phí.
    Khi một chunk đầy, `overlap` từ cuối cùng được mang sang chunk kế tiếp.
    """
    chunks: list[str] = []
    current: list[str] = []

    for piece in pieces:
        piece_words = piece.split()
        if current and len(current) + len(piece_words) > chunk_size:
            chunks.append(" ".join(current))
            current = current[-overlap:] if overlap else []
        current.extend(piece_words)

    if current:
        chunks.append(" ".join(current))
    return chunks


def chunk_recursive(
    text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP
) -> list[str]:
    """Cắt `text` theo chiến lược recursive: tách theo cấu trúc rồi gộp lại tới chunk_size."""
    pieces = _recursive_split(text, SEPARATORS, chunk_size)
    return _merge_pieces(pieces, chunk_size, overlap)


# ============================================================================
# CHIẾN LƯỢC 3: SEMANTIC (EMBEDDING-BASED) SPLITTING
# ============================================================================
_SENTENCE_BOUNDARY = re.compile(r"(?<=[.!?])\s+")


def _split_sentences(text: str) -> list[str]:
    """
    Tách `text` thành câu bằng một heuristic ĐƠN GIẢN (regex trên dấu . ! ?).

    LƯU Ý: đây KHÔNG phải sentence segmentation hoàn chỉnh — nó sẽ tách sai ở
    các trường hợp như viết tắt ("Dr.", "e.g.") hay số thập phân ("3.14"). Sentence
    segmentation chính xác cần thư viện NLP chuyên dụng (spaCy, nltk), nằm ngoài
    phạm vi "tự cài từ đầu" của dự án học tập này — một heuristic đơn giản là đủ
    để minh hoạ ý tưởng cốt lõi của semantic chunking.
    """
    return [s.strip() for s in _SENTENCE_BOUNDARY.split(text) if s.strip()]


def chunk_semantic(
    text: str,
    embedder,
    chunk_size: int = CHUNK_SIZE,
    overlap: int = CHUNK_OVERLAP,
    breakpoint_percentile: float = SEMANTIC_BREAKPOINT_PERCENTILE,
) -> list[str]:
    """
    Cắt `text` theo ranh giới NGỮ NGHĨA thay vì cấu trúc hình thức.

    `embedder` phải có phương thức `embed_texts(list[str]) -> ndarray` (xem
    src.embedding.Embedder) — được TIÊM VÀO thay vì tự nạp model bên trong hàm,
    để: (1) dùng chung một model đã nạp sẵn với bước embed chunk cuối cùng
    (tránh nạp model 2 lần), và (2) dễ test bằng embedder giả (xem tests/test_chunker.py).
    """
    sentences = _split_sentences(text)
    if len(sentences) <= 1:
        return [text] if text.strip() else []

    # NORMALIZE_EMBEDDINGS=True trong config -> vector đã chuẩn hoá độ dài 1,
    # nên tích vô hướng (dot product) CHÍNH LÀ cosine similarity, không cần
    # chia thêm cho norm.
    vectors = embedder.embed_texts(sentences)
    similarities = np.array(
        [float(np.dot(vectors[i], vectors[i + 1])) for i in range(len(vectors) - 1)]
    )
    distances = 1.0 - similarities  # khoảng cách ngữ nghĩa giữa 2 câu liên tiếp

    # Điểm gãy = những chỗ khoảng cách LỚN BẤT THƯỜNG so với phần còn lại của
    # CHÍNH tài liệu này (percentile) — tự thích nghi với từng văn bản, thay vì
    # một ngưỡng cố định (một đoạn văn học thuật và một đoạn hội thoại có phân
    # bố similarity rất khác nhau, ngưỡng cố định sẽ không hợp với cả hai).
    threshold = np.percentile(distances, breakpoint_percentile)
    # Dùng ">=" thay vì ">": với văn bản rất ngắn (chỉ 2 câu -> 1 khoảng cách
    # duy nhất), percentile của một mảng 1 phần tử CHÍNH LÀ giá trị đó, nên so
    # sánh nghiêm ngặt ">" sẽ không bao giờ đúng và không điểm gãy nào được tìm
    # thấy dù 2 câu khác chủ đề rõ rệt.
    breakpoints = {i for i, d in enumerate(distances) if d >= threshold}

    pieces: list[str] = []
    current = [sentences[0]]
    for i in range(1, len(sentences)):
        if (i - 1) in breakpoints:
            pieces.append(" ".join(current))
            current = []
        current.append(sentences[i])
    pieces.append(" ".join(current))

    # KHÔNG gộp các mảnh ngữ nghĩa lại với nhau (khác chunk_recursive ở trên).
    # Ranh giới vừa tìm được MANG Ý NGHĨA (chỗ đổi chủ đề) — nếu gộp lại chỉ để
    # đạt chunk_size, ta sẽ trộn 2 chủ đề vào một chunk, triệt tiêu chính lợi
    # ích mà semantic chunking mang lại so với recursive. Ta chỉ SUB-SPLIT một
    # mảnh nếu nó vẫn dài hơn chunk_size (dùng lại logic recursive cho việc này).
    result: list[str] = []
    for piece in pieces:
        if count_words(piece) <= chunk_size:
            result.append(piece)
        else:
            sub_pieces = _recursive_split(piece, SEPARATORS, chunk_size)
            result.extend(_merge_pieces(sub_pieces, chunk_size, overlap))
    return result


# ============================================================================
# ĐIỂM VÀO: nối Document (từ loader) -> Chunk
# ============================================================================
_STRATEGIES = {"fixed": chunk_fixed, "recursive": chunk_recursive}


def chunk_documents(
    documents: list[Document],
    strategy: str = "recursive",
    chunk_size: int = CHUNK_SIZE,
    overlap: int = CHUNK_OVERLAP,
    embedder=None,
) -> list[Chunk]:
    """
    Làm sạch + cắt chunk cho toàn bộ danh sách Document, giữ nguyên metadata
    (source, page) để mỗi Chunk vẫn biết mình "sinh ra từ đâu".

    `embedder` CHỈ bắt buộc khi strategy="semantic" (xem chunk_semantic ở trên).
    """
    if strategy == "semantic":
        if embedder is None:
            raise ValueError(
                "strategy='semantic' cần truyền tham số embedder "
                "(xem src.embedding.get_embedder())"
            )
        chunk_fn = lambda text, cs, ov: chunk_semantic(text, embedder, cs, ov)
    elif strategy in _STRATEGIES:
        chunk_fn = _STRATEGIES[strategy]
    else:
        raise ValueError(
            f"strategy phải là một trong {list(_STRATEGIES) + ['semantic']}, nhận '{strategy}'"
        )

    chunks: list[Chunk] = []
    for doc in documents:
        cleaned = clean_text(doc.text)
        pieces = chunk_fn(cleaned, chunk_size, overlap)
        for i, piece in enumerate(pieces):
            chunks.append(
                Chunk(
                    text=piece,
                    source=doc.source,
                    page=doc.page,
                    chunk_index=i,
                    strategy=strategy,
                )
            )
    return chunks


if __name__ == "__main__":
    # Chạy `python -m src.chunker` từ thư mục gốc để so sánh cả 3 chiến lược
    # trên dữ liệu thật. Chiến lược "semantic" sẽ nạp model bge-m3 (đã tải sẵn).
    from src.embedding import get_embedder
    from src.loader import load_documents

    docs = load_documents()
    for strategy in ("fixed", "recursive", "semantic"):
        kwargs = {"embedder": get_embedder()} if strategy == "semantic" else {}
        chunks = chunk_documents(docs, strategy=strategy, **kwargs)
        sizes = [count_words(c.text) for c in chunks]
        avg = sum(sizes) / len(sizes) if sizes else 0
        print(f"[{strategy}] {len(chunks)} chunk, kích thước trung bình ~{avg:.0f} từ")
