"""
prompt_builder.py — Dựng prompt cuối cùng gửi cho Qwen.

LÝ THUYẾT:
    Đây là nơi "grounding" (neo câu trả lời vào ngữ cảnh thật) xảy ra. LLM
    không tự biết đâu là "sự thật" — nó chỉ tiếp tục chuỗi văn bản theo xác
    suất. Nếu prompt không NÓI RÕ "chỉ dùng thông tin dưới đây, nếu không có
    thì nói không biết", model có xu hướng BỊA (hallucinate) dựa trên kiến thức
    huấn luyện sẵn thay vì ngữ cảnh vừa truy xuất — đánh mất toàn bộ lý do ta
    xây RAG thay vì hỏi thẳng LLM.

    2 nguyên tắc thiết kế áp dụng ở đây:
      1. Mỗi chunk được ĐÁNH SỐ + GẮN NGUỒN (vd "[1] (source.pdf, trang 3)") để
         model có thể TRÍCH DẪN ngay trong câu trả lời — yêu cầu này được nêu
         rõ trong SYSTEM_INSTRUCTION bên dưới, không phải model tự "đoán ra".
      2. Ngữ cảnh được đặt NGAY TRƯỚC câu hỏi (không chôn ở đầu prompt quá xa) —
         corpus của chính dự án này có bài "Lost in the Middle" cho thấy vị trí
         thông tin trong context ảnh hưởng chất lượng model sử dụng nó.

THIẾT KẾ:
    build_prompt() là một HÀM THUẦN (không có class, không giữ trạng thái):
    nhận query + list chunk đã rerank (dict có 'text', 'metadata'), trả về MỘT
    chuỗi string duy nhất sẵn sàng gửi cho llm.py.
"""

from src.config import ANSWER_LANGUAGE

SYSTEM_INSTRUCTION = f"""Bạn là một trợ lý AI trả lời câu hỏi DỰA HOÀN TOÀN vào phần NGỮ CẢNH được cung cấp dưới đây.

QUY TẮC BẮT BUỘC:
1. CHỈ dùng thông tin có trong NGỮ CẢNH. KHÔNG dùng kiến thức bên ngoài.
2. Nếu NGỮ CẢNH không đủ để trả lời, hãy trả lời: "Tôi không tìm thấy thông tin này trong tài liệu được cung cấp."
3. Sau mỗi ý, TRÍCH DẪN nguồn bằng ký hiệu [số] tương ứng với đoạn ngữ cảnh đã dùng.
4. Trả lời bằng {ANSWER_LANGUAGE}, ngắn gọn, chính xác."""


def _format_context(chunks: list[dict]) -> str:
    """
    Đánh số + gắn nguồn cho từng chunk, vd:
        [1] (attention_is_all_you_need.pdf, trang 3)
        <nội dung chunk>

    page=-1 là quy ước của vectordb.py cho "không có số trang" (file .md/.txt)
    -> ẩn phần "trang X" trong trường hợp này thay vì hiện "trang -1" vô nghĩa.
    """
    lines = []
    for i, chunk in enumerate(chunks, start=1):
        meta = chunk["metadata"]
        page = meta.get("page", -1)
        page_str = f", trang {page}" if page is not None and page != -1 else ""
        lines.append(f"[{i}] ({meta['source']}{page_str})\n{chunk['text']}")
    return "\n\n".join(lines)


def build_prompt(query: str, chunks: list[dict]) -> str:
    """Ghép SYSTEM_INSTRUCTION + ngữ cảnh (đã đánh số nguồn) + câu hỏi thành 1 prompt."""
    context = _format_context(chunks)
    return f"{SYSTEM_INSTRUCTION}\n\nNGỮ CẢNH:\n{context}\n\nCÂU HỎI: {query}\n\nTRẢ LỜI:"
