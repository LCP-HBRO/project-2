"""
ask.py — Điểm vào của PIPELINE HỎI-ĐÁP đầy đủ (đối xứng với ingest.py).

Luồng: câu hỏi -> retriever -> reranker -> prompt_builder -> llm -> câu trả lời

Chạy:  python ask.py "câu hỏi của bạn"

THIẾT KẾ:
    answer_question() trả về MỘT dict "structured log" (không chỉ câu trả lời)
    ghi lại latency TỪNG BƯỚC riêng biệt. Đây là lý do structured logging quan
    trọng hơn print thông thường: khi cả pipeline chậm, log này cho biết CHÍNH
    XÁC bước nào là thủ phạm (retrieval? reranker? LLM?) — thay vì chỉ biết
    "toàn bộ mất 3 giây" mà không rõ tại đâu. Ngày 4 đã cho thấy chính reranker
    từng là điểm nghẽn latency lớn nhất (23s trên CPU) — nếu không tách log
    riêng từng bước, sẽ rất khó phát hiện thủ phạm thật sự.

    LƯU LOG RA FILE (logs/queries.jsonl): trước đây structured log chỉ IN RA
    CONSOLE rồi mất — không thể phân tích lại sau (vd: "trung bình latency 100
    câu hỏi gần nhất là bao nhiêu?"). Dùng định dạng JSONL (mỗi dòng một JSON
    object độc lập) thay vì một mảng JSON lớn: GHI THÊM (append) một dòng mới
    không cần đọc/parse lại toàn bộ file cũ — quan trọng vì file log chỉ lớn
    dần theo thời gian chạy app.py. `log_path=None` tắt hẳn việc ghi file (dùng
    trong test để không làm bẩn log thật — xem tests/test_ask.py).
"""

import json
import time
from datetime import datetime, timezone
from pathlib import Path

from src.llm import generate_answer
from src.prompt_builder import build_prompt
from src.reranker import Reranker, get_reranker
from src.retriever import Retriever

DEFAULT_LOG_PATH = Path(__file__).resolve().parent / "logs" / "queries.jsonl"


def _persist_log(log: dict, path: Path) -> None:
    """Ghi thêm 1 dòng JSON vào cuối file log (định dạng JSONL)."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(log, ensure_ascii=False) + "\n")


def answer_question(
    query: str,
    retriever: Retriever | None = None,
    reranker: Reranker | None = None,
    mode: str | None = None,
    log_path: Path | None = DEFAULT_LOG_PATH,
) -> dict:
    """Chạy toàn bộ pipeline cho MỘT câu hỏi, trả về câu trả lời + structured log."""
    retriever = retriever if retriever is not None else Retriever()
    reranker = reranker if reranker is not None else get_reranker()

    t0 = time.time()
    hits = retriever.retrieve(query, mode=mode)
    t1 = time.time()

    reranked = reranker.rerank(query, hits)
    t2 = time.time()

    prompt = build_prompt(query, reranked)
    answer = generate_answer(prompt)
    t3 = time.time()

    log = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "query": query,
        "retrieval_latency_ms": round((t1 - t0) * 1000, 1),
        "reranker_latency_ms": round((t2 - t1) * 1000, 1),
        "llm_latency_ms": round((t3 - t2) * 1000, 1),
        "total_latency_ms": round((t3 - t0) * 1000, 1),
        "sources_cited": [
            f"{hit['metadata']['source']}:p{hit['metadata']['page']}" for hit in reranked
        ],
        "context_chunks": [hit["text"] for hit in reranked],
        "answer": answer,
    }

    if log_path is not None:
        _persist_log(log, log_path)

    return log


if __name__ == "__main__":
    import argparse

    from src.llm import LLMError

    parser = argparse.ArgumentParser(description="Hỏi câu hỏi trên pipeline RAG.")
    parser.add_argument("query", nargs="*", help="Câu hỏi")
    parser.add_argument("--mode", choices=["dense", "bm25", "hybrid"], default=None,
                        help="Chế độ tìm kiếm (mặc định lấy từ config)")
    args = parser.parse_args()

    query_str = " ".join(args.query) or "What is the attention mechanism in Transformers?"

    try:
        result = answer_question(query_str, mode=args.mode)
    except LLMError as e:
        print(f"⚠️  {e}")
        raise SystemExit(1)

    print(f"Câu hỏi: {result['query']}\n")
    print(f"Trả lời:\n{result['answer']}\n")

    print("--- Structured log ---")
    log_only = {k: v for k, v in result.items() if k != "answer"}
    print(json.dumps(log_only, ensure_ascii=False, indent=2))
