"""
compare_chunking.py — So sánh ĐỊNH TÍNH 3 chiến lược chunking trên dữ liệu thật.

Ingest CÙNG một bộ tài liệu bằng cả 3 chiến lược (fixed/recursive/semantic) vào
3 collection ChromaDB RIÊNG BIỆT (ai_knowledge_fixed, ai_knowledge_recursive,
ai_knowledge_semantic) — tách riêng để không lẫn lộn khi so sánh, và để dùng
lại đúng các collection này ở evaluation.py (Ngày 5) khi đo Hit Rate@k/MRR định
lượng. Ở đây (Ngày 3), ta chỉ "nhìn bằng mắt" xem 3 chiến lược trả về chunk
khác nhau thế nào cho cùng một câu hỏi.

Chạy TỪ THƯ MỤC GỐC rag-project:  python -m scripts.compare_chunking
       (BẮT BUỘC dùng -m: chạy trực tiếp `python scripts/compare_chunking.py`
       sẽ khiến Python chỉ thêm thư mục scripts/ vào sys.path, không thấy được
       ingest.py/src/ ở gốc dự án -> ModuleNotFoundError.)
       Sẽ mất vài phút: semantic chunking phải embed từng CÂU trước khi ingest,
       nhiều hơn hẳn so với embed từng CHUNK như 2 chiến lược kia.
"""

from ingest import run_ingest
from src.config import COLLECTION_NAME
from src.retriever import Retriever
from src.vectordb import VectorStore

STRATEGIES = ["fixed", "recursive", "semantic"]

SAMPLE_QUERIES = [
    "What is the attention mechanism in Transformers?",
    "How does BGE-M3 support multiple languages?",
    "What is Retrieval-Augmented Generation?",
]


def ingest_all_strategies() -> dict[str, VectorStore]:
    stores = {}
    for strategy in STRATEGIES:
        print(f"\n{'=' * 70}\n[{strategy}] Đang ingest...\n{'=' * 70}")
        store = VectorStore(collection_name=f"{COLLECTION_NAME}_{strategy}")
        run_ingest(strategy=strategy, store=store, reset=True)
        stores[strategy] = store
    return stores


def compare_retrieval(stores: dict[str, VectorStore]) -> None:
    retrievers = {s: Retriever(store=stores[s]) for s in STRATEGIES}

    for query in SAMPLE_QUERIES:
        print(f"\n{'#' * 70}\nCâu hỏi: {query}\n{'#' * 70}")
        for strategy in STRATEGIES:
            print(f"\n--- [{strategy}] top-3 ---")
            hits = retrievers[strategy].retrieve(query, top_k=3)
            for rank, hit in enumerate(hits, start=1):
                meta = hit["metadata"]
                preview = hit["text"][:120].replace("\n", " ")
                print(f"  [{rank}] sim={hit['similarity']:.3f}  {meta['source']} (trang {meta['page']})")
                print(f"      {preview}...")


if __name__ == "__main__":
    stores = ingest_all_strategies()
    compare_retrieval(stores)
