"""
Test độc lập cho vectordb.py.

Không cần model embedding thật — tự tạo vector số 4 chiều bằng tay để kiểm tra
logic add/query/reset. ChromaDB chạy hoàn toàn local (SQLite dưới nền), không
cần mạng, nên các test này chạy nhanh và không cần đánh dấu @pytest.mark.integration.
Mỗi test dùng `tmp_path` riêng của pytest để không ảnh hưởng dữ liệu thật trong
data/chroma/.
"""

import numpy as np
import pytest

from src.chunker import Chunk
from src.vectordb import VectorStore


def _chunk(text, source="doc.pdf", page=1, chunk_index=0, strategy="recursive"):
    return Chunk(text=text, source=source, page=page, chunk_index=chunk_index, strategy=strategy)


def test_add_and_query_returns_closest_first(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test")

    chunks = [
        _chunk("noi dung A", chunk_index=0),
        _chunk("noi dung B", chunk_index=1),
        _chunk("noi dung C", chunk_index=2),
    ]
    vectors = np.array(
        [
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [0.9, 0.1, 0.0, 0.0],  # gần vector truy vấn hơn B, nhưng không bằng A
        ],
        dtype=np.float32,
    )
    store.add(chunks, vectors)

    query_vector = np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32)
    hits = store.query(query_vector, top_k=2)

    assert len(hits) == 2
    assert hits[0]["text"] == "noi dung A"   # gần nhất (distance = 0)
    assert hits[1]["text"] == "noi dung C"   # gần thứ nhì
    assert hits[0]["distance"] < hits[1]["distance"]


def test_add_is_idempotent_via_upsert(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test")
    chunk = _chunk("noi dung lap lai")
    vector = np.array([[1.0, 0.0, 0.0, 0.0]], dtype=np.float32)

    store.add([chunk], vector)
    store.add([chunk], vector)  # nạp lại CHÍNH chunk này lần 2 (ID giống hệt)

    assert store.count() == 1  # không tạo bản ghi trùng


def test_reset_clears_all_data(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test")
    store.add([_chunk("mot chunk")], np.array([[1.0, 0.0, 0.0, 0.0]], dtype=np.float32))
    assert store.count() == 1

    store.reset()

    assert store.count() == 0


def test_add_raises_on_mismatched_lengths(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test")
    with pytest.raises(ValueError):
        store.add([_chunk("a"), _chunk("b")], np.array([[1.0, 0.0, 0.0, 0.0]], dtype=np.float32))


def test_metadata_preserves_source_and_page(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test")
    store.add(
        [_chunk("noi dung", source="paper.pdf", page=7, chunk_index=2)],
        np.array([[1.0, 0.0, 0.0, 0.0]], dtype=np.float32),
    )

    hits = store.query(np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32), top_k=1)

    assert hits[0]["metadata"]["source"] == "paper.pdf"
    assert hits[0]["metadata"]["page"] == 7


def test_metadata_none_page_stored_as_sentinel(tmp_path):
    # Document .md/.txt không có số trang -> page=None -> quy ước lưu thành -1
    store = VectorStore(path=tmp_path / "chroma", collection_name="test")
    store.add(
        [_chunk("noi dung", source="note.md", page=None)],
        np.array([[1.0, 0.0, 0.0, 0.0]], dtype=np.float32),
    )

    hits = store.query(np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32), top_k=1)

    assert hits[0]["metadata"]["page"] == -1
