# AI Knowledge Assistant — Hệ thống RAG tự triển khai từ đầu (No LangChain/LlamaIndex)

Chào mừng bạn đến với dự án **AI Knowledge Assistant**. Đây là hệ thống **Retrieval-Augmented Generation (RAG)** được xây dựng hoàn toàn thủ công bằng Python (không sử dụng các framework ăn liền như LangChain hay LlamaIndex) nhằm mục tiêu làm chủ và tối ưu hóa từng module của một hệ thống RAG thực tế trong môi trường giới hạn tài nguyên phần cứng.

> [!NOTE]
> Dự án đã được mở rộng đáng kể từ 17 tài liệu PDF gốc lên tới **10.018 tài liệu thực tế** (~10.000 tóm tắt nghiên cứu NLP dạng `.docx` tải từ Hugging Face) để thử nghiệm khả năng chịu tải và hiệu năng thực tế.

---

## 1. Kiến Trúc Hệ Thống (Architecture)

Hệ thống được thiết kế theo mô hình kiến trúc phân lớp rõ ràng:

### 1.1. Pipeline Nạp Dữ Liệu (Ingestion Pipeline)
```mermaid
graph LR
    A[data/documents/] -->|PDF / DOCX| B[loader.py]
    B -->|Documents| C[chunker.py]
    C -->|Semantic Chunks| D[embedding.py BGE-M3]
    D -->|Vectors & Metadata| E[(ChromaDB)]
```

*   **Document Loader ([loader.py](file:///c:/Users/AD/Downloads/parallel pro/rag-project/src/loader.py)):** Hỗ trợ đọc tài liệu PDF theo từng trang (sử dụng PyMuPDF block-based extraction để bảo toàn ranh giới đoạn văn) và tài liệu Word `.docx` (sử dụng `python-docx` ghép đoạn bằng `\n\n`).
*   **Chunker ([chunker.py](file:///c:/Users/AD/Downloads/parallel pro/rag-project/src/chunker.py)):** Hỗ trợ 3 chiến lược cắt nhỏ văn bản: Fixed-size, Recursive Character (tối ưu ranh giới đoạn), và Semantic (cắt dựa trên độ tương đồng ngữ nghĩa của câu).
*   **Embedding ([embedding.py](file:///c:/Users/AD/Downloads/parallel pro/rag-project/src/embedding.py)):** Sử dụng mô hình đa ngôn ngữ mã nguồn mở `BAAI/bge-m3` chạy trên GPU (CUDA) để sinh vector 1024 chiều.
*   **Vector Database ([vectordb.py](file:///c:/Users/AD/Downloads/parallel pro/rag-project/src/vectordb.py)):** Quản lý lưu trữ bền vững (persistent) trên ổ đĩa thông qua ChromaDB.

---

### 1.2. Pipeline Truy Vấn & Hỏi Đáp (Query Pipeline)
```mermaid
graph TD
    Query[Câu hỏi của người dùng] -->|Embedding| DenseQ[Query Vector]
    Query -->|Tokenize| LexQ[BM25 Query]
    DenseQ -->|Dense Retrieval| VectorDB[(ChromaDB)]
    LexQ -->|Lexical Retrieval| BM25[BM25Searcher]
    VectorDB -->|Top-k candidates| Fusion[Reciprocal Rank Fusion - RRF]
    BM25 -->|Top-k candidates| Fusion
    Fusion -->|Hybrid Search Results| Reranker[BGE-Reranker-v2-m3]
    Reranker -->|Top-n reranked chunks| Prompt[prompt_builder.py]
    Prompt -->|Context + Instructions| LLM[LLM Generator]
    LLM -->|Local Qwen-1.5B / Gemini API| Output[Câu trả lời + Trích dẫn nguồn]
```

*   **Hybrid Search ([retriever.py](file:///c:/Users/AD/Downloads/parallel pro/rag-project/src/retriever.py)):** Kết hợp kết quả tìm kiếm ngữ nghĩa (Dense Retrieval) và tìm kiếm từ khóa (Lexical Search BM25) thông qua thuật toán kết hợp xếp hạng **RRF (Reciprocal Rank Fusion)**.
*   **Cross-Encoder Reranking ([reranker.py](file:///c:/Users/AD/Downloads/parallel pro/rag-project/src/reranker.py)):** Sử dụng mô hình `BAAI/bge-reranker-v2-m3` để chấm điểm lại mức độ liên quan của các chunk ứng viên, khắc phục giới hạn của mô hình Bi-Encoder.
*   **Prompt Builder ([prompt_builder.py](file:///c:/Users/AD/Downloads/parallel pro/rag-project/src/prompt_builder.py)):** Dựng prompt ngữ cảnh tự động, định hình hành vi LLM và bắt buộc mô hình phải trích dẫn số thứ tự nguồn (ví dụ: `[1]`, `[2]`) tương ứng với tài liệu tham khảo.
*   **LLM Interface ([llm.py](file:///c:/Users/AD/Downloads/parallel pro/rag-project/src/llm.py)):** Hỗ trợ linh hoạt giữa mô hình chạy cục bộ (Qwen2.5-1.5B qua Ollama) và mô hình đám mây hiệu năng cao (Gemini API) để tối ưu độ chính xác và khả năng tuân thủ định dạng.

---

## 2. Thiết Lập Công Nghệ & Phần Cứng (Tech Stack)

Hệ thống được thực nghiệm và tối ưu hóa trên cấu hình thiết bị cá nhân giới hạn:
*   **CPU:** Intel Core i5-13420H
*   **GPU:** NVIDIA GeForce RTX 3050 Laptop GPU (6GB VRAM)

### Chi Tiết Cấu Hình Thư Viện

| Thành phần | Lựa chọn công nghệ | Vai trò & Lý do |
| :--- | :--- | :--- |
| **Embedding** | `BAAI/bge-m3` | Chạy GPU (CUDA), sinh vector 1024 chiều, hỗ trợ đa ngôn ngữ chất lượng cao. |
| **Reranker** | `BAAI/bge-reranker-v2-m3` | Chạy GPU (CUDA). Tối ưu hóa `RERANKER_BATCH_SIZE=4` để tránh lỗi nghẽn cổ chai *unlucky batch*. |
| **Vector DB** | `ChromaDB` (Persistent) | Lưu trữ cơ sở dữ liệu vector bền vững xuống ổ đĩa cục bộ. |
| **Lexical Search** | `rank-bm25` (BM25Searcher) | Công cụ tìm kiếm từ khóa in-memory xây dựng trên corpus ChromaDB để tìm chính xác thuật ngữ viết tắt. |
| **LLM** | `qwen2.5:1.5b` (Local) / `Gemini` (API) | Local dùng bản 1.5B để vừa khít VRAM 6GB khi chạy đồng thời với Embedding + Reranker trên GPU. API dùng Gemini để triệt tiêu ảo giác và nâng Refusal Rate lên cao. |
| **Loader** | `PyMuPDF` + `python-docx` | Trích xuất khối văn bản (blocks) từ PDF và bóc tách đoạn từ Word `.docx`. |
| **Web UI** | `Streamlit` | Giao diện hỏi đáp tương tác trực quan "Explainable Retrieval" (hiện rõ độ tương đồng và mức chấm điểm rerank). |

---

## 3. Cấu Trúc Mã Nguồn (Source Tree)

```text
rag-project/
├── data/
│   ├── documents/         # Tài liệu nguồn (17 file PDF học thuật + 10.001 file Word nlp_paper)
│   ├── chroma/            # Dữ liệu index cơ sở dữ liệu vector ChromaDB (tự sinh)
│   └── golden_qa.json     # Bộ câu hỏi vàng gồm 38 câu hỏi thực tế để đánh giá định lượng
├── src/
│   ├── config.py          # Tập trung toàn bộ tham số cấu hình của hệ thống RAG
│   ├── loader.py          # Loader đọc văn bản từ PDF (theo trang) và Word (DOCX)
│   ├── chunker.py         # 3 thuật toán cắt nhỏ văn bản (fixed, recursive, semantic)
│   ├── embedding.py       # Wrapper quản lý nạp và sinh vector bằng bge-m3 trên GPU
│   ├── vectordb.py        # Quản lý ChromaDB (khởi tạo, nạp dữ liệu, reset)
│   ├── bm25.py            # Công cụ tìm kiếm từ khóa BM25Searcher
│   ├── retriever.py       # Tích hợp luồng tìm kiếm lai Hybrid Search + RRF
│   ├── reranker.py        # Tái sắp xếp tài liệu sử dụng Cross-Encoder trên GPU
│   ├── prompt_builder.py  # Xây dựng prompt chứa ngữ cảnh và hướng dẫn trích dẫn
│   └── llm.py             # Điều phối gọi mô hình sinh Qwen (local) hoặc Gemini (cloud)
├── scripts/
│   ├── download_corpus.py # Tải 17 tài liệu PDF gốc từ arXiv
│   ├── compare_chunking.py# Script so sánh định tính 3 chiến lược chunking
│   └── sweep_params.py    # Quét tham số tìm giá trị TOP_K và CHUNK_SIZE tối ưu
├── scratch/
│   └── download_nlp_dataset.py # Tải 10.000 bài báo từ Hugging Face và tạo file Word
├── tests/                 # Thư mục chứa 94 bài test độc lập (unit & integration)
├── requirements.txt       # Danh sách các thư viện chính xác (phục vụ đóng băng phiên bản)
├── ingest.py              # CLI: Kích hoạt pipeline nạp tài liệu vào ChromaDB
├── ask.py                 # CLI: Hỏi đáp trực tiếp qua terminal kèm log chi tiết độ trễ
├── app.py                 # Web UI: Chạy ứng dụng Streamlit trực quan
└── README.md              # Tài liệu hướng dẫn chính (file này)
```

---

## 4. Hướng Dẫn Cài Đặt (Installation)

### Bước 1: Tạo và kích hoạt môi trường ảo
```powershell
python -m venv .venv
.venv\Scripts\activate
```

### Bước 2: Cài đặt PyTorch hỗ trợ CUDA (GPU) trước
```powershell
pip install torch --index-url https://download.pytorch.org/whl/cu121
```
*Kiểm tra khả năng sử dụng GPU:*
```powershell
python -c "import torch; print(torch.cuda.is_available())" # Phải trả về True
```

### Bước 3: Cài đặt các thư viện phụ thuộc
```powershell
pip install -r requirements.txt
```

### Bước 4: Cài đặt Ollama và tải mô hình Qwen local (Nếu dùng local LLM)
Tải Ollama tại [ollama.com](https://ollama.com) và chạy lệnh:
```powershell
ollama pull qwen2.5:1.5b
```

---

## 5. Hướng Dẫn Sử Dụng (Usage Guide)

### 5.1. Chuẩn bị dữ liệu tài liệu nền tảng
Để tải 17 PDF học thuật cơ bản:
```powershell
python scripts/download_corpus.py
```
Để tải thêm 10.000 tài liệu Word NLP từ Hugging Face phục vụ kiểm thử chịu tải:
```powershell
python scratch/download_nlp_dataset.py
```

### 5.2. Chạy Pipeline nạp dữ liệu (Ingestion)
Nạp toàn bộ tài liệu trong thư mục dữ liệu vào ChromaDB bằng chiến lược cắt ngữ nghĩa (semantic):
```powershell
python ingest.py --strategy semantic --reset
```

### 5.3. Hỏi đáp qua giao diện dòng lệnh (CLI)
Đặt câu hỏi trực tiếp để xem câu trả lời và bảng phân tích độ trễ của từng bước:
```powershell
python ask.py "What is the attention mechanism in Transformers?"
```

### 5.4. Chạy chương trình đánh giá định lượng (Evaluation)
Đo lường các chỉ số Hit Rate@k, MRR, ROUGE-L và Refusal Rate trên tập câu hỏi vàng `golden_qa.json`:
```powershell
python evaluation.py
```

### 5.5. Khởi chạy Giao diện Web Streamlit
Chạy giao diện tương tác trực quan "Explainable Retrieval":
```powershell
streamlit run app.py
```

---

## 6. Các Phát Hiện & Bài Học Tối Ưu Hóa Quan Trọng

1.  **Lỗi mất ranh giới đoạn văn (PyMuPDF):** Hàm đọc text thô mặc định của PyMuPDF làm mất ký tự `\n\n` khiến thuật toán *Recursive Character Chunker* bị vô hiệu hóa (hoạt động giống hệt *Fixed Chunker*). Tối ưu hóa bằng cách đọc text theo cấu trúc khối ("blocks") đã giúp khôi phục định dạng, nâng MRR chiến lược recursive từ **0.890 lên 0.963**.
2.  **Hiện tượng Outlier độ trễ Reranker ("Unlucky Batch"):** Khi tăng `top_k` lên 20, thời gian truy vấn trung bình thỉnh thoảng bị vọt lên tới **46.1 giây** (gấp 23 lần bình thường). Lý do: BGE-Reranker mặc định gom toàn bộ 20 chunk vào đúng 1 batch để xử lý và pad độ dài của cả batch theo chunk dài nhất. Chỉ cần 1 chunk rất dài (như chunk sinh bởi semantic), cả batch bị kéo chậm theo. Khắc phục bằng cách hạ `RERANKER_BATCH_SIZE = 4`, đưa thời gian trung bình của cả pipeline về mức ổn định **1.92 giây**.
3.  **Tác động của Reranker lên vùng phủ cấp trang:** Nhờ thiết lập bộ câu hỏi đánh giá có đối chứng số trang thật (`expected_page`), dự án phát hiện mặc dù Reranker giúp tăng thứ hạng trung bình (MRR) nhưng lại làm giảm nhẹ vùng phủ cấp trang (`hit_rate_page` giảm từ **1.000 xuống 0.909**) do lọc quá mức. Phát hiện này là tiền đề đề xuất giải thuật đa dạng hóa MMR (Maximal Marginal Relevance) ở hướng phát triển tương lai.
4.  **Hạn chế của mô hình local siêu nhỏ:** Mô hình Qwen 1.5B cục bộ đôi khi gặp khó khăn trong việc tuân thủ nghiêm ngặt định dạng trích dẫn nguồn `[1]`, `[2]`. Chuyển sang Gemini API giúp giải quyết triệt để vấn đề này và nâng tỷ lệ từ chối trả lời chính xác đối với câu hỏi ngoài phạm vi lên cao hơn.
