"""
bm25.py — Tìm kiếm từ khoá BM25 (lexical search) trên CPU.

LÝ THUYẾT:
    Dense Embedding (như BGE-M3) tìm kiếm bằng cách so sánh ý nghĩa ngữ nghĩa tổng
    thể của câu hỏi và đoạn văn. Cách này cực kỳ tốt cho câu hỏi dạng giải thích
    hoặc khái niệm. Tuy nhiên, Dense Search thường gặp khó khăn với:
      - Từ khoá viết tắt, thuật ngữ kỹ thuật viết tắt (ví dụ: "LoRA", "RLHF", "ROUGE-L").
      - Các mã số, phiên bản cụ thể (ví dụ: "qwen2.5:1.5b", "RTX 3050").
      - Tên riêng, tên hàm hoặc tên lớp cụ thể trong code.

    BM25 (Best Matching 25) là thuật toán tìm kiếm dựa trên tần suất xuất hiện của
    từ khoá (TF-IDF cải tiến). Nó tìm kiếm chính xác các từ trùng lặp giữa câu hỏi
    và đoạn văn, không quan tâm ngữ nghĩa.

    Sự kết hợp giữa BM25 (chính xác từ khoá) và Dense Search (hiểu ngữ nghĩa) qua
    thuật toán RRF tạo nên một hệ thống Hybrid Search mạnh mẽ, bổ khuyết hoàn hảo
    cho nhau.

THIẾT KẾ:
    - Để tránh việc lưu trữ phức tạp và đồng bộ thủ công giữa index BM25 và VectorDB,
      BM25Searcher sẽ tải toàn bộ văn bản của chiến lược hiện tại từ ChromaDB lên
      bộ nhớ (In-Memory) khi bắt đầu truy vấn.
    - Với số lượng tài liệu học thuật nhỏ (~2000 chunks), quá trình nạp toàn bộ và
      xây dựng BM25 Index trong bộ nhớ chỉ mất ~5-10 mili-giây, cực kỳ nhanh và
      giữ hệ thống đơn giản, không cần file database phụ.
"""

import re
from rank_bm25 import BM25Okapi
from src.vectordb import VectorStore


class BM25Searcher:
    """Xây dựng và tìm kiếm BM25 trên tập dữ liệu lấy từ ChromaDB."""

    def __init__(self, store: VectorStore):
        self.store = store
        self.bm25 = None
        self.chunks_data = []  # Lưu thông tin đầy đủ của các chunk để trả về

    def _tokenize(self, text: str) -> list[str]:
        """Tách từ đơn giản bằng regex (chuyển sang chữ thường, giữ lại ký tự chữ & số)."""
        return re.findall(r"\w+", text.lower())

    def fit(self) -> None:
        """
        Tải toàn bộ chunk từ ChromaDB collection hiện tại và khởi tạo mô hình BM25.
        """
        # Truy vấn toàn bộ document từ ChromaDB collection
        results = self.store.collection.get()

        ids = results.get("ids", [])
        documents = results.get("documents", [])
        metadatas = results.get("metadatas", [])

        self.chunks_data = []
        corpus_tokenized = []

        for i in range(len(ids)):
            chunk_dict = {
                "id": ids[i],
                "text": documents[i],
                "metadata": metadatas[i],
                "distance": 1.0,  # Điểm khoảng cách giả lập (BM25 không dùng khoảng cách)
            }
            self.chunks_data.append(chunk_dict)
            corpus_tokenized.append(self._tokenize(documents[i]))

        if corpus_tokenized:
            self.bm25 = BM25Okapi(corpus_tokenized)
        else:
            self.bm25 = None

    def query(self, query_str: str, top_k: int = 10) -> list[dict]:
        """
        Tìm kiếm câu hỏi bằng BM25, trả về định dạng danh sách hit tương tự ChromaDB.
        """
        if not self.bm25 or not self.chunks_data:
            return []

        query_tokens = self._tokenize(query_str)
        scores = self.bm25.get_scores(query_tokens)

        # Gán điểm số BM25 và sắp xếp
        indexed_scores = list(enumerate(scores))
        # Sắp xếp theo score giảm dần
        indexed_scores.sort(key=lambda x: x[1], reverse=True)

        hits = []
        for index, score in indexed_scores[:top_k]:
            hit = self.chunks_data[index].copy()
            # Ghi nhận điểm số BM25 để tiện debug/hiển thị UI
            hit["bm25_score"] = float(score)
            # Giả lập distance tỷ lệ nghịch với score để giao diện hiển thị đồng nhất
            # BM25 score càng cao thì distance giả lập càng nhỏ (càng gần)
            hit["distance"] = 1.0 / (1.0 + float(score))
            hits.append(hit)

        return hits
