"""Package src — chứa toàn bộ module lõi của hệ thống RAG."""
