import numpy as np
from src.chunker import Chunk
from src.vectordb import VectorStore
from src.bm25 import BM25Searcher


def _chunk(text, chunk_index):
    return Chunk(
        text=text,
        source="doc.pdf",
        page=1,
        chunk_index=chunk_index,
        strategy="recursive",
    )


def test_bm25_searcher_tokenize():
    searcher = BM25Searcher(None)
    tokens = searcher._tokenize("Hello World! This is a test, 123.")
    assert tokens == ["hello", "world", "this", "is", "a", "test", "123"]


def test_bm25_searcher_fit_and_query(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test_bm25")

    chunks = [
        _chunk("Attention mechanism in Transformer networks", 0),
        _chunk("Low-Rank Adaptation (LoRA) of large language models", 1),
        _chunk("Deep learning architectures and artificial intelligence", 2),
    ]
    vectors = np.random.rand(3, 4).astype(np.float32)

    store.add(chunks, vectors)

    searcher = BM25Searcher(store)
    searcher.fit()

    assert searcher.bm25 is not None
    assert len(searcher.chunks_data) == 3

    # Query matching chunk 0
    hits = searcher.query("Transformer", top_k=2)
    assert len(hits) == 2
    assert "Transformer" in hits[0]["text"]
    assert hits[0]["metadata"]["chunk_index"] == 0

    # Query matching chunk 1
    hits = searcher.query("LoRA", top_k=1)
    assert len(hits) == 1
    assert "LoRA" in hits[0]["text"]
    assert hits[0]["metadata"]["chunk_index"] == 1
