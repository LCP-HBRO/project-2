"""
vectordb.py — Vector Database (ChromaDB).

LÝ THUYẾT:
    Sau khi có vector cho mỗi chunk, ta cần một nơi LƯU và TÌM lại chúng hiệu
    quả. Nếu chỉ có vài trăm vector, so sánh "brute-force" (tính cosine với TẤT
    CẢ vector rồi sắp xếp) là đủ nhanh. Nhưng một Vector Database như ChromaDB
    xây sẵn chỉ mục HNSW (Hierarchical Navigable Small World) — cấu trúc đồ thị
    cho phép tìm gần-đúng (approximate nearest neighbor) trong thời gian gần như
    hằng số, thay vì phải quét qua mọi vector. Ngoài ra ChromaDB lưu vector +
    text gốc + metadata CÙNG NHAU và ghi xuống đĩa (persistent) — không cần tự
    quản lý việc đồng bộ giữa "kho vector" và "kho text" như khi tự dùng FAISS
    thô (FAISS chỉ lưu vector, không lưu text/metadata đi kèm).

THIẾT KẾ:
    - Mỗi chunk cần một ID DUY NHẤT khi lưu vào Chroma. Ta ghép
      "source|page|strategy|chunk_index" — đủ để phân biệt kể cả khi bạn ingest
      CẢ 2 chiến lược chunking (fixed và recursive) vào CÙNG một collection để
      so sánh (Ngày 3), vì lúc đó "chunk_index=0" của 2 chiến lược sẽ không đè
      lên nhau.
    - Dùng `upsert` thay vì `add`: `add` sẽ báo lỗi nếu ID đã tồn tại, trong khi
      `upsert` ghi đè êm nếu trùng ID và tạo mới nếu chưa có. Điều này khiến
      ingest.py có thể CHẠY LẠI NHIỀU LẦN một cách an toàn (idempotent) — hữu
      ích khi bạn đang phát triển và chạy ingest lặp đi lặp lại.
    - ChromaDB không cho phép giá trị `None` trong metadata -> `page=None` (file
      .md/.txt không có khái niệm trang) được lưu thành số hiệu -1, quy ước rõ
      trong docstring của `_make_metadata`.
"""

from pathlib import Path

import chromadb
import numpy as np

from src.chunker import Chunk
from src.config import CHROMA_DIR, COLLECTION_NAME, DISTANCE_METRIC, TOP_K


def _make_id(chunk: Chunk) -> str:
    """Sinh ID duy nhất cho một chunk, dùng làm khoá lưu trong ChromaDB."""
    page_part = chunk.page if chunk.page is not None else "-"
    return f"{chunk.source}|p{page_part}|{chunk.strategy}|{chunk.chunk_index}"


def _make_metadata(chunk: Chunk) -> dict:
    """
    Chuyển Chunk thành dict metadata mà ChromaDB chấp nhận (không hỗ trợ None).

    page = -1 là quy ước cho "không có số trang" (tài liệu .md/.txt).
    """
    return {
        "source": chunk.source,
        "page": chunk.page if chunk.page is not None else -1,
        "strategy": chunk.strategy,
        "chunk_index": chunk.chunk_index,
    }


class VectorStore:
    """Bọc một ChromaDB collection: thêm chunk kèm vector, và tìm top-k gần nhất."""

    def __init__(
        self,
        path: Path = CHROMA_DIR,
        collection_name: str = COLLECTION_NAME,
        distance: str = DISTANCE_METRIC,
    ):
        self._collection_name = collection_name
        self._distance = distance
        # PersistentClient ghi index xuống đĩa tại `path` -> dữ liệu còn nguyên
        # sau khi tắt chương trình, không cần embed lại mỗi lần chạy app.py.
        self.client = chromadb.PersistentClient(path=str(path))
        self.collection = self.client.get_or_create_collection(
            name=collection_name,
            metadata={"hnsw:space": distance},
        )

    def add(self, chunks: list[Chunk], vectors: np.ndarray) -> None:
        """Thêm (hoặc ghi đè nếu trùng ID) danh sách chunk kèm vector tương ứng."""
        if len(chunks) != len(vectors):
            raise ValueError(
                f"Số chunk ({len(chunks)}) và số vector ({len(vectors)}) phải bằng nhau"
            )
        if not chunks:
            return

        # ChromaDB giới hạn tối đa 5461 phần tử trong một lần upsert (do SQLite parameter limit)
        # Ta chia thành các batch nhỏ hơn (ví dụ 4000) để đảm bảo an toàn.
        batch_size = 4000
        for i in range(0, len(chunks), batch_size):
            batch_chunks = chunks[i : i + batch_size]
            batch_vectors = vectors[i : i + batch_size]
            
            self.collection.upsert(
                ids=[_make_id(c) for c in batch_chunks],
                embeddings=batch_vectors.tolist(),
                documents=[c.text for c in batch_chunks],
                metadatas=[_make_metadata(c) for c in batch_chunks],
            )

    def query(self, query_vector: np.ndarray, top_k: int = TOP_K) -> list[dict]:
        """Tìm top_k chunk có vector gần `query_vector` nhất, sắp xếp gần -> xa."""
        results = self.collection.query(
            query_embeddings=[query_vector.tolist()],
            n_results=top_k,
        )
        # Chroma trả kết quả dạng "list-of-list" (một list con cho mỗi vector truy
        # vấn gửi lên cùng lúc) — ở đây ta luôn gửi đúng 1 vector nên lấy [0].
        hits = []
        for i in range(len(results["ids"][0])):
            hits.append(
                {
                    "id": results["ids"][0][i],
                    "text": results["documents"][0][i],
                    "distance": results["distances"][0][i],
                    "metadata": results["metadatas"][0][i],
                }
            )
        return hits

    def count(self) -> int:
        """Số chunk hiện có trong collection."""
        return self.collection.count()

    def reset(self) -> None:
        """Xoá sạch collection và tạo lại rỗng — dùng khi muốn ingest lại từ đầu."""
        self.client.delete_collection(self._collection_name)
        self.collection = self.client.get_or_create_collection(
            name=self._collection_name,
            metadata={"hnsw:space": self._distance},
        )


if __name__ == "__main__":
    # Chạy `python -m src.vectordb` để kiểm tra nhanh: collection hiện có bao nhiêu chunk.
    store = VectorStore()
    print(f"Collection '{COLLECTION_NAME}' hiện có {store.count()} chunk.")
