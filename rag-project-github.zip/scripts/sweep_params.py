"""
scripts/sweep_params.py — Thí nghiệm quét CHUNK_SIZE và TOP_K.

Đây là 2 trục thí nghiệm đã nêu rõ trong spec gốc của dự án ("So sánh: Chunk
size, Top-K, Có/Không reranker") nhưng CHƯA từng thực hiện trong 7 ngày đầu —
bản đầu chỉ so sánh CHIẾN LƯỢC chunking (fixed/recursive/semantic) ở một
chunk_size cố định (512), và luôn dùng top_k=20 cố định. Script này lấp
khoảng trống đó.

Chạy TỪ THƯ MỤC GỐC:  python -m scripts.sweep_params
"""

from evaluation import evaluate_retriever, load_golden_qa
from ingest import run_ingest
from src.config import COLLECTION_NAME
from src.reranker import get_reranker
from src.retriever import Retriever
from src.vectordb import VectorStore


def sweep_top_k(golden_qa: list[dict]) -> None:
    """
    TOP_K sweep: KHÔNG cần ingest lại — dùng chung collection mặc định (semantic,
    đã ingest sẵn), chỉ đổi top_k lúc retrieve. Cố ý thử cả top_k RẤT NHỎ (1, 3)
    để tìm điểm mà Hit Rate@k bắt đầu tụt xuống dưới 1.00 — Ngày 5 đã phát hiện
    Hit Rate@20 = 1.00 tuyệt đối (ceiling effect), top_k nhỏ hơn có thể "phá vỡ
    trần" đó và cho tín hiệu phân biệt rõ hơn.
    """
    store = VectorStore(collection_name=COLLECTION_NAME)  # collection mặc định (semantic)
    retriever = Retriever(store=store)
    reranker = get_reranker()

    print("\n=== SWEEP TOP_K (chunking=semantic, collection mặc định) ===")
    header = f"{'top_k':<8} {'reranker':<10} {'hit_rate':<10} {'mrr':<8} {'latency_ms':<12}"
    print(header)
    print("-" * len(header))

    for top_k in (1, 3, 5, 10, 20):
        for label, rr in (("no", None), ("yes", reranker)):
            rerank_top_n = min(5, top_k)  # không thể lấy top_n > số ứng viên có sẵn
            result = evaluate_retriever(
                retriever, golden_qa, top_k=top_k, reranker=rr, rerank_top_n=rerank_top_n
            )
            print(
                f"{top_k:<8} {label:<10} {result['hit_rate']:<10.2f} "
                f"{result['mrr']:<8.3f} {result['avg_latency_ms']:<12.1f}"
            )


def sweep_chunk_size(golden_qa: list[dict]) -> None:
    """
    CHUNK_SIZE sweep: PHẢI ingest lại vì chunk_size ảnh hưởng ngay bước chunking.
    Dùng chiến lược "recursive" (KHÔNG "semantic") vì rẻ hơn nhiều để lặp lại 3
    lần — recursive không cần embed từng câu như semantic, nên re-ingest nhanh.
    """
    print("\n=== SWEEP CHUNK_SIZE (chunking=recursive, top_k=20) ===")
    header = f"{'chunk_size':<12} {'reranker':<10} {'hit_rate':<10} {'mrr':<8} {'n_chunks':<10}"
    print(header)
    print("-" * len(header))

    reranker = get_reranker()
    for chunk_size in (256, 512, 1024):
        store = VectorStore(collection_name=f"{COLLECTION_NAME}_cs{chunk_size}")
        run_ingest(strategy="recursive", chunk_size=chunk_size, store=store, reset=True)
        retriever = Retriever(store=store)

        for label, rr in (("no", None), ("yes", reranker)):
            result = evaluate_retriever(retriever, golden_qa, reranker=rr)
            print(
                f"{chunk_size:<12} {label:<10} {result['hit_rate']:<10.2f} "
                f"{result['mrr']:<8.3f} {store.count():<10}"
            )


if __name__ == "__main__":
    golden_qa = load_golden_qa()
    sweep_top_k(golden_qa)
    sweep_chunk_size(golden_qa)
