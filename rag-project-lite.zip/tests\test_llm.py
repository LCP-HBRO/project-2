"""
Test độc lập cho llm.py.

1) Unit test (mặc định, nhanh): thay _client bằng fake, không gọi Ollama server thật.
2) Integration test (@pytest.mark.integration, TẮT mặc định): gọi Ollama server
   THẬT với model qwen2.5:1.5b (đã có sẵn, không cần tải).
   Chạy riêng bằng: pytest tests/test_llm.py -m integration
"""

import ollama
import pytest

import src.llm as llm_module
from src.llm import LLMError, generate_answer


class _FakeOllamaClient:
    """Giả lập ollama.Client — không gọi mạng, ghi lại tham số để kiểm tra."""

    def __init__(self):
        self.chat_calls = []

    def chat(self, model, messages, options):
        self.chat_calls.append({"model": model, "messages": messages, "options": options})
        return {"message": {"content": "day la cau tra loi gia"}}


class _FakeOllamaClientDown:
    """Giả lập Ollama server KHÔNG chạy — luôn raise ConnectionError."""

    def chat(self, model, messages, options):
        raise ConnectionError("Failed to connect to Ollama.")


class _FakeOllamaClientModelMissing:
    """Giả lập gọi model CHƯA được `ollama pull` — luôn raise ollama.ResponseError."""

    def chat(self, model, messages, options):
        raise ollama.ResponseError(f"model '{model}' not found", 404)


def test_generate_answer_returns_message_content(monkeypatch):
    fake_client = _FakeOllamaClient()
    monkeypatch.setattr(llm_module, "_client", fake_client)

    result = generate_answer("mot prompt bat ky")

    assert result == "day la cau tra loi gia"


def test_generate_answer_sends_prompt_as_user_message(monkeypatch):
    fake_client = _FakeOllamaClient()
    monkeypatch.setattr(llm_module, "_client", fake_client)

    generate_answer("noi dung prompt cu the")

    call = fake_client.chat_calls[0]
    assert call["messages"] == [{"role": "user", "content": "noi dung prompt cu the"}]


def test_generate_answer_passes_temperature_and_max_tokens(monkeypatch):
    fake_client = _FakeOllamaClient()
    monkeypatch.setattr(llm_module, "_client", fake_client)

    generate_answer("prompt", temperature=0.5, max_tokens=100)

    options = fake_client.chat_calls[0]["options"]
    assert options["temperature"] == 0.5
    assert options["num_predict"] == 100


def test_generate_answer_uses_configured_default_model(monkeypatch):
    from src.config import LLM_MODEL

    fake_client = _FakeOllamaClient()
    monkeypatch.setattr(llm_module, "_client", fake_client)

    generate_answer("prompt")

    assert fake_client.chat_calls[0]["model"] == LLM_MODEL


def test_generate_answer_wraps_connection_error_with_helpful_message(monkeypatch):
    monkeypatch.setattr(llm_module, "_client", _FakeOllamaClientDown())

    with pytest.raises(LLMError, match="Ollama"):
        generate_answer("prompt")


def test_generate_answer_wraps_response_error_with_helpful_message(monkeypatch):
    monkeypatch.setattr(llm_module, "_client", _FakeOllamaClientModelMissing())

    with pytest.raises(LLMError, match="ollama pull"):
        generate_answer("prompt")


@pytest.mark.integration
def test_real_ollama_generates_non_empty_answer():
    """Chỉ chạy khi gọi rõ: pytest tests/test_llm.py -m integration
    (yêu cầu Ollama server đang chạy local, model qwen2.5:1.5b đã có sẵn)."""
    answer = generate_answer("Say the word 'test' and nothing else.", max_tokens=20)
    assert isinstance(answer, str)
    assert len(answer.strip()) > 0
