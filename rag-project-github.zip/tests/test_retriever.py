"""
Test độc lập cho retriever.py.

Dùng VectorStore THẬT (chạy local qua tmp_path, không cần mạng) nhưng Embedder
GIẢ (không tải model bge-m3) — vừa test đúng logic nối 2 module, vừa chạy nhanh.
"""

import numpy as np

from src.chunker import Chunk
from src.retriever import Retriever
from src.vectordb import VectorStore


class _FakeEmbedder:
    """Luôn trả về CÙNG MỘT vector cho mọi câu hỏi — đủ để kiểm soát kết quả retrieve."""

    def embed_query(self, query: str) -> np.ndarray:
        return np.array([1.0, 0.0, 0.0, 0.0], dtype=np.float32)


def _chunk(text, chunk_index):
    return Chunk(text=text, source="doc.pdf", page=1, chunk_index=chunk_index, strategy="recursive")


def test_retrieve_returns_closest_chunk_first_with_similarity(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test")
    store.add(
        [_chunk("gan nhat", 0), _chunk("xa nhat", 1)],
        np.array([[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0]], dtype=np.float32),
    )
    retriever = Retriever(store=store, embedder=_FakeEmbedder())

    hits = retriever.retrieve("cau hoi bat ky", top_k=2)

    assert hits[0]["text"] == "gan nhat"
    assert hits[0]["similarity"] > hits[1]["similarity"]
    assert np.isclose(hits[0]["similarity"], 1.0, atol=1e-6)


def test_retrieve_respects_top_k(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test")
    store.add(
        [_chunk(f"chunk {i}", i) for i in range(5)],
        np.array([[1.0, 0.0, 0.0, 0.0]] * 5, dtype=np.float32),
    )
    retriever = Retriever(store=store, embedder=_FakeEmbedder())

    hits = retriever.retrieve("cau hoi", top_k=3)

    assert len(hits) == 3


def test_retrieve_uses_default_store_and_embedder_when_not_injected(monkeypatch, tmp_path):
    # Kiểm tra Retriever() không tham số vẫn hoạt động: tự tạo VectorStore/Embedder
    # mặc định — ở đây thay get_embedder bằng fake để không tải model thật.
    import src.retriever as retriever_module

    monkeypatch.setattr(retriever_module, "get_embedder", lambda: _FakeEmbedder())
    monkeypatch.setattr(retriever_module, "VectorStore", lambda: VectorStore(path=tmp_path / "chroma", collection_name="default_test"))

    retriever = Retriever()
    assert retriever.store.count() == 0


def test_retrieve_bm25_mode(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test_bm25_retriever")
    store.add(
        [_chunk("Attention mechanisms", 0), _chunk("BERT model", 1), _chunk("dummy document", 2)],
        np.array([[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0]], dtype=np.float32),
    )
    retriever = Retriever(store=store, embedder=_FakeEmbedder())

    hits = retriever.retrieve("BERT", mode="bm25", top_k=1)
    assert len(hits) == 1
    assert hits[0]["text"] == "BERT model"


def test_retrieve_hybrid_mode(tmp_path):
    store = VectorStore(path=tmp_path / "chroma", collection_name="test_hybrid_retriever")
    # Chunk 0: Rất gần vector câu hỏi [1,0,0,0] nhưng không chứa từ "Transformers"
    # Chunk 1: Chứa từ "Transformers" nhưng vector xa ([0,1,0,0])
    store.add(
        [
            _chunk("Very semantic chunk about self-attention", 0),
            _chunk("Transformers are all you need", 1),
            _chunk("dummy document", 2),
        ],
        np.array([[1.0, 0.0, 0.0, 0.0], [0.0, 1.0, 0.0, 0.0], [0.0, 0.0, 1.0, 0.0]], dtype=np.float32),
    )

    retriever = Retriever(store=store, embedder=_FakeEmbedder())

    # Kiểm tra Dense
    dense_hits = retriever.retrieve("Transformers", mode="dense", top_k=2)
    assert dense_hits[0]["text"] == "Very semantic chunk about self-attention"

    # Kiểm tra BM25
    bm25_hits = retriever.retrieve("Transformers", mode="bm25", top_k=2)
    assert bm25_hits[0]["text"] == "Transformers are all you need"

    # Kiểm tra Hybrid
    hybrid_hits = retriever.retrieve("Transformers", mode="hybrid", top_k=2)
    assert len(hybrid_hits) == 2
    assert "rrf_score" in hybrid_hits[0]
