# 📋 RAG Project — Handoff Summary (Bàn giao cho Claude)

## 1. Tổng quan dự án

**Tên:** Local RAG Assistant for ML/NLP Research Papers  
**Mục tiêu:** Xây dựng hệ thống hỏi-đáp tự động trên 217 bài báo ML/NLP (635 trang PDF), chạy hoàn toàn local trên laptop có GPU RTX 3050 (6GB VRAM).

**Thư mục dự án:** `c:\Users\AD\Downloads\parallel pro\rag-project`

---

## 2. Kiến trúc hệ thống

```
PDF → Loader → Chunker → Embedder → ChromaDB (Vector Store)
                                          ↓
User Question → Embedder → Retriever (Dense/BM25/Hybrid) → Reranker → Prompt Builder → LLM (Qwen) → Answer
```

### Công nghệ sử dụng

| Thành phần | Công nghệ | File |
|---|---|---|
| PDF Loader | PyMuPDF (fitz) | `src/loader.py` |
| Chunking | 3 chiến lược: Fixed, Recursive, Semantic | `src/chunker.py` |
| Embedding | BAAI/bge-m3 (đa ngôn ngữ, 1024-dim) | `src/embedding.py` |
| Vector DB | ChromaDB (local, cosine distance) | `src/vectordb.py` |
| BM25 | rank_bm25 | `src/bm25.py` |
| Retrieval | Dense / BM25 / Hybrid (RRF fusion) | `src/retriever.py` |
| Reranker | BAAI/bge-reranker-v2-m3 (Cross-Encoder) | `src/reranker.py` |
| LLM | Qwen2.5:1.5b qua Ollama | `src/llm.py` |
| Prompt | Vietnamese system instruction | `src/prompt_builder.py` |
| Config | Tập trung tại 1 file | `src/config.py` |
| UI | Streamlit | `app.py` |
| Pipeline | `ask.py` (Qwen local), `ask_gemini.py` (Gemini API) |

### Cấu hình chính (`src/config.py`)

- `CHUNK_SIZE = 512`, `CHUNK_OVERLAP = 64`
- `SEMANTIC_BREAKPOINT_PERCENTILE = 95.0`
- `EMBEDDING_MODEL = "BAAI/bge-m3"`, device = `cuda`
- `RERANKER_MODEL = "BAAI/bge-reranker-v2-m3"`, device = `cuda`
- `TOP_K = 20` (retrieval), `RERANK_TOP_N = 5` (final)
- `LLM_MODEL = "qwen2.5:1.5b"`, `LLM_NUM_GPU = 0` (chạy CPU để tránh quá nhiệt)
- `RETRIEVAL_MODE = "hybrid"`, `RRF_K = 60`

---

## 3. Dữ liệu đã có

### 3.1 Corpus
- **217 file PDF**, tổng **635 trang**, nằm trong `data/documents/`
- Chủ đề: Transformer, BERT, GPT-3, InstructGPT, Mistral, LoRA, RAG, LangChain, v.v.

### 3.2 Vector Database (ChromaDB)
Đã ingest xong cả 3 chiến lược chunking:

| Collection | Số chunks |
|---|---|
| `ai_knowledge_fixed` | 3,421 |
| `ai_knowledge_recursive` | 3,570 |
| `ai_knowledge_semantic` | 6,324 |

### 3.3 Golden QA (`data/golden_qa.json`)
- **38 câu hỏi** đánh giá (30 answerable + 8 unanswerable)
- Mỗi câu có: question, expected_source, expected_answer, expected_page
- Câu unanswerable có `expected_source: null`

---

## 4. ĐÃ HOÀN THÀNH — Kết quả Retrieval Evaluation

### File kết quả: `reports/evaluation_results.json` và `reports/evaluation_results.md`

**18 tổ hợp** = 3 chunking strategies × 3 search modes × 2 reranker settings

| Strategy | Mode | Reranker | Hit Rate | MRR | Latency (ms) |
|---|---|---|---|---|---|
| fixed | dense | no | 1.00 | 0.980 | 37.1 |
| fixed | dense | yes | 1.00 | 0.970 | 3,270.8 |
| fixed | bm25 | no | 1.00 | 0.907 | 50.0 |
| fixed | bm25 | yes | 1.00 | 0.985 | 3,730.7 |
| fixed | hybrid | no | 1.00 | 0.965 | 44.9 |
| fixed | hybrid | yes | 1.00 | 0.985 | 3,797.3 |
| recursive | dense | no | 1.00 | 0.980 | 41.9 |
| recursive | dense | yes | 1.00 | 0.962 | 32,914.4 |
| recursive | bm25 | no | 1.00 | 0.890 | 70.1 |
| recursive | bm25 | yes | 1.00 | 0.985 | 24,198.3 |
| recursive | hybrid | no | 1.00 | 0.949 | 56.8 |
| recursive | hybrid | yes | 1.00 | 0.985 | 3,542.7 |
| semantic | dense | no | 1.00 | 0.980 | 36.3 |
| semantic | dense | yes | 1.00 | 0.970 | 2,563.8 |
| semantic | bm25 | no | 1.00 | 0.894 | 64.2 |
| semantic | bm25 | yes | 1.00 | 0.970 | 2,675.5 |
| semantic | hybrid | no | 1.00 | 0.962 | 67.9 |
| semantic | hybrid | yes | 1.00 | 0.970 | 2,618.7 |

### Phân tích chính từ Retrieval:
1. **Hit Rate = 100%** cho tất cả 18 tổ hợp — hệ thống luôn tìm được tài liệu đúng
2. **MRR cao nhất = 0.985** ở các tổ hợp BM25+Reranker và Hybrid+Reranker
3. **Reranker cải thiện BM25 rõ rệt:** BM25 MRR từ ~0.89-0.91 lên 0.97-0.985
4. **Dense search nhanh nhất** (~37ms) nhưng Hybrid+Reranker cho MRR tốt nhất
5. **Semantic chunking** tạo nhiều chunk nhất (6,324) nhưng MRR không vượt trội hơn

---

## 5. ĐÃ HOÀN THÀNH — Single Question End-to-End Test

Chạy thành công 1 câu qua full pipeline trên GPU (Embedder+Reranker trên CUDA, LLM trên CPU):

```
Retrieval: 1,259ms | Rerank: 2,592ms | LLM: 38,338ms | Total: 42,189ms
```

> **Ghi chú:** LLM chậm (38s) vì chạy Qwen trên CPU (`num_gpu=0`) để tránh laptop quá nhiệt. Nếu chạy trên GPU sẽ nhanh hơn nhiều nhưng gây sập nguồn.

---

## 6. CHƯA HOÀN THÀNH — Generation Evaluation

### Cần chạy lệnh:

```bash
cd "c:\Users\AD\Downloads\parallel pro\rag-project"
python -u -m scripts.evaluate_generation
```

### Script này sẽ đo 4 chỉ số:

1. **ROUGE-L (F1):** So khớp câu trả lời sinh ra với expected_answer (30 câu answerable)
2. **Faithfulness Score:** Tỉ lệ từ trong answer có xuất hiện trong context chunks (phát hiện hallucination)
3. **Refusal Rate:** Tỉ lệ từ chối đúng cách cho 8 câu unanswerable
4. **Latency Breakdown:** Retrieval / Reranker / LLM / Total (ms)

### Script có tính năng checkpoint:
- Lưu tiến độ vào `reports/generation_evaluation_temp.json` sau mỗi câu
- Nếu bị crash, chạy lại sẽ tự động resume từ câu cuối
- Kết quả cuối cùng lưu vào `reports/generation_evaluation_results.json`

### Lưu ý khi chạy:
- Đảm bảo **Ollama đang chạy** (`ollama serve` hoặc mở app Ollama)
- Model Qwen chạy trên CPU nên mỗi câu mất ~30-40 giây
- Tổng 38 câu ≈ 20-25 phút
- GPU temp sẽ không quá cao vì LLM đã chuyển sang CPU

---

## 7. CÁC FILE QUAN TRỌNG CẦN ĐỌC

| File | Mô tả |
|---|---|
| `src/config.py` | Toàn bộ cấu hình hệ thống |
| `src/chunker.py` | 3 chiến lược chunking (Fixed, Recursive, Semantic) |
| `src/embedding.py` | Embedder class, có GPU thermal throttling |
| `src/retriever.py` | Dense, BM25, Hybrid retrieval |
| `src/reranker.py` | Cross-encoder reranker |
| `src/llm.py` | Giao tiếp Ollama, cấu hình num_gpu |
| `src/prompt_builder.py` | Vietnamese system prompt |
| `ask.py` | Full RAG pipeline |
| `evaluation.py` | Metrics: Hit Rate, MRR, ROUGE-L, Faithfulness, Refusal |
| `scripts/evaluate_generation.py` | Script đánh giá end-to-end generation |
| `ingest.py` | Script nạp PDF vào ChromaDB |
| `app.py` | Streamlit UI |
| `reports/evaluation_results.json` | **KẾT QUẢ RETRIEVAL** (đã xong) |
| `reports/evaluation_results.md` | Báo cáo retrieval dạng markdown |
| `data/golden_qa.json` | 38 câu hỏi đánh giá |

---

## 8. GỢI Ý CẤU TRÚC BÁO CÁO

### Chương 1: Giới thiệu
- Bối cảnh: Nhu cầu hỏi-đáp trên tài liệu nghiên cứu ML/NLP
- Mục tiêu: Xây dựng RAG pipeline chạy hoàn toàn local
- Phạm vi: 217 PDF, 635 trang

### Chương 2: Cơ sở lý thuyết
- RAG (Retrieval-Augmented Generation)
- Text Chunking (Fixed, Recursive, Semantic)
- Vector Embedding (bge-m3, dense retrieval)
- BM25 (sparse retrieval)
- Hybrid Retrieval (RRF - Reciprocal Rank Fusion)
- Cross-Encoder Reranking
- LLM Generation

### Chương 3: Thiết kế & Triển khai hệ thống
- Kiến trúc tổng quan (pipeline diagram)
- Mô tả từng module (loader → chunker → embedder → vectordb → retriever → reranker → llm → prompt)
- Công nghệ sử dụng (bảng ở mục 2 trên)
- Giao diện Streamlit

### Chương 4: Đánh giá thực nghiệm
#### 4.1 Phương pháp đánh giá
- Golden QA set: 38 câu (30 answerable + 8 unanswerable)
- Metrics: Hit Rate, MRR, ROUGE-L, Faithfulness, Refusal Rate
- Ma trận thí nghiệm: 3 chunking × 3 search modes × 2 reranker = 18 tổ hợp

#### 4.2 Kết quả Retrieval (BẢNG 18 TỔ HỢP Ở MỤC 4)
- Hit Rate = 100% tất cả
- MRR best = 0.985 (BM25/Hybrid + Reranker)
- Phân tích: Reranker cải thiện BM25 đáng kể, Dense nhanh nhất

#### 4.3 Kết quả Generation (CẦN CHẠY SCRIPT → điền số liệu)
- ROUGE-L, Faithfulness, Refusal Rate, Latency

#### 4.4 Thảo luận
- Trade-off giữa tốc độ vs chất lượng
- Ảnh hưởng của chunking strategy
- Reranker: khi nào nên dùng
- Giới hạn phần cứng (GPU 6GB, thermal throttling)

### Chương 5: Kết luận & Hướng phát triển

---

## 9. VẤN ĐỀ KỸ THUẬT ĐÃ GẶP & GIẢI QUYẾT

1. **GPU quá nhiệt → laptop reset:** Giảm batch size 16→4, thêm thermal throttling ở 77°C, chuyển LLM sang CPU (`num_gpu=0`)
2. **Windows stdout crash:** `sys.stdout.reconfigure` lỗi khi chạy qua pipe → wrap try/except
3. **VRAM 6GB không đủ:** Embedder (bge-m3) + Reranker (bge-reranker-v2-m3) + LLM (Qwen) cùng lúc trên GPU → giảm Qwen từ 3B xuống 1.5B, rồi chuyển hẳn LLM sang CPU
4. **BM25 index mỗi lần phải rebuild:** Chấp nhận vì corpus nhỏ (~3-6k chunks), rebuild mất <1 giây

---

## 10. CHECKLIST — Việc còn lại

- [ ] **Chạy Generation Evaluation:** `python -u -m scripts.evaluate_generation` (20-25 phút)
- [ ] **Đọc kết quả:** File `reports/generation_evaluation_results.json`
- [ ] **Viết báo cáo:** Dựa trên cấu trúc ở mục 8, điền kết quả retrieval (mục 4) và generation
- [ ] **Vẽ biểu đồ:** So sánh MRR giữa các tổ hợp, latency breakdown pie chart
- [ ] **Dọn file test:** Xóa `test_eval.py`, `test_imports.py`, `test_ask_import.py`, `debug_single_qa.py`
