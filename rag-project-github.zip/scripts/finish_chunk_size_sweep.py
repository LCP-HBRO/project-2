"""
scripts/finish_chunk_size_sweep.py — Hoàn thiện phần CHUNK_SIZE sweep còn thiếu
(512+reranker, 1024 cả 2) sau khi đã fix "unlucky batch" (RERANKER_BATCH_SIZE=4).

chunk_size=256 và 512 (không reranker) đã có số liệu từ lần chạy trước — script
này CHỈ chạy phần còn thiếu, tái sử dụng collection ai_knowledge_cs512 đã ingest
sẵn (không ingest lại) để tiết kiệm thời gian.

Chạy TỪ THƯ MỤC GỐC: python -u -m scripts.finish_chunk_size_sweep
"""

from evaluation import evaluate_retriever, load_golden_qa
from ingest import run_ingest
from src.config import COLLECTION_NAME
from src.reranker import get_reranker
from src.retriever import Retriever
from src.vectordb import VectorStore

if __name__ == "__main__":
    golden_qa = load_golden_qa()
    reranker = get_reranker()

    header = f"{'chunk_size':<12} {'reranker':<10} {'hit_rate':<10} {'mrr':<8} {'n_chunks':<10}"
    print(header)
    print("-" * len(header))

    # --- chunk_size=512, reranker=yes (dùng lại collection đã ingest) ---
    store_512 = VectorStore(collection_name=f"{COLLECTION_NAME}_cs512")
    retriever_512 = Retriever(store=store_512)
    result = evaluate_retriever(retriever_512, golden_qa, reranker=reranker)
    print(f"{'512':<12} {'yes':<10} {result['hit_rate']:<10.2f} {result['mrr']:<8.3f} {store_512.count():<10}")

    # --- chunk_size=1024: ingest mới + cả 2 trường hợp reranker ---
    store_1024 = VectorStore(collection_name=f"{COLLECTION_NAME}_cs1024")
    run_ingest(strategy="recursive", chunk_size=1024, store=store_1024, reset=True)
    retriever_1024 = Retriever(store=store_1024)

    for label, rr in (("no", None), ("yes", reranker)):
        result = evaluate_retriever(retriever_1024, golden_qa, reranker=rr)
        print(
            f"{'1024':<12} {label:<10} {result['hit_rate']:<10.2f} "
            f"{result['mrr']:<8.3f} {store_1024.count():<10}"
        )
