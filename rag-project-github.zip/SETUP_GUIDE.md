# 🚀 HƯỚNG DẪN SETUP & TIẾP TỤC DỰ ÁN RAG TRÊN MÁY MỚI

> **Cách lấy dự án:**
> - **Source code:** Clone từ GitHub repo
> - **Data nặng (PDF + ChromaDB):** Tải từ Kaggle Dataset, giải nén vào thư mục `data/`

---

## Bước 1: Clone repo từ GitHub

```powershell
git clone <URL_GITHUB_REPO>
cd rag-project
```

---

## Bước 2: Tải data từ Kaggle

1. Vào link Kaggle Dataset (do chủ dự án cung cấp)
2. Tải file ZIP về, giải nén
3. Copy 2 thư mục vào đúng vị trí:

```
rag-project/
├── data/
│   ├── documents/     ← 217 file PDF (từ Kaggle)
│   ├── chroma/        ← ChromaDB vector index (từ Kaggle)
│   └── golden_qa.json ← đã có sẵn trong Git
```

> **Nếu không có ChromaDB từ Kaggle**, bạn có thể tự ingest lại:
> ```powershell
> python ingest.py
> ```
> Mất ~15-30 phút tuỳ GPU.

---

## Bước 3: Cài Python (nếu chưa có)

- Cần **Python 3.10+** (khuyên 3.11 hoặc 3.12)
- Tải từ https://www.python.org/downloads/
- Tick **"Add Python to PATH"** khi cài

---

## Bước 4: Tạo Virtual Environment

```powershell
cd rag-project
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

> Nếu lỗi Execution Policy:
> ```powershell
> Set-ExecutionPolicy -Scope CurrentUser RemoteSigned
> ```

---

## Bước 5: Cài PyTorch với CUDA (QUAN TRỌNG)

**Phải cài PyTorch bản CUDA TRƯỚC, rồi mới cài requirements.txt.**

### Nếu máy có GPU NVIDIA:
```powershell
# Kiểm tra phiên bản CUDA:
nvidia-smi
# Xem dòng "CUDA Version: XX.X"

# Cài torch cho CUDA 12.1 (phổ biến nhất):
pip install torch --index-url https://download.pytorch.org/whl/cu121

# Hoặc CUDA 12.4:
pip install torch --index-url https://download.pytorch.org/whl/cu124

# Kiểm tra:
python -c "import torch; print(torch.cuda.is_available())"
# Phải in: True
```

### Nếu máy KHÔNG có GPU NVIDIA:
```powershell
pip install torch
```
Sau đó sửa file `src/config.py`:
- `EMBEDDING_DEVICE = "cpu"` (dòng ~78)
- `RERANKER_DEVICE = "cpu"` (dòng ~126)

---

## Bước 6: Cài thư viện

```powershell
pip install -r requirements.txt
```

---

## Bước 7: Cài Ollama + Model Qwen

1. Tải Ollama: https://ollama.ai/download
2. Cài đặt và mở Ollama
3. Tải model:
```powershell
ollama pull qwen2.5:1.5b
```
4. Kiểm tra:
```powershell
ollama list
# Phải thấy qwen2.5:1.5b
```

---

## Bước 8: Cấu hình GPU cho LLM (tuỳ máy)

Mở file `src/config.py`, tìm dòng `LLM_NUM_GPU`:

```python
LLM_NUM_GPU = 0   # Hiện tại = 0 (chạy CPU) vì máy cũ bị quá nhiệt
```

| GPU máy mới | Chỉnh thành |
|---|---|
| Không có GPU | `LLM_NUM_GPU = 0` |
| GPU yếu (< 6GB VRAM) | `LLM_NUM_GPU = 0` |
| GPU trung bình (6-8GB) | `LLM_NUM_GPU = 99` (thử, nếu crash thì đổi lại 0) |
| GPU mạnh (> 8GB) | `LLM_NUM_GPU = 99` |

---

## Bước 9: Kiểm tra hệ thống hoạt động

### Test nhanh 1 câu hỏi qua pipeline:
```powershell
python -u debug_single_qa.py
```

Kết quả mong đợi:
```
[1/5] Importing modules... OK
[2/5] Loading Embedder... OK
[3/5] Loading Retriever... OK
[4/5] Loading Reranker... OK
[5/5] Running single question... SUCCESS
Answer: The attention mechanism in Transformers...
Retrieval: XXms | Rerank: XXms | LLM: XXms | Total: XXms
```

---

## Bước 10: Chạy Generation Evaluation (VIỆC CHÍNH CÒN LẠI)

```powershell
python -u run_gen_eval.py
```

### Script này sẽ:
- Chạy 38 câu hỏi từ `data/golden_qa.json` qua full RAG pipeline
- Đo 4 chỉ số: **ROUGE-L, Faithfulness, Refusal Rate, Latency**
- Lưu checkpoint sau mỗi câu vào `reports/generation_evaluation_temp.json`
- **Nếu bị crash → chạy lại lệnh trên, tự resume từ câu cuối**
- Kết quả cuối cùng: `reports/generation_evaluation_results.json`

### Thời gian ước tính:
- GPU (LLM_NUM_GPU=99): ~5-10 phút
- CPU (LLM_NUM_GPU=0): ~20-25 phút

---

## Bước 11: Đọc kết quả

Sau khi chạy xong, mở `reports/generation_evaluation_results.json`:
```json
{
  "avg_rouge_l": 0.XXXX,
  "avg_faithfulness_score": 0.XXXX,
  "refusal_rate": 0.XXXX,
  "avg_retrieval_latency_ms": XX.X,
  "avg_reranker_latency_ms": XX.X,
  "avg_llm_latency_ms": XX.X,
  "avg_total_latency_ms": XX.X,
  "details": [...]
}
```

---

## Kết quả Retrieval đã có (18 tổ hợp)

File: `reports/evaluation_results.json`

| Chỉ số | Kết quả |
|---|---|
| Hit Rate | **100%** (tất cả 18 tổ hợp) |
| MRR cao nhất | **0.985** (BM25+Reranker, Hybrid+Reranker) |
| Latency nhanh nhất | **37ms** (Dense, không reranker) |

---

## Cấu trúc thư mục

```
rag-project/
├── src/                    # Source code chính
│   ├── config.py           # ⭐ CẤU HÌNH TOÀN BỘ HỆ THỐNG
│   ├── loader.py           # Đọc PDF
│   ├── chunker.py          # 3 chiến lược chunking
│   ├── embedding.py        # Embedder (bge-m3)
│   ├── vectordb.py         # ChromaDB wrapper
│   ├── bm25.py             # BM25 sparse search
│   ├── retriever.py        # Dense/BM25/Hybrid retrieval
│   ├── reranker.py         # Cross-encoder reranker
│   ├── llm.py              # Giao tiếp Ollama (Qwen)
│   └── prompt_builder.py   # Prompt template tiếng Việt
├── data/
│   ├── documents/          # 217 PDF (từ Kaggle)
│   ├── chroma/             # ChromaDB index (từ Kaggle)
│   └── golden_qa.json      # 38 câu hỏi đánh giá
├── reports/
│   ├── evaluation_results.json   # ✅ Kết quả retrieval (đã xong)
│   ├── handoff_summary.md        # ⭐ Tóm tắt cho AI viết báo cáo
│   └── generation_evaluation_results.json  # (tạo sau bước 10)
├── ask.py                  # Full RAG pipeline
├── evaluation.py           # Metrics
├── ingest.py               # Nạp PDF vào ChromaDB
├── app.py                  # Streamlit UI
├── run_gen_eval.py         # ⭐ CHẠY ĐỂ ĐÁNH GIÁ GENERATION
└── requirements.txt
```

---

## Khắc phục lỗi thường gặp

| Lỗi | Giải pháp |
|---|---|
| `torch.cuda.is_available() = False` | Cài lại PyTorch bản CUDA (Bước 5) |
| Không kết nối được Ollama | Mở app Ollama hoặc `ollama serve` |
| Model qwen2.5:1.5b not found | `ollama pull qwen2.5:1.5b` |
| GPU quá nhiệt / máy reset | `LLM_NUM_GPU = 0` trong `src/config.py` |
| UnicodeEncodeError | `$env:PYTHONIOENCODING="utf-8"` |
| ChromaDB collection not found | `python ingest.py` (~15-30 phút) |
