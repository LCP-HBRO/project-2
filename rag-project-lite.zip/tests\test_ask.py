"""
Test độc lập (smoke test) cho ask.py — chỉ kiểm tra pipeline NỐI ĐÚNG THỨ TỰ
(retriever -> reranker -> prompt_builder -> llm) và structured log có đủ
trường cần thiết, KHÔNG kiểm tra lại logic chi tiết từng module (đã có test
riêng ở test_retriever/test_reranker/test_prompt_builder/test_llm.py).
"""

import json

import pytest

import ask as ask_module
from ask import answer_question
from src.llm import LLMError


class _FakeRetriever:
    def retrieve(self, query, top_k=20, mode=None):
        return [{"text": "noi dung goc", "metadata": {"source": "doc.pdf", "page": 3}, "similarity": 0.9}]


class _FakeReranker:
    def rerank(self, query, hits, top_n=5):
        return hits  # giữ nguyên, chỉ để kiểm tra pipeline gọi đúng thứ tự


def test_answer_question_returns_expected_structured_log(monkeypatch):
    monkeypatch.setattr(ask_module, "generate_answer", lambda prompt: "cau tra loi gia")

    result = answer_question(
        "cau hoi test", retriever=_FakeRetriever(), reranker=_FakeReranker(), log_path=None
    )

    assert result["query"] == "cau hoi test"
    assert result["answer"] == "cau tra loi gia"
    assert result["sources_cited"] == ["doc.pdf:p3"]
    for key in ("retrieval_latency_ms", "reranker_latency_ms", "llm_latency_ms", "total_latency_ms", "timestamp"):
        assert key in result


def test_answer_question_total_latency_at_least_sum_of_stages(monkeypatch):
    monkeypatch.setattr(ask_module, "generate_answer", lambda prompt: "cau tra loi gia")

    result = answer_question(
        "cau hoi test", retriever=_FakeRetriever(), reranker=_FakeReranker(), log_path=None
    )

    stage_sum = result["retrieval_latency_ms"] + result["reranker_latency_ms"] + result["llm_latency_ms"]
    assert result["total_latency_ms"] >= stage_sum


def test_answer_question_appends_jsonl_log_to_file(monkeypatch, tmp_path):
    monkeypatch.setattr(ask_module, "generate_answer", lambda prompt: "cau tra loi gia")
    log_path = tmp_path / "queries.jsonl"

    answer_question("cau hoi 1", retriever=_FakeRetriever(), reranker=_FakeReranker(), log_path=log_path)
    answer_question("cau hoi 2", retriever=_FakeRetriever(), reranker=_FakeReranker(), log_path=log_path)

    lines = log_path.read_text(encoding="utf-8").strip().split("\n")
    assert len(lines) == 2  # 2 lần gọi -> 2 dòng, KHÔNG ghi đè (append, không overwrite)

    first_entry = json.loads(lines[0])
    assert first_entry["query"] == "cau hoi 1"
    second_entry = json.loads(lines[1])
    assert second_entry["query"] == "cau hoi 2"


def test_answer_question_log_path_none_skips_file_write(monkeypatch, tmp_path):
    monkeypatch.setattr(ask_module, "generate_answer", lambda prompt: "cau tra loi gia")

    answer_question("cau hoi test", retriever=_FakeRetriever(), reranker=_FakeReranker(), log_path=None)

    # Khong co file nao duoc tao trong tmp_path (thu muc rong)
    assert list(tmp_path.iterdir()) == []


def test_answer_question_propagates_llm_error(monkeypatch):
    def _raise(prompt):
        raise LLMError("Ollama khong ket noi duoc.")

    monkeypatch.setattr(ask_module, "generate_answer", _raise)

    with pytest.raises(LLMError):
        answer_question("cau hoi test", retriever=_FakeRetriever(), reranker=_FakeReranker(), log_path=None)
