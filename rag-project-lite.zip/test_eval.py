import sys
sys.path.insert(0, '.')

try:
    print("Starting test evaluation...")
    from scripts.evaluate_generation import evaluate_end_to_end
    from evaluation import load_golden_qa
    import scripts.evaluate_generation as eg
    
    # Override golden_qa with just the first 2 questions to test
    original_load = eg.load_golden_qa
    eg.load_golden_qa = lambda: original_load()[:2]
    
    evaluate_end_to_end()
    print("Test evaluation finished successfully!")
except BaseException as e:
    import traceback
    traceback.print_exc()
