"""
app.py — Giao diện Streamlit (điểm vào của PIPELINE HỎI-ĐÁP).

Luồng: câu hỏi -> retriever -> reranker -> prompt_builder -> llm -> hiển thị
câu trả lời kèm nguồn trích dẫn.

Chạy:  streamlit run app.py

THIẾT KẾ — "Explainable Retrieval":
    Mục tiêu dự án là HIỂU sâu Retrieval, không chỉ có một chatbot chạy được.
    Vì vậy UI này KHÔNG CHỈ hiện câu trả lời cuối cùng — nó phơi bày MỌI bước
    trung gian (top-k vector search kèm similarity, kết quả sau rerank kèm
    rerank_score, prompt thật gửi cho Qwen) trong các expander có thể mở ra.
    Một chatbot production sẽ giấu hết những thứ này; ở đây ta cố tình để lộ
    để mỗi lần hỏi cũng là một lần "xem bên trong" pipeline hoạt động.

    st.cache_resource giữ Retriever/Reranker sống xuyên suốt các lần Streamlit
    chạy lại script (mỗi tương tác của người dùng khiến toàn bộ file này chạy
    lại từ đầu) — nếu không cache, mỗi lần bấm nút sẽ tạo lại kết nối ChromaDB
    và có nguy cơ nạp lại model, rất lãng phí.
"""

import time

import streamlit as st

from ask_gemini import GEMINI_MODEL, GeminiLLMError, generate_answer_gemini
from src.config import RERANK_TOP_N
from src.llm import LLMError, generate_answer
from src.prompt_builder import build_prompt
from src.reranker import get_reranker
from src.retriever import Retriever

st.set_page_config(page_title="AI Knowledge Assistant", page_icon="🔎", layout="wide")


@st.cache_resource(show_spinner="Đang nạp model (bge-m3 + bge-reranker-v2-m3)...")
def load_pipeline():
    return Retriever(), get_reranker()


retriever, reranker = load_pipeline()

st.title("🔎 AI Knowledge Assistant")
st.caption(
    "RAG tự xây từ đầu — bge-m3 + ChromaDB + bge-reranker-v2-m3 + Qwen/Gemini. "
    "Hỏi về LLM, RAG, Embeddings, Transformers, Vector Databases, Fine-tuning, AI Agents..."
)

with st.sidebar:
    st.header("Tuỳ chọn")
    retrieval_mode = st.radio(
        "Chế độ tìm kiếm (Retrieval Mode):",
        options=["dense", "bm25", "hybrid"],
        index=2,
        format_func=lambda x: {
            "dense": "🧠 Dense Search (BGE-M3)",
            "bm25": "📝 Lexical Search (BM25)",
            "hybrid": "🔀 Hybrid Search (Dense + BM25 + RRF)"
        }[x]
    )
    use_reranker = st.checkbox("Dùng reranker", value=True)
    show_prompt = st.checkbox("Hiện prompt gửi cho LLM", value=False)

    st.divider()
    llm_backend = st.radio(
        "Mô hình sinh câu trả lời (LLM):",
        options=["qwen", "gemini"],
        index=0,
        format_func=lambda x: {
            "qwen": "🖥️ Qwen (local, qua Ollama)",
            "gemini": f"☁️ Gemini API ({GEMINI_MODEL})",
        }[x],
    )
    if llm_backend == "gemini":
        st.caption(
            "Cần biến môi trường `GEMINI_API_KEY` đã set TRƯỚC khi chạy "
            "`streamlit run app.py` (xem ask_gemini.py). Không dán key vào đây."
        )

query = st.text_input(
    "Câu hỏi của bạn:", placeholder="What is the attention mechanism in Transformers?"
)
ask_clicked = st.button("Hỏi", type="primary")

if ask_clicked and query.strip():
    t0 = time.time()
    if retrieval_mode == "hybrid":
        with st.spinner("Đang tìm kiếm bằng cả Dense và BM25..."):
            dense_hits = retriever.retrieve(query, mode="dense")
            bm25_hits = retriever.retrieve(query, mode="bm25")
            hits = retriever.retrieve(query, mode="hybrid")
        t1 = time.time()

        with st.expander(f"🔎 Quy trình Hybrid Search & RRF — {(t1 - t0) * 1000:.0f}ms", expanded=False):
            col1, col2 = st.columns(2)
            with col1:
                st.markdown("##### 🧠 1. Dense Search Hits")
                for i, h in enumerate(dense_hits[:5], start=1):
                    st.markdown(f"**[{i}] {h['metadata']['source']}** (trang {h['metadata']['page']}) — sim=`{h['similarity']:.3f}`")
                    st.caption(h["text"][:150] + "...")
            with col2:
                st.markdown("##### 📝 2. BM25 Search Hits")
                for i, h in enumerate(bm25_hits[:5], start=1):
                    st.markdown(f"**[{i}] {h['metadata']['source']}** (trang {h['metadata']['page']}) — score=`{h['bm25_score']:.1f}`")
                    st.caption(h["text"][:150] + "...")
            
            st.markdown("---")
            st.markdown("##### 🔀 3. Kết quả xếp hạng RRF sau cùng (Top-5)")
            for i, h in enumerate(hits[:5], start=1):
                st.markdown(f"**[{i}] {h['metadata']['source']}** (trang {h['metadata']['page']}) — rrf_score=`{h['rrf_score']:.4f}`")
                st.caption(h["text"][:150] + "...")
    else:
        with st.spinner(f"Đang tìm kiếm ({retrieval_mode.upper()})..."):
            hits = retriever.retrieve(query, mode=retrieval_mode)
        t1 = time.time()

        with st.expander(f"🔎 Top-{len(hits)} kết quả từ {retrieval_mode.upper()} Search — {(t1 - t0) * 1000:.0f}ms", expanded=False):
            for i, hit in enumerate(hits, start=1):
                meta = hit["metadata"]
                score_str = f"similarity=`{hit['similarity']:.3f}`" if retrieval_mode == "dense" else f"bm25_score=`{hit['bm25_score']:.1f}`"
                st.markdown(f"**[{i}] {meta['source']}** (trang {meta['page']}) — {score_str}")
                st.caption(hit["text"][:300] + "...")

    if use_reranker:
        with st.spinner("Đang chấm lại điểm (cross-encoder reranker)..."):
            reranked = reranker.rerank(query, hits, top_n=RERANK_TOP_N)
        t2 = time.time()
        with st.expander(f"📊 Top-{len(reranked)} sau Reranker — {(t2 - t1) * 1000:.0f}ms", expanded=True):
            for i, hit in enumerate(reranked, start=1):
                meta = hit["metadata"]
                st.markdown(
                    f"**[{i}] {meta['source']}** (trang {meta['page']}) — "
                    f"rerank_score=`{hit['rerank_score']:.3f}`, similarity=`{hit['similarity']:.3f}`"
                )
                st.caption(hit["text"][:300] + "...")
    else:
        reranked = hits[:RERANK_TOP_N]
        t2 = time.time()

    prompt = build_prompt(query, reranked)
    if show_prompt:
        with st.expander("📝 Prompt đầy đủ gửi cho LLM", expanded=True):
            st.text(prompt)

    # Bọc lỗi LLM riêng (không bọc cả retrieval/rerank ở trên): nếu Ollama server
    # tắt / model chưa được `ollama pull` / thiếu GEMINI_API_KEY, người dùng cuối
    # sẽ thấy thông báo rõ ràng kèm cách khắc phục thay vì traceback thô.
    try:
        if llm_backend == "gemini":
            with st.spinner(f"Gemini ({GEMINI_MODEL}) đang sinh câu trả lời..."):
                answer = generate_answer_gemini(prompt)
        else:
            with st.spinner("Qwen đang sinh câu trả lời..."):
                answer = generate_answer(prompt)
    except (LLMError, GeminiLLMError) as e:
        st.error(f"⚠️ {e}")
        st.stop()
    t3 = time.time()

    st.subheader("Câu trả lời")
    st.write(answer)

    st.markdown("**Nguồn đã dùng:**")
    for i, hit in enumerate(reranked, start=1):
        meta = hit["metadata"]
        st.caption(f"[{i}] {meta['source']} (trang {meta['page']})")

    reranker_ms = f", rerank {(t2 - t1) * 1000:.0f}ms" if use_reranker else ""
    st.caption(
        f"⏱️ retrieval {(t1 - t0) * 1000:.0f}ms{reranker_ms}, "
        f"LLM {(t3 - t2) * 1000:.0f}ms — tổng {(t3 - t0) * 1000:.0f}ms"
    )
elif ask_clicked:
    st.warning("Vui lòng nhập câu hỏi.")
