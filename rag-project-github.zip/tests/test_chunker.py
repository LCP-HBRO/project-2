"""
Test độc lập cho chunker.py — module quan trọng nhất của Retrieval.

Các test này không cần model hay file thật; chỉ dùng chuỗi Python thuần và
Document giả lập, để chạy nhanh và tách biệt khỏi các module nặng (embedding...).
"""

import numpy as np
import pytest

from src.chunker import (
    Chunk,
    chunk_documents,
    chunk_fixed,
    chunk_recursive,
    chunk_semantic,
    clean_text,
    count_words,
)
from src.loader import Document


class _FakeSentenceEmbedder:
    """
    Embedder giả cho test chunk_semantic: câu chứa 'TOPICA' -> vector [1,0,0,0],
    câu chứa 'TOPICB' -> vector [0,1,0,0]. Nhờ vậy điểm gãy ngữ nghĩa (chỗ đổi
    từ TOPICA sang TOPICB) là HOÀN TOÀN xác định, không phụ thuộc model thật.
    """

    def embed_texts(self, texts, batch_size=None):
        vectors = [
            [1.0, 0.0, 0.0, 0.0] if "TOPICA" in t else [0.0, 1.0, 0.0, 0.0] for t in texts
        ]
        return np.array(vectors, dtype=np.float32)


def test_clean_text_removes_null_bytes_and_extra_whitespace():
    dirty = "Dong 1\x00\n\n\n\nDong  2   voi   khoang  trang  thua  \n"
    cleaned = clean_text(dirty)

    assert "\x00" not in cleaned
    assert "\n\n\n" not in cleaned          # tối đa 1 dòng trống liên tiếp
    assert "Dong  2" not in cleaned          # khoảng trắng kép đã bị gộp


def test_chunk_fixed_basic_overlap():
    text = " ".join(f"w{i}" for i in range(10))  # "w0 w1 ... w9"

    chunks = chunk_fixed(text, chunk_size=4, overlap=1)

    assert chunks[0] == "w0 w1 w2 w3"
    assert chunks[1] == "w3 w4 w5 w6"      # "w3" lặp lại do overlap=1
    assert chunks[-1].endswith("w9")


def test_chunk_fixed_rejects_overlap_not_smaller_than_chunk_size():
    with pytest.raises(ValueError):
        chunk_fixed("a b c d e f", chunk_size=4, overlap=4)


def test_chunk_recursive_respects_paragraph_boundaries():
    para_a = " ".join(f"a{i}" for i in range(20))
    para_b = " ".join(f"b{i}" for i in range(20))
    text = f"{para_a}\n\n{para_b}"

    # chunk_size nhỏ hơn tổng 2 đoạn (40 từ) nhưng đủ chứa 1 đoạn (20 từ)
    # -> kỳ vọng mỗi đoạn văn nằm gọn trong 1 chunk riêng, không bị trộn lẫn.
    chunks = chunk_recursive(text, chunk_size=20, overlap=0)

    assert len(chunks) == 2
    assert "a0" in chunks[0] and "b0" not in chunks[0]
    assert "b0" in chunks[1] and "a0" not in chunks[1]


def test_chunk_recursive_falls_back_to_words_when_paragraph_too_long():
    # Một "đoạn văn" dài 50 từ, không có \n hay dấu chấm nào để tách theo cấu trúc
    # -> phải hạ xuống tới mức tách theo TỪ (separator cuối cùng) để không vượt chunk_size.
    long_para = " ".join(f"tu{i}" for i in range(50))

    chunks = chunk_recursive(long_para, chunk_size=20, overlap=0)

    assert all(count_words(c) <= 20 for c in chunks)
    assert sum(count_words(c) for c in chunks) == 50  # không mất từ nào


def test_chunk_semantic_splits_at_topic_boundary():
    text = (
        "TOPICA sentence one. TOPICA sentence two. TOPICA sentence three. "
        "TOPICB sentence one. TOPICB sentence two. TOPICB sentence three."
    )

    chunks = chunk_semantic(text, embedder=_FakeSentenceEmbedder(), chunk_size=100, overlap=0)

    assert len(chunks) == 2
    assert "TOPICA" in chunks[0] and "TOPICB" not in chunks[0]
    assert "TOPICB" in chunks[1] and "TOPICA" not in chunks[1]


def test_chunk_semantic_does_not_merge_across_boundary():
    # Dù mỗi mảnh rất nhỏ so với chunk_size, chunk_semantic KHÔNG được gộp 2
    # chủ đề lại làm 1 — đây là khác biệt cố ý so với chunk_recursive.
    text = "TOPICA mot. TOPICB hai."

    chunks = chunk_semantic(text, embedder=_FakeSentenceEmbedder(), chunk_size=1000, overlap=0)

    assert len(chunks) == 2


def test_chunk_semantic_single_sentence_returns_as_is():
    chunks = chunk_semantic("Chi mot cau duy nhat.", embedder=_FakeSentenceEmbedder())
    assert chunks == ["Chi mot cau duy nhat."]


def test_chunk_documents_semantic_requires_embedder():
    with pytest.raises(ValueError):
        chunk_documents([Document(text="abc", source="a.txt", page=None)], strategy="semantic")


def test_chunk_documents_semantic_uses_injected_embedder():
    documents = [
        Document(
            text="TOPICA cau mot. TOPICA cau hai. TOPICB cau mot. TOPICB cau hai.",
            source="doc.txt",
            page=None,
        )
    ]

    chunks = chunk_documents(
        documents, strategy="semantic", chunk_size=100, embedder=_FakeSentenceEmbedder()
    )

    assert all(c.strategy == "semantic" for c in chunks)
    assert len(chunks) == 2


def test_chunk_documents_preserves_metadata():
    documents = [
        Document(text="Noi dung tai lieu mot.", source="doc1.pdf", page=3),
        Document(text="Noi dung tai lieu hai.", source="doc2.md", page=None),
    ]

    chunks = chunk_documents(documents, strategy="recursive")

    assert all(isinstance(c, Chunk) for c in chunks)
    sources_pages = {(c.source, c.page) for c in chunks}
    assert ("doc1.pdf", 3) in sources_pages
    assert ("doc2.md", None) in sources_pages
    assert all(c.strategy == "recursive" for c in chunks)


def test_chunk_documents_rejects_unknown_strategy():
    with pytest.raises(ValueError):
        chunk_documents([], strategy="khong-ton-tai")
