"""
ask_gemini.py — Thử nghiệm THAY THẾ Qwen (local, qua Ollama) bằng Gemini API.
Sử dụng thư viện google-genai mới nhất.
"""

import json
import os
import sys
import time
from datetime import datetime, timezone
from google import genai  # Thư viện mới nhất

from src.prompt_builder import build_prompt
from src.reranker import Reranker, get_reranker
from src.retriever import Retriever

# Sử dụng model mới nhất từ danh sách của bạn
GEMINI_MODEL = os.environ.get("GEMINI_MODEL", "gemini-3.1-flash-lite")

class GeminiLLMError(Exception):
    """Lỗi khi gọi Gemini API."""

def _get_api_key() -> str:
    api_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not api_key:
        raise GeminiLLMError(
            "Chưa thiết lập GEMINI_API_KEY. Lấy tại https://aistudio.google.com/apikey, sau đó:\n"
            '  PowerShell:  $env:GEMINI_API_KEY = "your-key-here"'
        )
    return api_key

def generate_answer_gemini(prompt: str, model: str = GEMINI_MODEL) -> str:
    """Gửi prompt tới Gemini API bằng SDK google-genai mới."""
    client = genai.Client(api_key=_get_api_key())
    try:
        # Cấu trúc gọi hàm chuẩn của thư viện google-genai
        response = client.models.generate_content(
            model=model, 
            contents=prompt
        )
        return response.text
    except Exception as e:
        raise GeminiLLMError(f"Gemini API báo lỗi (Model: {model}): {e}") from e

def answer_question_gemini(
    query: str,
    retriever: Retriever | None = None,
    reranker: Reranker | None = None,
) -> dict:
    """Chạy pipeline RAG và lấy câu trả lời từ Gemini."""
    _get_api_key() 

    retriever = retriever if retriever is not None else Retriever()
    reranker = reranker if reranker is not None else get_reranker()

    t0 = time.time()
    hits = retriever.retrieve(query)
    t1 = time.time()

    reranked = reranker.rerank(query, hits)
    t2 = time.time()

    prompt = build_prompt(query, reranked)
    answer = generate_answer_gemini(prompt)
    t3 = time.time()

    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "query": query,
        "llm_backend": f"gemini:{GEMINI_MODEL}",
        "retrieval_latency_ms": round((t1 - t0) * 1000, 1),
        "reranker_latency_ms": round((t2 - t1) * 1000, 1),
        "llm_latency_ms": round((t3 - t2) * 1000, 1),
        "total_latency_ms": round((t3 - t0) * 1000, 1),
        "sources_cited": [
            f"{hit['metadata']['source']}:p{hit['metadata']['page']}" for hit in reranked
        ],
        "answer": answer,
    }

if __name__ == "__main__":
    query = " ".join(sys.argv[1:]) or "Demonstrate the structure of Bert"

    try:
        result = answer_question_gemini(query)
    except GeminiLLMError as e:
        print(f"⚠️  {e}")
        sys.exit(1)

    print(f"Câu hỏi: {result['query']}\n")
    print(f"Trả lời (Gemini — {result['llm_backend']}):\n{result['answer']}\n")

    print("--- Structured log ---")
    log_only = {k: v for k, v in result.items() if k != "answer"}
    print(json.dumps(log_only, ensure_ascii=False, indent=2))