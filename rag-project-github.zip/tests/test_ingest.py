"""
Test độc lập (dạng smoke test) cho ingest.py — chỉ kiểm tra các module được NỐI
ĐÚNG THỨ TỰ (loader -> chunker -> embedding -> vectordb), không kiểm tra lại
logic chi tiết của từng module (đã có test riêng ở test_loader/test_chunker/
test_vectordb.py).

Để tránh tải model bge-m3 thật (nặng, cần mạng), get_embedder() được thay bằng
một fake xác định qua monkeypatch — cùng chiến lược đã dùng ở test_embedding.py.
"""

import numpy as np
import docx

import ingest as ingest_module
from src.vectordb import VectorStore


def _make_docx(path, text: str):
    doc_obj = docx.Document()
    doc_obj.add_paragraph(text)
    doc_obj.save(path)


class _FakeEmbedder:
    """Sinh vector giả 4 chiều dựa trên độ dài chuỗi — đủ để kiểm tra pipeline
    nối đúng, không cần độ chính xác ngữ nghĩa thật. Cùng interface embed_texts()
    nên dùng được cho CẢ bước chunking semantic LẪN bước embed chunk cuối cùng."""

    def embed_texts(self, texts, batch_size=None):
        return np.array([[float(len(t)), 0.0, 0.0, 0.0] for t in texts], dtype=np.float32)


def test_run_ingest_reads_chunks_embeds_and_stores(tmp_path, monkeypatch):
    _make_docx(
        tmp_path / "note.docx",
        "Day la mot tai lieu Word docx ngan gon de kiem tra pipeline ingest."
    )
    monkeypatch.setattr(ingest_module, "get_embedder", lambda: _FakeEmbedder())
    store = VectorStore(path=tmp_path / "chroma", collection_name="test_ingest")

    n = ingest_module.run_ingest(documents_dir=tmp_path, store=store)

    assert n > 0
    assert store.count() == n


def test_run_ingest_returns_zero_when_no_documents(tmp_path, monkeypatch):
    monkeypatch.setattr(ingest_module, "get_embedder", lambda: _FakeEmbedder())
    store = VectorStore(path=tmp_path / "chroma", collection_name="test_empty")

    n = ingest_module.run_ingest(documents_dir=tmp_path, store=store)

    assert n == 0
    assert store.count() == 0


def test_run_ingest_reset_clears_previous_data(tmp_path, monkeypatch):
    monkeypatch.setattr(ingest_module, "get_embedder", lambda: _FakeEmbedder())
    _make_docx(tmp_path / "a.docx", "noi dung file a can duoc xoa sau khi reset")
    store = VectorStore(path=tmp_path / "chroma", collection_name="test_reset")

    ingest_module.run_ingest(documents_dir=tmp_path, store=store)
    assert store.count() > 0

    # Xoá file cũ, thêm file mới, chạy lại với reset=True -> dữ liệu cũ phải mất hẳn
    (tmp_path / "a.docx").unlink()
    _make_docx(tmp_path / "b.docx", "noi dung file b hoan toan moi")
    n_second = ingest_module.run_ingest(documents_dir=tmp_path, store=store, reset=True)

    # Sau reset, số chunk trong store phải đúng BẰNG số chunk của lần ingest thứ
    # hai (chỉ file b) — không còn cộng dồn với lần đầu (file a).
    assert store.count() == n_second


def test_run_ingest_supports_semantic_strategy(tmp_path, monkeypatch):
    # strategy="semantic" cần embedder ngay trong bước chunking (không chỉ bước
    # embed chunk cuối) — smoke test này xác nhận ingest.py truyền embedder
    # đúng chỗ, không quên tham số nào.
    monkeypatch.setattr(ingest_module, "get_embedder", lambda: _FakeEmbedder())
    _make_docx(
        tmp_path / "note.docx",
        "Cau mot noi ve chu de A. Cau hai van ve chu de A. Cau ba doi sang chu de B hoan toan khac."
    )
    store = VectorStore(path=tmp_path / "chroma", collection_name="test_semantic")

    n = ingest_module.run_ingest(documents_dir=tmp_path, strategy="semantic", store=store)

    assert n > 0
    assert store.count() == n
