"""
embedding.py — Embedding (BAAI/bge-m3).

LÝ THUYẾT:
    Embedding là bước biến văn bản (chuỗi ký tự) thành một VECTOR SỐ (bge-m3 cho
    ra vector 1024 chiều) sao cho 2 đoạn văn có Ý NGHĨA gần nhau thì vector của
    chúng cũng gần nhau trong không gian đó (đo bằng cosine similarity). Đây là
    nền tảng để "tìm theo ngữ nghĩa" thay vì tìm theo từ khoá — ví dụ "xe hơi" và
    "ô tô" có vector gần nhau dù không chung từ nào, điều mà BM25/TF-IDF không làm được.

VÌ SAO CHỌN bge-m3:
    - Đa ngôn ngữ (100+ ngôn ngữ, gồm tiếng Việt) — phù hợp vì bạn có thể hỏi
      bằng tiếng Việt trong khi tài liệu nguồn (paper) là tiếng Anh.
    - Hỗ trợ chuỗi dài tới 8192 token (nhiều embedding model cũ chỉ giới hạn 512).
    - Một trong các embedding mở mạnh nhất hiện nay theo benchmark MTEB.
    - bge-m3 thực ra hỗ trợ 3 kiểu biểu diễn (dense + sparse + ColBERT multi-vector)
      qua thư viện FlagEmbedding chuyên dụng — nhưng để giữ dự án ĐƠN GIẢN, ta chỉ
      dùng phần DENSE EMBEDDING (một vector duy nhất/đoạn) qua sentence-transformers,
      là phần cốt lõi và đủ cho một hệ RAG cơ bản. (Hybrid dense+sparse là hướng mở
      rộng thú vị nếu còn thời gian.)

MỘT SẮC THÁI QUAN TRỌNG — KHÔNG CẦN INSTRUCTION PREFIX CHO QUERY:
    Một số embedding họ BGE đời trước (vd bge-large-en-v1.5) yêu cầu thêm một câu
    hướng dẫn cố định vào ĐẦU câu truy vấn, ví dụ:
        "Represent this sentence for searching relevant passages: " + query
    để phân biệt "đây là câu hỏi" với "đây là đoạn văn cần tìm" (2 loại câu này có
    phân bố ngôn ngữ khác nhau: query thường ngắn & là câu hỏi, passage thường dài
    & là câu khẳng định). bge-m3 được huấn luyện để KHÔNG CẦN prefix này nữa — cả
    câu hỏi lẫn đoạn văn dùng chung một hàm encode. Đây là lý do embed_query() và
    embed_texts() dưới đây dùng chung logic, không thêm prefix nào.

THIẾT KẾ:
    - Embedder: bọc SentenceTransformer, tách biệt "encode NHIỀU đoạn văn khi
      ingest" (embed_texts, có batch_size để không tràn VRAM) và "encode MỘT câu
      hỏi khi query" (embed_query).
    - get_embedder(): cache model đã nạp (lru_cache) — nạp model từ đĩa lên GPU
      mất vài giây; không nên lặp lại mỗi lần gọi hàm (retriever.py sẽ gọi hàm
      này mỗi câu hỏi của người dùng).
    - _resolve_device(): nếu config yêu cầu "cuda" nhưng máy không có GPU khả
      dụng, tự động lùi về CPU kèm cảnh báo, thay vì crash giữa chừng.
"""

from functools import lru_cache
import subprocess
import time

import numpy as np
import torch
from sentence_transformers import SentenceTransformer

from src.config import (
    EMBEDDING_DEVICE,
    EMBEDDING_MAX_TOKENS,
    EMBEDDING_MODEL,
    INGEST_BATCH_SIZE,
    NORMALIZE_EMBEDDINGS,
)


def _resolve_device(device: str) -> str:
    """Lùi về CPU nếu 'cuda' được yêu cầu nhưng máy hiện tại không có GPU khả dụng."""
    if device == "cuda" and not torch.cuda.is_available():
        print("[embedding] Cảnh báo: CUDA không khả dụng, tự động chuyển sang CPU (sẽ chậm hơn).")
        return "cpu"
    return device


class Embedder:
    """Bọc SentenceTransformer cho model bge-m3, tách 2 nhu cầu dùng khác nhau."""

    def __init__(self, model_name: str = EMBEDDING_MODEL, device: str = EMBEDDING_DEVICE):
        self.device = _resolve_device(device)
        self.model = SentenceTransformer(model_name, device=self.device)
        # Giới hạn độ dài chuỗi đầu vào (tính theo token của chính tokenizer model
        # này) — chunk quá dài sẽ bị CẮT BỚT, không báo lỗi. Đặt trùng với
        # CHUNK_SIZE trong config để tránh mất nội dung ngoài ý muốn.
        self.model.max_seq_length = EMBEDDING_MAX_TOKENS

    def get_gpu_temp(self) -> int:
        """Lấy nhiệt độ GPU hiện tại bằng cách gọi nvidia-smi."""
        try:
            res = subprocess.run(
                ["nvidia-smi", "--query-gpu=temperature.gpu", "--format=csv,noheader,nounits"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=True
            )
            return int(res.stdout.strip())
        except Exception:
            return 0

    def check_and_cooldown_gpu(self, threshold_temp: int = 77, target_temp: int = 68, check_interval_sec: int = 10):
        """Kiểm tra và hạ nhiệt GPU nếu vượt ngưỡng threshold_temp."""
        temp = self.get_gpu_temp()
        if temp > threshold_temp:
            print(f"\n[GPU Cooldown] Cảnh báo: Nhiệt độ GPU đạt {temp}°C (ngưỡng an toàn: {threshold_temp}°C).")
            print(f"[GPU Cooldown] Tạm dừng tiến trình để GPU hạ nhiệt xuống dưới {target_temp}°C...")
            checks = 0
            while temp > target_temp and checks < 4:
                time.sleep(check_interval_sec)
                temp = self.get_gpu_temp()
                checks += 1
                print(f"  -> Nhiệt độ GPU: {temp}°C (Mục tiêu: <{target_temp}°C)...")
            print(f"[GPU Cooldown] GPU đã hạ nhiệt an toàn ({temp}°C). Tiếp tục tiến trình...\n")

    def embed_texts(self, texts: list[str], batch_size: int = INGEST_BATCH_SIZE) -> np.ndarray:
        """
        Mã hoá NHIỀU đoạn văn (dùng khi ingest cả kho tài liệu).

        batch_size giới hạn số câu gửi lên GPU cùng lúc — kiểm soát VRAM.
        Có chia nhỏ danh sách (block_size=32) và kiểm tra nhiệt độ GPU để hạ nhiệt tránh quá nhiệt.
        """
        if not texts:
            return np.empty((0, self.model.get_sentence_embedding_dimension()))

        # Nếu không sử dụng GPU (cuda), chạy trực tiếp toàn bộ
        if self.device != "cuda":
            return self.model.encode(
                texts,
                batch_size=batch_size,
                normalize_embeddings=NORMALIZE_EMBEDDINGS,
                show_progress_bar=len(texts) > batch_size,
                convert_to_numpy=True,
            )

        # Nếu chạy trên GPU (cuda): chia nhỏ thành các block để định kỳ kiểm tra nhiệt độ GPU
        block_size = 32
        all_embeddings = []
        
        # In tiến độ block nếu lượng dữ liệu lớn
        show_blocks = len(texts) > block_size
        
        for i in range(0, len(texts), block_size):
            # Kiểm tra nhiệt độ trước khi đẩy block mới vào GPU
            self.check_and_cooldown_gpu()
            
            block = texts[i : i + block_size]
            if show_blocks:
                print(f"[ingest-gpu] Đang embed block {i // block_size + 1} / {int(np.ceil(len(texts) / block_size))}...")
            
            embeddings = self.model.encode(
                block,
                batch_size=batch_size,
                normalize_embeddings=NORMALIZE_EMBEDDINGS,
                show_progress_bar=False,
                convert_to_numpy=True,
            )
            all_embeddings.append(embeddings)
            
        return np.vstack(all_embeddings)

    def embed_query(self, query: str) -> np.ndarray:
        """
        Mã hoá MỘT câu hỏi đơn (dùng khi trả lời truy vấn).

        Tách riêng hàm này (thay vì gọi embed_texts([query])) để code ở
        retriever.py rõ ý nghĩa hơn, và là nơi hợp lý để thêm logic riêng cho
        query trong tương lai (ví dụ: instruction prefix, nếu đổi sang model khác).
        """
        vectors = self.model.encode(
            [query],
            normalize_embeddings=NORMALIZE_EMBEDDINGS,
            convert_to_numpy=True,
        )
        return vectors[0]


@lru_cache(maxsize=1)
def get_embedder() -> Embedder:
    """
    Trả về MỘT instance Embedder duy nhất, dùng chung cho cả chương trình.

    Vì sao cần cache: nạp model từ đĩa lên GPU mất vài giây và chiếm ~2.3GB VRAM.
    Nếu mỗi lần gọi get_embedder() lại tạo Embedder() mới, retriever.py (gọi hàm
    này mỗi câu hỏi của người dùng) sẽ nạp lại model hàng trăm lần — vừa chậm vừa
    có thể tràn VRAM vì model cũ chưa được giải phóng.
    """
    return Embedder()


if __name__ == "__main__":
    # Chạy `python -m src.embedding` từ thư mục gốc để thử nhanh (sẽ tải model
    # bge-m3 ~2.3GB từ HuggingFace nếu chưa có sẵn trong cache).
    embedder = get_embedder()
    vectors = embedder.embed_texts(["Xin chào", "Retrieval-Augmented Generation là gì?"])
    print(f"Đã nạp model trên thiết bị: {embedder.device}")
    print(f"Shape vector: {vectors.shape}")  # kỳ vọng (2, 1024) — bge-m3 có 1024 chiều
