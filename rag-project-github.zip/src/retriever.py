"""
retriever.py — Retrieval (top-k).

LÝ THUYẾT:
    Đây là bước NỐI liền embedding (Ngày 2) và vectordb (Ngày 2) thành một quy
    trình duy nhất mà các phần khác của hệ thống (app.py, evaluation.py, và sau
    này reranker.py) chỉ cần gọi MỘT hàm: đưa vào câu hỏi (string), nhận về
    danh sách chunk liên quan nhất (đã sắp xếp gần -> xa).

    Retriever không tự làm gì "thông minh" cả — nó chỉ là dây nối. Nhưng tách
    thành class riêng (thay vì gọi `store.query(embedder.embed_query(q))` trực
    tiếp ở mọi nơi cần retrieval) mang lại 2 lợi ích:
      - Dễ TEST độc lập: tiêm (inject) VectorStore/Embedder giả vào để test
        không cần model thật hay dữ liệu thật (xem tests/test_retriever.py).
      - Dễ MỞ RỘNG: Ngày 4 reranker.py sẽ BỌC THÊM một lớp quanh kết quả của
        Retriever này (nhận list các chunk, chấm lại điểm), chứ không cần sửa
        lại logic vector search gốc ở đây.

THIẾT KẾ:
    ChromaDB trả về "distance" (cosine distance — CÀNG NHỎ càng giống). Ta thêm
    trường "similarity" = 1 - distance (CÀNG LỚN càng giống) vào mỗi kết quả,
    vì con người thường trực giác nghĩ theo "độ giống nhau" hơn là "khoảng
    cách" khi đọc log/debug hoặc hiển thị lên UI (Ngày 7). Việc này KHÔNG đổi
    thứ tự xếp hạng của Chroma, chỉ thêm một góc nhìn dễ đọc hơn.
"""

from src.config import TOP_K
from src.embedding import Embedder, get_embedder
from src.vectordb import VectorStore
from src.bm25 import BM25Searcher


class Retriever:
    """Nối Embedder + VectorStore + BM25: nhận câu hỏi (str), trả về top-k chunk liên quan."""

    def __init__(self, store: VectorStore | None = None, embedder: Embedder | None = None):
        self.store = store if store is not None else VectorStore()
        self.embedder = embedder if embedder is not None else get_embedder()
        self.bm25_searcher = BM25Searcher(self.store)

    def retrieve(self, query: str, top_k: int = TOP_K, mode: str | None = None) -> list[dict]:
        """
        Tìm kiếm các chunk liên quan nhất.
        Hỗ trợ 3 chế độ: 'dense', 'bm25', 'hybrid'.
        """
        if mode is None:
            from src.config import RETRIEVAL_MODE
            mode = RETRIEVAL_MODE

        if mode == "dense":
            query_vector = self.embedder.embed_query(query)
            hits = self.store.query(query_vector, top_k=top_k)
            for hit in hits:
                hit["similarity"] = 1.0 - hit["distance"]
            return hits

        elif mode == "bm25":
            if self.bm25_searcher.bm25 is None:
                self.bm25_searcher.fit()
            hits = self.bm25_searcher.query(query, top_k=top_k)
            for hit in hits:
                hit["similarity"] = 1.0 - hit["distance"]
            return hits

        elif mode == "hybrid":
            # 1. Lấy kết quả từ Dense
            query_vector = self.embedder.embed_query(query)
            dense_hits = self.store.query(query_vector, top_k=top_k)
            for hit in dense_hits:
                hit["similarity"] = 1.0 - hit["distance"]

            # 2. Lấy kết quả từ BM25
            if self.bm25_searcher.bm25 is None:
                self.bm25_searcher.fit()
            bm25_hits = self.bm25_searcher.query(query, top_k=top_k)
            for hit in bm25_hits:
                hit["similarity"] = 1.0 - hit["distance"]

            # 3. Kết hợp Reciprocal Rank Fusion (RRF)
            from src.config import RRF_K

            id_to_hit = {}
            dense_ranks = {}
            bm25_ranks = {}

            for rank, hit in enumerate(dense_hits, start=1):
                h_id = hit["id"]
                id_to_hit[h_id] = hit
                dense_ranks[h_id] = rank

            for rank, hit in enumerate(bm25_hits, start=1):
                h_id = hit["id"]
                if h_id not in id_to_hit:
                    id_to_hit[h_id] = hit
                bm25_ranks[h_id] = rank

            rrf_scores = {}
            for h_id in id_to_hit:
                score = 0.0
                if h_id in dense_ranks:
                    score += 1.0 / (RRF_K + dense_ranks[h_id])
                if h_id in bm25_ranks:
                    score += 1.0 / (RRF_K + bm25_ranks[h_id])
                rrf_scores[h_id] = score

            # Sắp xếp theo điểm RRF giảm dần
            sorted_ids = sorted(rrf_scores.keys(), key=lambda x: rrf_scores[x], reverse=True)

            hybrid_hits = []
            for h_id in sorted_ids[:top_k]:
                hit = id_to_hit[h_id].copy()
                hit["rrf_score"] = rrf_scores[h_id]
                hybrid_hits.append(hit)

            return hybrid_hits
        else:
            raise ValueError(f"Retrieval mode không hợp lệ: {mode}")


if __name__ == "__main__":
    # Chạy `python -m src.retriever "câu hỏi của bạn"` để thử nhanh trên dữ liệu thật
    # (yêu cầu đã chạy `python ingest.py` trước đó).
    import sys

    query = " ".join(sys.argv[1:]) or "What is the attention mechanism in Transformers?"
    retriever = Retriever()
    hits = retriever.retrieve(query, top_k=5)

    print(f"Câu hỏi: {query}\n")
    for rank, hit in enumerate(hits, start=1):
        meta = hit["metadata"]
        print(f"[{rank}] similarity={hit['similarity']:.3f}  {meta['source']} (trang {meta['page']})")
        print(f"     {hit['text'][:150]}...\n")
