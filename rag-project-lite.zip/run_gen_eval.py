"""
Chạy generation evaluation trực tiếp, ghi log vào file bằng logging module.
Không override sys.stdout để tránh xung đột với config.py reconfigure.
"""
import sys, os, logging, traceback

sys.path.insert(0, '.')

# Setup file logger (không đụng stdout)
LOG_FILE = os.path.join("reports", "gen_eval_progress.log")
os.makedirs("reports", exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_FILE, encoding="utf-8", mode="a"),
        logging.StreamHandler(sys.stderr),
    ]
)
log = logging.getLogger("gen_eval")

log.info("=" * 60)
log.info("BẮT ĐẦU GENERATION EVALUATION")
log.info("=" * 60)

try:
    log.info("Step 1: Importing modules...")
    from src.config import EMBEDDING_DEVICE, RERANKER_DEVICE, DATA_DIR
    log.info(f"  EMBEDDING_DEVICE={EMBEDDING_DEVICE}, RERANKER_DEVICE={RERANKER_DEVICE}")

    log.info("Step 2: Loading Embedder...")
    from src.embedding import Embedder
    embedder = Embedder(device=EMBEDDING_DEVICE)
    log.info("  Embedder OK")

    log.info("Step 3: Loading Retriever...")
    from src.retriever import Retriever
    retriever = Retriever(embedder=embedder)
    log.info("  Retriever OK")

    log.info("Step 4: Loading Reranker...")
    from src.reranker import Reranker
    reranker = Reranker(device=RERANKER_DEVICE)
    log.info("  Reranker OK")

    log.info("Step 5: Loading evaluation functions...")
    from ask import answer_question
    from evaluation import check_refusal, faithfulness_score, load_golden_qa, rouge_l
    import json, time
    from pathlib import Path

    golden_qa = load_golden_qa()
    log.info(f"  Loaded {len(golden_qa)} golden QA questions")

    OUTPUT_JSON = DATA_DIR.parent / "reports" / "generation_evaluation_results.json"
    TEMP_JSON = DATA_DIR.parent / "reports" / "generation_evaluation_temp.json"

    answerable_items = [item for item in golden_qa if item.get("expected_source") is not None]
    unanswerable_items = [item for item in golden_qa if item.get("expected_source") is None]
    log.info(f"  Answerable: {len(answerable_items)}, Unanswerable: {len(unanswerable_items)}")

    # Resume from checkpoint
    start_index = 0
    results_detail = []
    if TEMP_JSON.exists():
        try:
            temp_data = json.loads(TEMP_JSON.read_text(encoding="utf-8"))
            results_detail = temp_data.get("details", [])
            start_index = len(results_detail)
            log.info(f"  RESUME: Found checkpoint, continuing from question #{start_index + 1}")
        except Exception as e:
            log.warning(f"  Could not load checkpoint: {e}, starting fresh")
            results_detail = []

    log.info(f"Processing questions {start_index+1} to {len(golden_qa)}...")

    for i in range(start_index, len(golden_qa)):
        item = golden_qa[i]
        q_idx = i + 1
        q = item["question"]
        expected_ans = item.get("expected_answer", "")
        is_unanswerable = item.get("expected_source") is None
        q_type = "Unanswerable" if is_unanswerable else "Answerable"

        log.info(f"  [{q_idx}/{len(golden_qa)}] {q_type}: {q[:80]}...")

        t_start = time.time()
        result = answer_question(q, retriever=retriever, reranker=reranker, log_path=None)
        t_end = time.time()

        ans = result["answer"]
        ret_ms = result["retrieval_latency_ms"]
        rerank_ms = result["reranker_latency_ms"]
        llm_ms = result["llm_latency_ms"]
        tot_ms = result["total_latency_ms"]

        if not is_unanswerable and expected_ans:
            r_score = rouge_l(ans, expected_ans)
            f_score = faithfulness_score(ans, result.get("context_chunks", []))
            refused = False
        else:
            r_score = None
            f_score = None
            refused = check_refusal(ans)

        results_detail.append({
            "id": q_idx,
            "question": q,
            "type": q_type,
            "expected_answer": expected_ans,
            "generated_answer": ans,
            "rouge_l": r_score,
            "faithfulness_score": f_score,
            "refused": refused if is_unanswerable else None,
            "retrieval_latency_ms": ret_ms,
            "reranker_latency_ms": rerank_ms,
            "llm_latency_ms": llm_ms,
            "total_latency_ms": tot_ms,
        })

        # Save checkpoint immediately
        TEMP_JSON.parent.mkdir(parents=True, exist_ok=True)
        TEMP_JSON.write_text(
            json.dumps({"details": results_detail}, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )

        r_str = f"{r_score:.3f}" if r_score is not None else "N/A"
        f_str = f"{f_score:.3f}" if f_score is not None else "N/A"
        ref_str = str(refused) if is_unanswerable else "N/A"
        log.info(f"    ROUGE-L={r_str} | Faith={f_str} | Refused={ref_str} | "
                 f"Ret={ret_ms:.0f}ms Rerank={rerank_ms:.0f}ms LLM={llm_ms:.0f}ms Total={tot_ms:.0f}ms")

    # Compute summary
    rouge_scores = [d["rouge_l"] for d in results_detail if d["type"] == "Answerable" and d["rouge_l"] is not None]
    faith_scores = [d["faithfulness_score"] for d in results_detail if d["type"] == "Answerable" and d["faithfulness_score"] is not None]
    n_refused = sum(1 for d in results_detail if d["type"] == "Unanswerable" and d.get("refused"))
    refusal_rate = n_refused / len(unanswerable_items) if unanswerable_items else 0.0

    ret_lats = [d["retrieval_latency_ms"] for d in results_detail]
    rer_lats = [d["reranker_latency_ms"] for d in results_detail]
    llm_lats = [d["llm_latency_ms"] for d in results_detail]
    tot_lats = [d["total_latency_ms"] for d in results_detail]

    summary = {
        "n_total_questions": len(golden_qa),
        "n_answerable": len(answerable_items),
        "n_unanswerable": len(unanswerable_items),
        "avg_rouge_l": round(sum(rouge_scores) / len(rouge_scores), 4) if rouge_scores else 0.0,
        "avg_faithfulness_score": round(sum(faith_scores) / len(faith_scores), 4) if faith_scores else 0.0,
        "refusal_rate": round(refusal_rate, 4),
        "n_correctly_refused": n_refused,
        "avg_retrieval_latency_ms": round(sum(ret_lats) / len(ret_lats), 1),
        "avg_reranker_latency_ms": round(sum(rer_lats) / len(rer_lats), 1),
        "avg_llm_latency_ms": round(sum(llm_lats) / len(llm_lats), 1),
        "avg_total_latency_ms": round(sum(tot_lats) / len(tot_lats), 1),
        "details": results_detail,
    }

    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")

    if TEMP_JSON.exists():
        TEMP_JSON.unlink()

    log.info("=" * 60)
    log.info("KẾT QUẢ TỔNG HỢP:")
    log.info(f"  ROUGE-L (F1):        {summary['avg_rouge_l']:.4f}")
    log.info(f"  Faithfulness:        {summary['avg_faithfulness_score']:.4f}")
    log.info(f"  Refusal Rate:        {summary['refusal_rate']*100:.1f}% ({n_refused}/{len(unanswerable_items)})")
    log.info(f"  Avg Retrieval:       {summary['avg_retrieval_latency_ms']} ms")
    log.info(f"  Avg Reranker:        {summary['avg_reranker_latency_ms']} ms")
    log.info(f"  Avg LLM:             {summary['avg_llm_latency_ms']} ms")
    log.info(f"  Avg Total:           {summary['avg_total_latency_ms']} ms")
    log.info(f"  Saved to: {OUTPUT_JSON}")
    log.info("=" * 60)
    log.info("HOÀN TẤT!")

except BaseException as e:
    log.error(f"FATAL ERROR: {e}")
    log.error(traceback.format_exc())
    sys.exit(1)
