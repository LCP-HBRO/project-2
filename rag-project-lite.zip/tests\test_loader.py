"""
Test độc lập cho loader.py.

Không phụ thuộc vào tài liệu thật trong data/documents/ (thư mục đó có thể còn
trống) — mỗi test tự tạo file tạm (PDF/MD/TXT) trong tmp_path do pytest cấp,
để test chạy được ngay cả trước khi bạn tải bộ tài liệu về.
"""

import fitz
import pytest

from src.loader import load_documents, load_pdf, load_docx
import docx


def _make_pdf(path, pages_text: list[str]):
    """Tạo một PDF thật (không phải mock) có N trang, mỗi trang chứa một chuỗi text."""
    doc = fitz.open()
    for text in pages_text:
        page = doc.new_page()
        page.insert_text((72, 72), text)
    doc.save(path)
    doc.close()


def test_load_docx(tmp_path):
    path = tmp_path / "note.docx"
    doc_obj = docx.Document()
    doc_obj.add_paragraph("Nội dung Word docx.")
    doc_obj.save(path)

    docs = load_docx(path)

    assert len(docs) == 1
    assert docs[0].source == "note.docx"
    assert docs[0].page is None
    assert "Nội dung Word" in docs[0].text


def test_load_pdf_one_document_per_page(tmp_path):
    path = tmp_path / "paper.pdf"
    _make_pdf(path, ["Trang mot noi dung A", "Trang hai noi dung B"])

    docs = load_pdf(path)

    assert len(docs) == 2
    assert [d.page for d in docs] == [1, 2]
    assert all(d.source == "paper.pdf" for d in docs)
    assert "Trang mot" in docs[0].text
    assert "Trang hai" in docs[1].text


def test_load_pdf_skips_blank_pages(tmp_path):
    path = tmp_path / "with_blank.pdf"
    _make_pdf(path, ["Co noi dung", ""])  # trang 2 để trắng (không insert_text)

    docs = load_pdf(path)

    # Trang trắng bị bỏ qua -> chỉ còn 1 Document, vẫn giữ đúng số trang gốc (1)
    assert len(docs) == 1
    assert docs[0].page == 1


def test_load_documents_scans_mixed_formats(tmp_path):
    _make_pdf(tmp_path / "a.pdf", ["Noi dung PDF"])
    
    docx_path = tmp_path / "b.docx"
    doc_obj = docx.Document()
    doc_obj.add_paragraph("Noi dung Word docx")
    doc_obj.save(docx_path)
    
    (tmp_path / "ignore.png").write_bytes(b"\x89PNG\r\n")  # không hỗ trợ -> phải bị bỏ qua

    docs = load_documents(tmp_path)

    sources = {d.source for d in docs}
    assert sources == {"a.pdf", "b.docx"}
    assert len(docs) == 2
