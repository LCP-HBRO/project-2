"""
scripts/compare_llms.py — So sánh chất lượng GENERATION giữa Qwen (local) và
Gemini (API) trên CÙNG một pipeline retrieval/reranker.

Đây là một thí nghiệm ĐỐI CHỨNG (control experiment): với mỗi câu hỏi, phần
retrieval + rerank + dựng prompt được chạy ĐÚNG MỘT LẦN, rồi CÙNG một prompt/
ngữ cảnh được đưa cho CẢ HAI LLM. Nhờ đó mọi chênh lệch chỉ số chỉ phản ánh
năng lực của bản thân LLM, không lẫn với khác biệt ở khâu retrieval.

Chỉ số so sánh:
  - refusal_rate (câu "unanswerable"): tỉ lệ model TỪ CHỐI đúng cách thay vì bịa.
  - ROUGE-L & faithfulness (câu có đáp án, CHỈ khi --full): chất lượng câu trả lời.

Chạy TỪ THƯ MỤC GỐC:
    python -m scripts.compare_llms              # chỉ so sánh refusal (nhanh, 5 câu)
    python -m scripts.compare_llms --full       # thêm ROUGE-L/faithfulness (chậm)
    python -m scripts.compare_llms --full --limit 5   # giới hạn số câu có đáp án

Yêu cầu: đã set GEMINI_API_KEY (nếu thiếu, script vẫn chạy phần Qwen và bỏ qua
Gemini kèm cảnh báo).
"""

import argparse
import os

from evaluation import check_refusal, faithfulness_score, load_golden_qa, rouge_l
from src.llm import generate_answer
from src.prompt_builder import build_prompt
from src.reranker import get_reranker
from src.retriever import Retriever


def _gemini_available() -> bool:
    return bool(os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY"))


def _mean(values: list[float]) -> float:
    return sum(values) / len(values) if values else float("nan")


def main() -> None:
    parser = argparse.ArgumentParser(description="So sánh Qwen vs Gemini trên cùng pipeline RAG.")
    parser.add_argument("--full", action="store_true",
                        help="Chạy thêm ROUGE-L/faithfulness trên các câu CÓ đáp án (chậm hơn nhiều).")
    parser.add_argument("--limit", type=int, default=None,
                        help="Giới hạn số câu CÓ đáp án khi --full (để chạy thử nhanh).")
    args = parser.parse_args()

    gemini_on = _gemini_available()
    if gemini_on:
        from ask_gemini import GEMINI_MODEL, generate_answer_gemini
    else:
        print("[cảnh báo] Chưa set GEMINI_API_KEY -> chỉ chạy Qwen, bỏ qua Gemini.\n")
        GEMINI_MODEL = "(không chạy)"

    golden_qa = load_golden_qa()
    retriever = Retriever()
    reranker = get_reranker()

    unanswerable = [q for q in golden_qa if q.get("expected_source") is None]
    answerable = [q for q in golden_qa if q.get("expected_source") is not None]
    if args.full and args.limit:
        answerable = answerable[: args.limit]

    # Gom kết quả để tính trung bình cuối cùng.
    qwen_refused = gemini_refused = 0
    qwen_rouge, qwen_faith, gem_rouge, gem_faith = [], [], [], []

    def answer_both(prompt: str) -> tuple[str, str | None]:
        """Trả về (câu trả lời Qwen, câu trả lời Gemini|None) cho cùng một prompt."""
        a_qwen = generate_answer(prompt)
        a_gem = generate_answer_gemini(prompt) if gemini_on else None
        return a_qwen, a_gem

    # ---- 1. REFUSAL trên câu unanswerable (luôn chạy) ----
    print("=" * 70)
    print("REFUSAL — câu hỏi KHÔNG có đáp án trong corpus (mong đợi: model TỪ CHỐI)")
    print("=" * 70)
    for item in unanswerable:
        hits = retriever.retrieve(item["question"])
        reranked = reranker.rerank(item["question"], hits)
        prompt = build_prompt(item["question"], reranked)
        a_qwen, a_gem = answer_both(prompt)

        r_qwen = check_refusal(a_qwen)
        qwen_refused += r_qwen
        line = f"  Qwen {'TỪ CHỐI ✔' if r_qwen else 'BỊA ✗'}"
        if gemini_on:
            r_gem = check_refusal(a_gem)
            gemini_refused += r_gem
            line += f"  |  Gemini {'TỪ CHỐI ✔' if r_gem else 'BỊA ✗'}"
        print(f"- {item['question'][:65]}")
        print(f"  {line}")

    # ---- 2. ROUGE-L / faithfulness trên câu có đáp án (chỉ khi --full) ----
    if args.full:
        print("\n" + "=" * 70)
        print(f"GENERATION — {len(answerable)} câu CÓ đáp án (ROUGE-L vs đáp án mẫu, faithfulness vs ngữ cảnh)")
        print("=" * 70)
        for i, item in enumerate(answerable, start=1):
            hits = retriever.retrieve(item["question"])
            reranked = reranker.rerank(item["question"], hits)
            prompt = build_prompt(item["question"], reranked)
            context_chunks = [c["text"] for c in reranked]
            ref = item.get("expected_answer") or ""

            a_qwen, a_gem = answer_both(prompt)
            qwen_rouge.append(rouge_l(a_qwen, ref))
            qwen_faith.append(faithfulness_score(a_qwen, context_chunks))
            if gemini_on:
                gem_rouge.append(rouge_l(a_gem, ref))
                gem_faith.append(faithfulness_score(a_gem, context_chunks))
            print(f"  [{i}/{len(answerable)}] đã chấm: {item['question'][:55]}...")

    # ---- 3. BẢNG TỔNG KẾT ----
    n_unans = len(unanswerable)
    print("\n" + "=" * 70)
    print("TỔNG KẾT")
    print("=" * 70)
    header = f"{'Chỉ số':<28} {'Qwen (local)':<16} {'Gemini ' + GEMINI_MODEL:<24}"
    print(header)
    print("-" * len(header))
    gem_ref_str = f"{gemini_refused}/{n_unans} ({gemini_refused/n_unans:.2f})" if gemini_on else "—"
    print(f"{'refusal_rate':<28} {f'{qwen_refused}/{n_unans} ({qwen_refused/n_unans:.2f})':<16} {gem_ref_str:<24}")
    if args.full:
        gem_rouge_str = f"{_mean(gem_rouge):.3f}" if gemini_on else "—"
        gem_faith_str = f"{_mean(gem_faith):.3f}" if gemini_on else "—"
        print(f"{'ROUGE-L (trung bình)':<28} {f'{_mean(qwen_rouge):.3f}':<16} {gem_rouge_str:<24}")
        print(f"{'faithfulness (trung bình)':<28} {f'{_mean(qwen_faith):.3f}':<16} {gem_faith_str:<24}")


if __name__ == "__main__":
    main()
