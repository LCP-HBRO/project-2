"""
config.py — Trung tâm cấu hình của toàn bộ hệ thống RAG.

TRIẾT LÝ:
    Mọi "con số ma thuật" (magic number) và tên model đều nằm ở ĐÂY, không rải
    rác trong code. Lý do: RAG là công việc THÍ NGHIỆM. Bạn sẽ liên tục đổi
    chunk_size, top_k, có/không reranker... để xem retrieval tốt lên hay xấu đi.
    Nếu các tham số này nằm rải rác trong từng file, mỗi lần thí nghiệm bạn phải
    sửa nhiều nơi -> dễ sai, khó tái lập kết quả. Gom về một chỗ = đổi 1 dòng,
    chạy lại, so sánh.

THIẾT KẾ:
    Ở đây dùng "hằng số cấp module" (module-level constants) thay vì class hay
    pydantic Settings. Với dự án học, cách này dễ hiểu nhất: các file khác chỉ
    cần `from config import CHUNK_SIZE`. (Khi lên production người ta thường dùng
    pydantic-settings để đọc từ biến môi trường / file .env — ta không cần ở đây.)
"""

import sys
from pathlib import Path

if sys.platform == "win32":
    # Console mặc định của Windows dùng codepage cp1252, KHÔNG hiển thị được
    # tiếng Việt có dấu -> mọi print() tiếng Việt sẽ crash với UnicodeEncodeError
    # khi chạy `python -m src.xxx` từ PowerShell/cmd. Vì config.py được import
    # đầu tiên bởi mọi module khác, ép stdout/stderr sang UTF-8 ở đây một lần
    # là đủ cho toàn bộ dự án, thay vì lặp lại ở từng file.
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass
    try:
        sys.stderr.reconfigure(encoding="utf-8")
    except Exception:
        pass

# ============================================================================
# 1. ĐƯỜNG DẪN (PATHS)
# ============================================================================
# __file__ là đường dẫn tới chính config.py (nằm trong src/).
# .resolve() -> đường dẫn tuyệt đối; .parent.parent -> lùi 2 cấp: src/ -> gốc dự án.
# Dùng pathlib thay vì nối chuỗi "a/b/c" để code chạy đúng trên cả Windows lẫn Linux.
BASE_DIR = Path(__file__).resolve().parent.parent

DATA_DIR = BASE_DIR / "data"
DOCUMENTS_DIR = DATA_DIR / "documents"   # nơi để PDF / Markdown / TXT nguồn
CHROMA_DIR = DATA_DIR / "chroma"         # nơi ChromaDB lưu index xuống ổ đĩa (persistent)

# Tạo sẵn thư mục nếu chưa có, tránh lỗi "folder not found" khi chạy lần đầu.
DOCUMENTS_DIR.mkdir(parents=True, exist_ok=True)
CHROMA_DIR.mkdir(parents=True, exist_ok=True)

# ============================================================================
# 2. CHUNKING — cắt tài liệu thành đoạn nhỏ (phần CỐT LÕI của Retrieval)
# ============================================================================
# Vì sao phải cắt nhỏ? Embedding model có giới hạn độ dài, và một câu hỏi thường
# chỉ liên quan tới một đoạn nhỏ chứ không phải cả tài liệu 20 trang. Chunk càng
# "vừa vặn" với ý -> retrieval càng chính xác.
#
#   - CHUNK_SIZE quá LỚN: mỗi chunk lẫn nhiều chủ đề -> vector bị "loãng", tìm kém.
#   - CHUNK_SIZE quá NHỎ: mất ngữ cảnh, câu bị cắt cụt.
#   - OVERLAP: cho 2 chunk liền nhau chồng lấn vài token, tránh làm đứt một ý
#     nằm ngay ranh giới cắt.
# Đây chính là các số bạn sẽ thí nghiệm ở Ngày 3.
CHUNK_SIZE = 512        # số token mỗi chunk (xấp xỉ)
CHUNK_OVERLAP = 64      # số token chồng lấn giữa 2 chunk liền nhau

# Riêng cho chiến lược "semantic" (xem chunker.py): điểm gãy giữa 2 câu liên
# tiếp được coi là "ranh giới chủ đề" nếu khoảng cách ngữ nghĩa của nó nằm
# trong percentile này so với TOÀN BỘ khoảng cách trong chính tài liệu đó.
# Percentile càng CAO -> càng ít điểm gãy được chấp nhận -> chunk càng LỚN/ít.
SEMANTIC_BREAKPOINT_PERCENTILE = 95.0

# ============================================================================
# 3. EMBEDDING — biến văn bản thành vector số
# ============================================================================
EMBEDDING_MODEL = "BAAI/bge-m3"   # đa ngôn ngữ, hỗ trợ tốt cả tiếng Việt
EMBEDDING_DEVICE = "cuda"         # chạy trên GPU RTX 3050 cho nhanh khi ingest
                                   # đổi thành "cpu" nếu chưa cài đúng bản torch-CUDA

# Số chunk gửi lên GPU mỗi lần khi nạp dữ liệu. Đã giảm xuống 4 để tránh quá tải nhiệt cho GPU Laptop.
INGEST_BATCH_SIZE = 4

# bge-m3 hỗ trợ tới 8192 token/lần, NHƯNG chuỗi càng dài càng tốn VRAM.
# Ta giới hạn 512 cho khớp với CHUNK_SIZE -> tiết kiệm bộ nhớ, đủ dùng.
EMBEDDING_MAX_TOKENS = 512

# Chuẩn hoá vector về độ dài 1 (L2-normalize). Khi đó "khoảng cách cosine" và
# "tích vô hướng" tương đương nhau -> tìm kiếm nhất quán. Nên để True với bge-m3.
NORMALIZE_EMBEDDINGS = True

# ============================================================================
# 4. VECTOR DATABASE (ChromaDB)
# ============================================================================
COLLECTION_NAME = "ai_knowledge"   # tên "bảng" chứa vector trong Chroma
# Hàm đo độ tương đồng giữa các vector. "cosine" hợp với vector đã chuẩn hoá.
# Lựa chọn khác: "l2" (khoảng cách Euclid), "ip" (inner product).
DISTANCE_METRIC = "cosine"

# ============================================================================
# 5. RETRIEVAL — tìm top-k chunk gần nhất với câu hỏi
# ============================================================================
# Lấy nhiều ứng viên (TOP_K) từ vector search, rồi để reranker lọc lại tinh (RERANK_TOP_N).
# Đây là mẫu 2 tầng kinh điển: tầng 1 nhanh & rộng, tầng 2 chậm & chính xác.
TOP_K = 20            # số ứng viên vector search trả về (tầng 1 - thô)
RERANK_TOP_N = 5      # số chunk tốt nhất sau reranker, đưa vào prompt (tầng 2 - tinh)

# --- HYBRID RETRIEVAL ---
# Chế độ tìm kiếm mặc định: "dense", "bm25", hoặc "hybrid"
RETRIEVAL_MODE = "hybrid"
# Hằng số điều phối thứ hạng trong Reciprocal Rank Fusion (RRF)
# k càng lớn thì mức độ phạt thứ hạng thấp càng giảm. Mặc định 60 là tối ưu.
RRF_K = 60

# ============================================================================
# 6. RERANKER (Cross-Encoder)
# ============================================================================
RERANKER_MODEL = "BAAI/bge-reranker-v2-m3"
# QUYẾT ĐỊNH NÀY ĐÃ ĐỔI SAU KHI ĐO THỰC NGHIỆM (không chỉ suy luận trên giấy):
# ban đầu định để CPU vì lý do VRAM, nhưng đo thật cho thấy CPU rerank 20 cặp
# mất tới 23.3s — quá chậm cho một trợ lý hỏi-đáp tương tác. Trên GPU chỉ mất
# 2.0s (nhanh gấp ~11 lần), đổi lại embedding+reranker cùng lúc trên GPU chiếm
# đỉnh ~5.02GB VRAM (đo bằng torch.cuda.max_memory_allocated), chỉ còn ~1.4GB
# cho LLM -> đây là lý do LLM_MODEL bên dưới đổi từ 3B xuống 1.5B để vừa ngân
# sách. Bài học: LUÔN ĐO THẬT thay vì chỉ ước tính VRAM/latency trên giấy.
RERANKER_DEVICE = "cuda"

# bge-reranker-v2-m3 kế thừa kiến trúc bge-m3 nên mặc định hỗ trợ tới 8192 token
# -> nếu không giới hạn, CrossEncoder sẽ pad/xử lý MỌI cặp ở độ dài 8192 dù chunk
# thực tế ngắn hơn nhiều, khiến latency CPU tăng vọt (đo thực tế: 20 cặp mất tới
# 41 GIÂY với max_length mặc định).
#
# LƯU Ý VỀ ĐƠN VỊ (bug đã tìm và sửa): bản đầu tiên đặt RERANKER_MAX_LENGTH =
# CHUNK_SIZE với lý do "chunk không bao giờ dài hơn giá trị này" — SAI, vì
# CHUNK_SIZE=512 đếm theo TỪ (word), còn max_length của CrossEncoder đếm theo
# TOKEN — hai đơn vị khác nhau (1 từ ≈ 1.3-1.4 token). Đo thật trên 2079 chunk
# đã ingest cho thấy 13.9% chunk vượt quá 512 token (dài nhất 1974 token) khi
# dùng max_length=512 -> bị CẮT CỤT trước khi đưa vào reranker mà không báo lỗi.
# 1024 phủ được 99.5% chunk (chỉ còn 0.5% bị cắt), đánh đổi lấy latency cao hơn
# đôi chút cho các batch chứa chunk dài — chấp nhận được vì reranker đã chạy GPU.
RERANKER_MAX_LENGTH = 1024

# BUG THẬT ĐÃ ĐO ĐƯỢC ("unlucky batch"): CrossEncoder.predict() tự sắp xếp các
# cặp theo độ dài trước khi tạo batch (length_sorted_idx trong source code
# sentence-transformers) — nhưng việc sắp xếp CHỈ có tác dụng khi có NHIỀU hơn
# 1 batch. Với batch_size mặc định (32) và TOP_K=20, cả 20 ứng viên của MỘT
# câu hỏi luôn rơi vào ĐÚNG 1 batch dù đã sắp xếp — nếu trong đó có 1 chunk dài
# gần RERANKER_MAX_LENGTH, CẢ BATCH bị pad theo độ dài đó, kéo cả 19 chunk ngắn
# còn lại chậm theo. Đo thật (1 chunk 1974 token + 19 chunk 3 token, cùng 1
# câu hỏi): batch_size=32 mất 4.7-24s (dao động theo GPU warm-up), batch_size=4
# chỉ mất ~1.0-1.1s — nhanh hơn 4-23 LẦN. Đây chính là nguyên nhân sweep ở
# scripts/sweep_params.py có lúc latency vọt lên 46s/câu hỏi (xem README).
# Giảm batch_size buộc các cặp đã sắp xếp theo độ dài phải tách thành NHIỀU
# batch nhỏ, cách ly chunk dài ra một batch riêng thay vì kéo theo cả nhóm.
RERANKER_BATCH_SIZE = 4

# ============================================================================
# 7. LLM (Qwen qua Ollama) — bước sinh câu trả lời, giữ ĐƠN GIẢN
# ============================================================================
# Đổi từ bản 3B xuống 1.5B (xem lý do ở RERANKER_DEVICE phía trên): sau khi
# chuyển reranker sang GPU, embedding+reranker đã chiếm đỉnh ~5.02GB, chỉ còn
# ~1.4GB cho LLM -> 3B (~2GB) không đủ an toàn, 1.5B (đã tải sẵn qua Ollama) vừa
# ngân sách hơn. Đánh đổi: chất lượng sinh câu trả lời thấp hơn 3B một chút,
# chấp nhận được vì dự án tập trung vào Retrieval, generation chỉ là bước phụ.
LLM_MODEL = "qwen2.5:1.5b"
OLLAMA_HOST = "http://localhost:11434"
LLM_NUM_GPU = 0                     # Chạy Ollama trên CPU để giải phóng VRAM GPU cho Embedder & Reranker
LLM_TEMPERATURE = 0.1               # thấp -> trả lời bám sát ngữ cảnh, ít bịa
LLM_MAX_TOKENS = 1024               # độ dài tối đa câu trả lời

# Ngôn ngữ assistant dùng để trả lời người dùng.
ANSWER_LANGUAGE = "Vietnamese"

# ============================================================================
# 8. TIỆN ÍCH — in cấu hình để kiểm tra nhanh
# ============================================================================
def summary() -> str:
    """Trả về chuỗi tóm tắt cấu hình hiện tại, dùng để in ra khi debug."""
    return (
        f"BASE_DIR         = {BASE_DIR}\n"
        f"DOCUMENTS_DIR    = {DOCUMENTS_DIR}\n"
        f"CHROMA_DIR       = {CHROMA_DIR}\n"
        f"CHUNK_SIZE       = {CHUNK_SIZE} (overlap {CHUNK_OVERLAP})\n"
        f"EMBEDDING_MODEL  = {EMBEDDING_MODEL} on {EMBEDDING_DEVICE}\n"
        f"RERANKER_MODEL   = {RERANKER_MODEL} on {RERANKER_DEVICE}\n"
        f"LLM_MODEL        = {LLM_MODEL}\n"
        f"RETRIEVAL_MODE   = {RETRIEVAL_MODE} (RRF_K={RRF_K})\n"
        f"TOP_K / RERANK_N = {TOP_K} / {RERANK_TOP_N}\n"
    )


if __name__ == "__main__":
    # Chạy `python src/config.py` để tự kiểm tra cấu hình có đúng không.
    print(summary())
