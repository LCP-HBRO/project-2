"""
evaluate_generation.py — Đánh giá ĐỊNH LƯỢNG chất lượng sinh câu trả lời (Generation Stage).

Đo đạc 4 chỉ số cốt lõi:
1. ROUGE-L (F1): Tỉ lệ trùng khớp giữa câu trả lời sinh ra và đáp án chuẩn trong golden_qa.json.
2. Faithfulness Score: Tỉ lệ từ trong câu trả lời xuất hiện trong ngữ cảnh retrieved (kiểm tra hallucination).
3. Refusal Rate: Tỉ lệ từ chối trả lời đúng cách cho các câu hỏi unanswerable.
4. Latency Breakdown: Độ trễ trung bình của từng chặng (Retrieval, Reranker, LLM, Total).
"""

import json
import time
from pathlib import Path

from ask import answer_question
from evaluation import check_refusal, faithfulness_score, load_golden_qa, rouge_l
from src.config import DATA_DIR
from src.reranker import get_reranker
from src.retriever import Retriever

OUTPUT_JSON = DATA_DIR.parent / "reports" / "generation_evaluation_results.json"


def evaluate_end_to_end():
    golden_qa = load_golden_qa()
    print(f"======================================================================")
    print(f"Đang đánh giá End-to-End LLM Generation trên {len(golden_qa)} câu hỏi vàng...")
    print(f"======================================================================\n")

    from src.embedding import Embedder
    from src.reranker import Reranker
    from src.config import EMBEDDING_DEVICE, RERANKER_DEVICE
    
    print(f"[evaluate] Khởi tạo Embedder trên {EMBEDDING_DEVICE} và Reranker trên {RERANKER_DEVICE}...")
    embedder = Embedder(device=EMBEDDING_DEVICE)
    retriever = Retriever(embedder=embedder)
    reranker = Reranker(device=RERANKER_DEVICE)

    answerable_items = [item for item in golden_qa if item.get("expected_source") is not None]
    unanswerable_items = [item for item in golden_qa if item.get("expected_source") is None]

    TEMP_JSON = DATA_DIR.parent / "reports" / "generation_evaluation_temp.json"
    
    # Check if we can resume
    start_index = 0
    results_detail = []
    if TEMP_JSON.exists():
        try:
            temp_data = json.loads(TEMP_JSON.read_text(encoding="utf-8"))
            results_detail = temp_data.get("details", [])
            start_index = len(results_detail)
            print(f"[resume] Tìm thấy kết quả tạm thời. Tiếp tục từ câu hỏi #{start_index + 1}...")
        except Exception as e:
            print(f"[resume] Lỗi khi nạp file tạm thời, bắt đầu lại từ đầu: {e}")
            results_detail = []

    answerable_items = [item for item in golden_qa if item.get("expected_source") is not None]
    unanswerable_items = [item for item in golden_qa if item.get("expected_source") is None]

    print(f"{'No.':<4} {'Type':<14} {'ROUGE-L':<10} {'Faithful':<10} {'Refused':<10} {'Total_Latency (ms)':<18}")
    print("-" * 70)

    for i in range(start_index, len(golden_qa)):
        item = golden_qa[i]
        q_idx = i + 1
        q = item["question"]
        expected_ans = item.get("expected_answer", "")
        is_unanswerable = item.get("expected_source") is None
        q_type = "Unanswerable" if is_unanswerable else "Answerable"

        # Gọi full pipeline RAG qua ask.py
        log = answer_question(q, retriever=retriever, reranker=reranker, log_path=None)

        ans = log["answer"]
        ret_ms = log["retrieval_latency_ms"]
        rerank_ms = log["reranker_latency_ms"]
        llm_ms = log["llm_latency_ms"]
        tot_ms = log["total_latency_ms"]

        # Lấy retrieved chunks từ sources_cited / hits để tính faithfulness
        sources_cited = log.get("sources_cited", [])
        
        # Tính ROUGE-L & Faithfulness cho câu answerable
        if not is_unanswerable and expected_ans:
            r_score = rouge_l(ans, expected_ans)
            f_score = faithfulness_score(ans, log.get("context_chunks", []))
            refused = False
        else:
            r_score = float("nan")
            f_score = float("nan")
            refused = check_refusal(ans)

        results_detail.append({
            "id": q_idx,
            "question": q,
            "type": q_type,
            "expected_answer": expected_ans,
            "generated_answer": ans,
            "rouge_l": r_score if not is_unanswerable else None,
            "faithfulness_score": f_score if not is_unanswerable else None,
            "refused": refused if is_unanswerable else None,
            "retrieval_latency_ms": ret_ms,
            "reranker_latency_ms": rerank_ms,
            "llm_latency_ms": llm_ms,
            "total_latency_ms": tot_ms,
        })

        # Lưu kết quả tạm thời lập tức
        TEMP_JSON.parent.mkdir(parents=True, exist_ok=True)
        TEMP_JSON.write_text(json.dumps({"details": results_detail}, ensure_ascii=False, indent=2), encoding="utf-8")

        r_str = f"{r_score:.3f}" if not is_unanswerable else "N/A"
        f_str = f"{f_score:.3f}" if not is_unanswerable else "N/A"
        ref_str = str(refused) if is_unanswerable else "N/A"
        print(f"{q_idx:<4} {q_type:<14} {r_str:<10} {f_str:<10} {ref_str:<10} {tot_ms:<18.1f}")

    # Tính toán kết quả tổng hợp từ kết quả chi tiết
    rouge_l_scores = [d["rouge_l"] for d in results_detail if d["type"] == "Answerable" and d["rouge_l"] is not None]
    faithfulness_scores = [d["faithfulness_score"] for d in results_detail if d["type"] == "Answerable" and d["faithfulness_score"] is not None]
    retrieval_latencies = [d["retrieval_latency_ms"] for d in results_detail]
    reranker_latencies = [d["reranker_latency_ms"] for d in results_detail]
    llm_latencies = [d["llm_latency_ms"] for d in results_detail]
    total_latencies = [d["total_latency_ms"] for d in results_detail]

    avg_rouge = sum(rouge_l_scores) / len(rouge_l_scores) if rouge_l_scores else 0.0
    avg_faithful = sum(faithfulness_scores) / len(faithfulness_scores) if faithfulness_scores else 0.0
    
    n_refused = sum(1 for d in results_detail if d["type"] == "Unanswerable" and d["refused"])
    refusal_rate = n_refused / len(unanswerable_items) if unanswerable_items else 0.0

    summary = {
        "n_total_questions": len(golden_qa),
        "n_answerable": len(answerable_items),
        "n_unanswerable": len(unanswerable_items),
        "avg_rouge_l": round(avg_rouge, 4),
        "avg_faithfulness_score": round(avg_faithful, 4),
        "refusal_rate": round(refusal_rate, 4),
        "n_correctly_refused": n_refused,
        "avg_retrieval_latency_ms": round(sum(retrieval_latencies) / len(retrieval_latencies), 1),
        "avg_reranker_latency_ms": round(sum(reranker_latencies) / len(reranker_latencies), 1),
        "avg_llm_latency_ms": round(sum(llm_latencies) / len(llm_latencies), 1),
        "avg_total_latency_ms": round(sum(total_latencies) / len(total_latencies), 1),
        "details": results_detail,
    }

    OUTPUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_JSON.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    
    # Xóa file tạm thời khi đã hoàn tất thành công
    if TEMP_JSON.exists():
        try:
            TEMP_JSON.unlink()
        except Exception:
            pass

    print("\n" + "=" * 70)
    print("KẾT QUẢ TỔNG HỢP END-TO-END GENERATION EVALUATION:")
    print("=" * 70)
    print(f"Số câu hỏi đánh giá      : {len(golden_qa)}")
    print(f"ROUGE-L Score (F1)       : {summary['avg_rouge_l']:.4f}")
    print(f"Faithfulness Score       : {summary['avg_faithfulness_score']:.4f}")
    print(f"Refusal Rate (Unanswer)  : {summary['refusal_rate'] * 100:.1f}% ({n_refused}/{len(unanswerable_items)})")
    print(f"Độ trễ Retrieval trung bình : {summary['avg_retrieval_latency_ms']} ms")
    print(f"Độ trễ Reranker trung bình  : {summary['avg_reranker_latency_ms']} ms")
    print(f"Độ trễ LLM (Qwen) trung bình: {summary['avg_llm_latency_ms']} ms")
    print(f"TỔNG ĐỘ TRỄ TRUNG BÌNH     : {summary['avg_total_latency_ms']} ms ({summary['avg_total_latency_ms']/1000:.2f}s)")
    print("=" * 70)
    print(f"Đã lưu kết quả chi tiết tại: {OUTPUT_JSON}\n")


if __name__ == "__main__":
    evaluate_end_to_end()
