"""Debug: chạy 1 câu hỏi duy nhất qua full RAG pipeline, in lỗi chi tiết."""
import sys, traceback, os
sys.path.insert(0, '.')
os.environ["PYTHONUNBUFFERED"] = "1"

try:
    print("[1/5] Importing modules...", flush=True)
    from src.config import EMBEDDING_DEVICE, RERANKER_DEVICE
    print(f"      EMBEDDING_DEVICE={EMBEDDING_DEVICE}, RERANKER_DEVICE={RERANKER_DEVICE}", flush=True)

    print("[2/5] Loading Embedder...", flush=True)
    from src.embedding import Embedder
    embedder = Embedder(device=EMBEDDING_DEVICE)
    print("      Embedder OK!", flush=True)

    print("[3/5] Loading Retriever...", flush=True)
    from src.retriever import Retriever
    retriever = Retriever(embedder=embedder)
    print("      Retriever OK!", flush=True)

    print("[4/5] Loading Reranker...", flush=True)
    from src.reranker import Reranker
    reranker = Reranker(device=RERANKER_DEVICE)
    print("      Reranker OK!", flush=True)

    print("[5/5] Running single question through ask.answer_question...", flush=True)
    from ask import answer_question
    log = answer_question(
        "What is the attention mechanism in Transformers?",
        retriever=retriever,
        reranker=reranker,
        log_path=None,
    )
    print(f"\n--- SUCCESS ---", flush=True)
    print(f"Answer (first 200 chars): {log['answer'][:200]}", flush=True)
    print(f"Retrieval: {log['retrieval_latency_ms']}ms | Rerank: {log['reranker_latency_ms']}ms | LLM: {log['llm_latency_ms']}ms | Total: {log['total_latency_ms']}ms", flush=True)

except BaseException as e:
    print(f"\n--- FAILED ---", flush=True)
    traceback.print_exc()
    sys.exit(1)
