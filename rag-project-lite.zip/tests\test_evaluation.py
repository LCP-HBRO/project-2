"""
Test độc lập cho evaluation.py.

hit_rate_at_k, reciprocal_rank, rouge_l, faithfulness_score đều là HÀM THUẦN
(pure function) — test bằng dữ liệu tự tạo, không cần model/mạng. evaluate_retriever
được test bằng Retriever/Reranker GIẢ (tiêm vào), theo đúng mẫu DI đã dùng xuyên
suốt dự án.
"""

from evaluation import (
    check_refusal,
    evaluate_refusal_behavior,
    evaluate_retriever,
    faithfulness_score,
    hit_rate_at_k,
    hit_rate_at_page,
    reciprocal_rank,
    reciprocal_rank_page,
    rouge_l,
)


# ============================================================================
# hit_rate_at_k / reciprocal_rank
# ============================================================================
def test_hit_rate_true_when_expected_source_present():
    assert hit_rate_at_k(["a.pdf", "b.pdf", "c.pdf"], "b.pdf") is True


def test_hit_rate_false_when_expected_source_absent():
    assert hit_rate_at_k(["a.pdf", "b.pdf"], "z.pdf") is False


def test_reciprocal_rank_first_position():
    assert reciprocal_rank(["a.pdf", "b.pdf"], "a.pdf") == 1.0


def test_reciprocal_rank_third_position():
    assert reciprocal_rank(["a.pdf", "b.pdf", "c.pdf"], "c.pdf") == 1.0 / 3


def test_reciprocal_rank_zero_when_absent():
    assert reciprocal_rank(["a.pdf", "b.pdf"], "z.pdf") == 0.0


# ============================================================================
# hit_rate_at_page / reciprocal_rank_page (ground truth cấp trang)
# ============================================================================
def test_hit_rate_at_page_true_when_exact_pair_present():
    pairs = [("a.pdf", 1), ("a.pdf", 5), ("b.pdf", 2)]
    assert hit_rate_at_page(pairs, "a.pdf", 5) is True


def test_hit_rate_at_page_false_when_source_matches_but_page_wrong():
    # Dung file nhung SAI trang -> phai tinh la KHONG dung (khac hit_rate_at_k cap file)
    pairs = [("a.pdf", 1), ("a.pdf", 3)]
    assert hit_rate_at_page(pairs, "a.pdf", 8) is False


def test_reciprocal_rank_page_matches_exact_pair_position():
    pairs = [("a.pdf", 1), ("a.pdf", 5), ("b.pdf", 2)]
    assert reciprocal_rank_page(pairs, "a.pdf", 5) == 0.5  # hang 2 -> 1/2


def test_reciprocal_rank_page_zero_when_source_right_but_page_wrong():
    pairs = [("a.pdf", 1)]
    assert reciprocal_rank_page(pairs, "a.pdf", 99) == 0.0


# ============================================================================
# rouge_l
# ============================================================================
def test_rouge_l_identical_strings_scores_one():
    assert rouge_l("attention is all you need", "attention is all you need") == 1.0


def test_rouge_l_completely_different_scores_zero():
    assert rouge_l("hoan toan khac nhau", "khong lien quan gi ca") == 0.0


def test_rouge_l_partial_overlap_between_zero_and_one():
    score = rouge_l("the model uses self attention", "the transformer uses self attention layers")
    assert 0.0 < score < 1.0


def test_rouge_l_empty_string_scores_zero():
    assert rouge_l("", "cai gi do") == 0.0
    assert rouge_l("cai gi do", "") == 0.0


# ============================================================================
# faithfulness_score
# ============================================================================
def test_faithfulness_all_words_grounded_scores_one():
    score = faithfulness_score("self attention is powerful", ["self attention is a powerful mechanism"])
    assert score == 1.0


def test_faithfulness_no_words_grounded_scores_zero():
    score = faithfulness_score("bananas are yellow", ["the transformer uses self attention"])
    assert score == 0.0


def test_faithfulness_partial_grounding():
    score = faithfulness_score("self attention is magic", ["self attention is a mechanism"])
    assert 0.0 < score < 1.0


# ============================================================================
# evaluate_retriever (DI: Retriever/Reranker giả)
# ============================================================================
class _FakeRetriever:
    """Luôn trả về DANH SÁCH KẾT QUẢ CỐ ĐỊNH bất kể câu hỏi — đủ để kiểm soát Hit Rate/MRR.

    pages_in_order (tuỳ chọn) cho phép kiểm soát cả số trang, để test hit_rate_page/
    mrr_page — mặc định None (điền giá trị giữ chỗ) cho các test chỉ quan tâm cấp file."""

    def __init__(self, sources_in_order, pages_in_order=None):
        self._sources = sources_in_order
        self._pages = pages_in_order or [0] * len(sources_in_order)

    def retrieve(self, query, top_k=20):
        return [
            {"metadata": {"source": s, "page": p}} for s, p in zip(self._sources, self._pages)
        ]


class _FakeReranker:
    """Đảo ngược thứ tự — đủ để kiểm tra evaluate_retriever THỰC SỰ dùng kết quả
    sau rerank, không phải kết quả gốc từ retriever."""

    def rerank(self, query, hits, top_n=5):
        return list(reversed(hits))[:top_n]


def test_evaluate_retriever_without_reranker():
    retriever = _FakeRetriever(["a.pdf", "b.pdf", "c.pdf"])
    golden_qa = [{"question": "q1", "expected_source": "a.pdf"}, {"question": "q2", "expected_source": "z.pdf"}]

    result = evaluate_retriever(retriever, golden_qa)

    assert result["n_questions"] == 2
    assert result["hit_rate"] == 0.5   # 1 trong 2 câu hỏi tìm đúng nguồn
    assert result["mrr"] == 0.5         # a.pdf ở hạng 1 -> 1.0; z.pdf không có -> 0.0; TB = 0.5


def test_evaluate_retriever_uses_reranked_order():
    retriever = _FakeRetriever(["z.pdf", "a.pdf"])  # a.pdf gốc ở hạng 2
    golden_qa = [{"question": "q1", "expected_source": "a.pdf"}]

    result = evaluate_retriever(retriever, golden_qa, reranker=_FakeReranker())

    # Sau khi FakeReranker đảo ngược: a.pdf lên hạng 1 -> MRR phải là 1.0,
    # KHÔNG phải 0.5 (hạng gốc trước rerank) -> xác nhận rerank thực sự được áp dụng.
    assert result["mrr"] == 1.0


def test_evaluate_retriever_skips_unanswerable_items_in_hit_rate_and_mrr():
    retriever = _FakeRetriever(["a.pdf", "b.pdf"])
    golden_qa = [
        {"question": "q1", "expected_source": "a.pdf"},        # hit -> tính
        {"question": "q2", "expected_source": None},            # unanswerable -> BỎ QUA
    ]

    result = evaluate_retriever(retriever, golden_qa)

    # Chỉ 1 câu được TÍNH vào hit_rate/mrr (câu unanswerable bị loại), dù
    # golden_qa có 2 phần tử -> n_questions phải là 1, không phải 2.
    assert result["n_questions"] == 1
    assert result["hit_rate"] == 1.0
    assert result["mrr"] == 1.0


def test_evaluate_retriever_all_unanswerable_returns_nan_not_crash():
    import math

    retriever = _FakeRetriever(["a.pdf"])
    golden_qa = [{"question": "q1", "expected_source": None}]

    result = evaluate_retriever(retriever, golden_qa)

    assert math.isnan(result["hit_rate"])
    assert math.isnan(result["mrr"])
    assert result["n_questions"] == 0


def test_evaluate_retriever_page_level_stricter_than_file_level():
    # Dung FILE nhung SAI trang: hit_rate cap file phai la True, hit_rate_page phai la False.
    retriever = _FakeRetriever(["a.pdf"], pages_in_order=[3])
    golden_qa = [{"question": "q1", "expected_source": "a.pdf", "expected_page": 8}]

    result = evaluate_retriever(retriever, golden_qa)

    assert result["hit_rate"] == 1.0       # dung file -> tinh la hit o cap file
    assert result["hit_rate_page"] == 0.0  # nhung SAI trang -> khong tinh o cap trang
    assert result["n_questions_page"] == 1


def test_evaluate_retriever_page_level_hit_when_page_matches():
    retriever = _FakeRetriever(["a.pdf"], pages_in_order=[8])
    golden_qa = [{"question": "q1", "expected_source": "a.pdf", "expected_page": 8}]

    result = evaluate_retriever(retriever, golden_qa)

    assert result["hit_rate_page"] == 1.0
    assert result["mrr_page"] == 1.0


def test_evaluate_retriever_omits_page_metrics_when_no_expected_page():
    # golden_qa cu (chua co expected_page) -> khong duoc co key hit_rate_page/mrr_page
    retriever = _FakeRetriever(["a.pdf"])
    golden_qa = [{"question": "q1", "expected_source": "a.pdf"}]

    result = evaluate_retriever(retriever, golden_qa)

    assert "hit_rate_page" not in result
    assert "mrr_page" not in result


# ============================================================================
# check_refusal / evaluate_refusal_behavior
# ============================================================================
def test_check_refusal_detects_vietnamese_refusal_phrase():
    assert check_refusal("Tôi không tìm thấy thông tin này trong tài liệu được cung cấp.") is True


def test_check_refusal_detects_english_refusal_phrase():
    assert check_refusal("I could not find this information in the provided context.") is True


def test_check_refusal_false_for_confident_answer():
    assert check_refusal("The Transformer uses self-attention to relate positions in a sequence.") is False


def test_check_refusal_detects_not_provided_phrase():
    # Phat hien thuc te tu evaluate_refusal_behavior() voi model thuc: Qwen hay
    # dung cum "is not provided" thay vi "not found" — phai bat duoc ca 2 kieu.
    assert check_refusal("The source code repository URL is not provided in the given context.") is True


def test_check_refusal_does_not_false_positive_on_unrelated_cung_cap():
    # "duoc cung cap" xuat hien trong cau (khong di kem "khong" ngay truoc) -> KHONG duoc tinh la tu choi
    assert check_refusal("Tôi không tìm thấy thông tin này trong tài liệu được cung cấp.") is True  # do co "khong tim thay"
    assert check_refusal("Câu trả lời nằm trong tài liệu được cung cấp ở trang 3.") is False


class _FakeRetrieverForRefusal:
    def retrieve(self, query, top_k=20, mode=None):
        return [{"text": "khong lien quan", "metadata": {"source": "x.pdf", "page": 1}, "similarity": 0.1}]


class _FakeRerankerForRefusal:
    def rerank(self, query, hits, top_n=5):
        return hits


def test_evaluate_refusal_behavior_counts_correct_refusals(monkeypatch):
    # evaluate_refusal_behavior() gọi `from ask import answer_question` bên
    # trong hàm (local import) rồi chạy pipeline thật của ask.py — chặn đúng
    # generate_answer() trong module ask (cùng mẫu DI đã dùng ở test_ask.py)
    # là đủ, không cần giả lập retriever/reranker thật bên trong ask.py.
    import ask as ask_module

    monkeypatch.setattr(ask_module, "generate_answer", lambda prompt: "Tôi không tìm thấy thông tin này.")

    golden_qa = [
        {"question": "q1", "expected_source": None},
        {"question": "q2", "expected_source": "a.pdf"},  # không phải unanswerable -> bị loại khỏi phép đo
    ]

    result = evaluate_refusal_behavior(
        golden_qa, retriever=_FakeRetrieverForRefusal(), reranker=_FakeRerankerForRefusal(), log_path=None
    )

    assert result["n_unanswerable"] == 1
    assert result["n_correctly_refused"] == 1
    assert result["refusal_rate"] == 1.0
    assert result["llm"] == "qwen"  # nhãn LLM mặc định


def test_evaluate_refusal_behavior_with_custom_answer_fn():
    # Đánh giá một LLM KHÁC (vd Gemini) bằng cách truyền answer_fn — không cần
    # đụng tới ask.py/Qwen. answer_fn giả lập ở đây luôn BỊA (không từ chối).
    def fake_hallucinating_llm(query, retriever, reranker):
        return {"answer": "GPT-5 được phát hành vào ngày 1 tháng 1 năm 2025."}

    golden_qa = [
        {"question": "q1", "expected_source": None},
        {"question": "q2", "expected_source": None},
    ]

    result = evaluate_refusal_behavior(
        golden_qa,
        retriever=_FakeRetrieverForRefusal(),
        reranker=_FakeRerankerForRefusal(),
        answer_fn=fake_hallucinating_llm,
        llm_label="gemini-test",
    )

    assert result["llm"] == "gemini-test"
    assert result["n_unanswerable"] == 2
    assert result["n_correctly_refused"] == 0   # LLM giả luôn bịa -> không câu nào từ chối
    assert result["refusal_rate"] == 0.0
