"""
loader.py — Document Loader.

LÝ THUYẾT (vì sao module này tồn tại):
    Tài liệu nguồn của bạn ở nhiều định dạng khác nhau (PDF cho paper, DOCX
    cho tài liệu văn bản). Mỗi định dạng có cách trích xuất văn bản riêng: PDF là dữ liệu nhị
    phân có layout (cột, header, footer), còn DOCX là tài liệu văn bản có cấu trúc. Nhiệm vụ
    của Loader là CHUẨN HOÁ mọi định dạng về cùng MỘT kiểu dữ liệu (Document) để
    các bước sau (chunker, embedding...) không cần biết file gốc là PDF hay DOCX.

    Một quyết định quan trọng: loader PDF trả về MỘT Document CHO MỖI TRANG, thay vì
    gộp cả file thành một chuỗi lớn. Lý do: ta muốn giữ được số trang làm metadata
    để trích dẫn nguồn (ví dụ "theo trang 5 của Attention Is All You Need") ở bước
    sinh câu trả lời (Ngày 6). Nếu gộp hết thành 1 chuỗi ngay từ đầu, thông tin
    trang sẽ mất vĩnh viễn.

THIẾT KẾ:
    - Document: dataclass đơn giản (text, source, page) — "hợp đồng dữ liệu" giữa
      loader và chunker. Bất kỳ loader mới nào (vd: thêm .html sau này) chỉ cần
      trả về list[Document] đúng dạng này là chunker dùng được ngay, không cần sửa.
    - load_pdf(): dùng PyMuPDF (fitz) — nhanh, không cần Poppler/ImageMagick như
      một số thư viện PDF khác.
    - load_docx(): đọc .docx bằng python-docx (không có khái niệm "trang").
    - load_documents(): quét cả thư mục, tự chọn loader theo phần mở rộng file.
"""

from dataclasses import dataclass
from pathlib import Path

import fitz  # PyMuPDF — tên import là 'fitz' vì lý do lịch sử của thư viện

from src.config import DOCUMENTS_DIR

# Các phần mở rộng file văn bản Word
DOCX_EXTENSIONS = {".docx"}
PDF_EXTENSIONS = {".pdf"}


@dataclass
class Document:
    """
    Một đơn vị văn bản thô, gắn kèm nguồn gốc để trích dẫn về sau.

    text:   nội dung văn bản (một trang PDF, hoặc toàn bộ một file .docx)
    source: tên file gốc (vd: "attention_is_all_you_need.pdf")
    page:   số trang (bắt đầu từ 1) nếu là PDF; None nếu là tài liệu Word
    """
    text: str
    source: str
    page: int | None = None


def load_pdf(path: Path) -> list[Document]:
    """
    Đọc một file PDF, trả về MỘT Document cho MỖI TRANG có chữ.

    Vì sao tách theo trang thay vì gộp cả file:
    xem phần LÝ THUYẾT ở đầu file — giữ số trang để trích dẫn nguồn sau này.
    """
    documents: list[Document] = []
    # fitz.open() trả về đối tượng đại diện cả file PDF; "with" đảm bảo đóng file
    # (giải phóng tài nguyên) kể cả khi có lỗi xảy ra giữa chừng.
    with fitz.open(path) as pdf:
        for page_index, page in enumerate(pdf):
            # Lấy các block văn bản. Mỗi block là một tuple: (x0, y0, x1, y1, "nội dung", block_no, block_type)
            blocks = page.get_text("blocks")
            # Lọc chỉ lấy block chứa text (block_type = 0) và nối chúng bằng "\n\n"
            text = "\n\n".join([b[4].strip() for b in blocks if b[6] == 0])
            if text.strip():  # bỏ qua trang trắng (vd trang bìa chỉ có ảnh)
                documents.append(
                    Document(text=text, source=path.name, page=page_index + 1)
                )
    return documents


def load_docx(path: Path) -> list[Document]:
    """Đọc một file .docx, trả về DUY NHẤT một Document chứa toàn bộ văn bản (không có số trang)."""
    import docx
    doc_obj = docx.Document(path)
    # Ghép các đoạn văn bản (paragraphs) lại bằng \n\n để giữ cấu trúc đoạn văn tự nhiên
    text = "\n\n".join([p.text.strip() for p in doc_obj.paragraphs if p.text.strip()])
    return [Document(text=text, source=path.name, page=None)]


def load_documents(directory: Path = DOCUMENTS_DIR) -> list[Document]:
    """
    Quét toàn bộ thư mục, đọc mọi file được hỗ trợ (.pdf, .docx).

    Trả về danh sách phẳng list[Document] gộp từ mọi file — chunker ở bước sau
    sẽ xử lý từng Document độc lập nên thứ tự file không quan trọng.
    """
    documents: list[Document] = []
    # sorted() để thứ tự xử lý ổn định giữa các lần chạy (dễ debug, dễ so sánh log).
    for path in sorted(directory.iterdir()):
        if not path.is_file():
            continue
        suffix = path.suffix.lower()
        if suffix in PDF_EXTENSIONS:
            documents.extend(load_pdf(path))
        elif suffix in DOCX_EXTENSIONS:
            documents.extend(load_docx(path))
        # Các phần mở rộng khác (.gitkeep, .png...) bị bỏ qua thầm lặng — đây là
        # thư mục dữ liệu, không phải mọi file trong đó đều là tài liệu cần nạp.
    return documents


if __name__ == "__main__":
    # Chạy `python -m src.loader` từ thư mục gốc để thử nhanh trên dữ liệu thật.
    docs = load_documents()
    print(f"Đã đọc {len(docs)} Document từ {DOCUMENTS_DIR}")
    for doc in docs[:3]:
        preview = doc.text[:80].replace("\n", " ")
        print(f"  - {doc.source} (trang {doc.page}): {preview}...")
